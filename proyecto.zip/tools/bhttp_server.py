#!/usr/bin/env python3
"""Servidor BHTTP propio (lado VPS) para la app Conecta. Version 2.

Recibe las peticiones BHTTP de la app y las reenvia al SSH del propio VPS (127.0.0.1:22 por defecto):

    app --BHTTP--> este script --TCP--> sshd

Sin dependencias: solo Python 3.8 o mas nuevo. Uso:

    python3 bhttp_server.py --port 8080 --backend 127.0.0.1:22
    python3 bhttp_server.py --probe 127.0.0.1:8080        # autoprueba de un servidor ya en marcha

Mejoras de la version 2 sobre la 1:
  * Espera corta de datos (--poll-wait-ms): si el SSH aun no tiene nada que enviar, el servidor
    aguarda un momento antes de responder vacio, asi la respuesta sale en cuanto llegan los datos
    en vez de esperar al siguiente sondeo de la app (baja la latencia).
  * Conexiones reutilizables: varias peticiones seguidas por la misma conexion TCP (la app actual
    abre una por peticion y sigue funcionando igual).
  * Keep-alive TCP en las conexiones de la app para limpiar enlaces muertos antes.

IMPORTANTE sobre seguridad: el "cifrado" de BHTTP es solo ofuscacion (no usa ninguna clave secreta),
no protege nada por si mismo. La seguridad real es la de SSH, que va por dentro. Este servidor solo
reenvia al destino fijo que le indiques con --backend, asi que no sirve de proxy abierto.

Protocolo (lo que el cliente de la app espera):
  Peticion  : [modo:1][sid:16][seq:8][largo:4][datos]      (una peticion por conexion TCP)
  Respuesta : [estado:1][largo:4][cuerpo]
  Modos     : 0 sondeo, 1 subida, 2 bajada (solo en sondeo), 3 lote de bajada, 4 ack
  Estados   : 0 ok, 1 error, 2 datos
  Ofuscacion: XOR con SHA-256(sid | modo | seq | es_respuesta | n_bloque), bloques de 32 bytes.
"""
import argparse
import asyncio
import hashlib
import logging
import signal
import struct
import time

MODE_PROBE, MODE_UPLOAD, MODE_DOWNLOAD, MODE_BATCH, MODE_ACK = 0, 1, 2, 3, 4
ST_OK, ST_ERR, ST_DATA = 0, 1, 2

HEADER = 29                      # 1 + 16 + 8 + 4
MAX_REQUEST = 1 << 20            # 1 MiB por peticion (el cliente manda como maximo 32 KiB)
MAX_PROBE_REPLY = 1 << 20
MAX_CHUNK = 65536
MAX_BATCH = 32
REQUEST_TIMEOUT = 15             # segundos para leer una peticion completa
KEEPALIVE_IDLE = 30              # segundos que una conexion reutilizada puede esperar la siguiente peticion
MAX_REQUESTS_PER_CONN = 2048
BACKLOG_MAX = 4 << 20            # bytes que se guardan del SSH antes de dejar de leerlo
UP_PENDING_MAX = 8 << 20         # bytes de subida fuera de orden que se aceptan guardar

log = logging.getLogger("bhttp")


# ---------------------------------------------------------------- ofuscacion

def crypt(data: bytes, sid: bytes, mode: int, seq: int, is_response: bool) -> bytes:
    """XOR con un flujo derivado de SHA-256. Es simetrico: sirve para cifrar y descifrar."""
    if not data:
        return b""
    base = sid + bytes([mode]) + seq.to_bytes(8, "big") + (b"\x01" if is_response else b"\x00")
    n = len(data)
    ks = b"".join(hashlib.sha256(base + i.to_bytes(4, "big")).digest() for i in range((n + 31) // 32))
    return (int.from_bytes(data, "big") ^ int.from_bytes(ks[:n], "big")).to_bytes(n, "big")


def reply(status: int, body: bytes = b"") -> bytes:
    return bytes([status]) + struct.pack(">I", len(body)) + body


# ---------------------------------------------------------------- sesion

class Session:
    """Una conexion SSH de la app (identificada por su sid de 16 bytes)."""

    def __init__(self, sid, reader, writer):
        self.sid = sid
        self.reader = reader
        self.writer = writer
        self.last = time.monotonic()
        self.closed = False         # el SSH del VPS cerro la conexion
        # subida: se escribe al SSH estrictamente en orden de seq
        self.next_up = 0
        self.up_pending = {}
        self.up_pending_bytes = 0
        # bajada: el flujo del SSH se reparte en "casillas" numeradas; la app las pide por ventanas
        self.backlog = bytearray()
        self.slots = {}             # casilla -> bytes (se guarda hasta que la app la confirma)
        self.filled = 0             # primera casilla aun sin asignar
        self.cond = asyncio.Condition()
        self.task = asyncio.ensure_future(self._pump())

    async def _pump(self):
        """Lee del SSH y guarda los bytes hasta que la app los pida."""
        try:
            while True:
                while len(self.backlog) >= BACKLOG_MAX:
                    await asyncio.sleep(0.02)
                data = await self.reader.read(65536)
                if not data:
                    break
                self.backlog += data
                await self._wake()
        except (ConnectionError, OSError, asyncio.CancelledError):
            pass
        finally:
            self.closed = True
            try:
                await self._wake()
            except Exception:
                pass

    async def _wake(self):
        async with self.cond:
            self.cond.notify_all()

    async def upload(self, seq: int, data: bytes) -> int:
        self.last = time.monotonic()
        if not data or seq < self.next_up:
            return ST_OK            # registro, o un reintento de algo ya entregado
        if seq not in self.up_pending:
            if self.up_pending_bytes + len(data) > UP_PENDING_MAX:
                return ST_ERR
            self.up_pending[seq] = data
            self.up_pending_bytes += len(data)
        wrote = False
        while self.next_up in self.up_pending:
            chunk = self.up_pending.pop(self.next_up)
            self.up_pending_bytes -= len(chunk)
            self.next_up += 1
            self.writer.write(chunk)
            wrote = True
        if wrote:
            try:
                await self.writer.drain()
            except (ConnectionError, OSError):
                return ST_ERR
        return ST_OK

    async def batch(self, base: int, chunk: int, count: int, wait: float):
        """Devuelve las `count` casillas desde `base`.

        Los datos se asignan siempre a la primera casilla libre (en orden), igual que en la version 1.
        Si la ventana aun no esta asignada y no hay datos pendientes, espera hasta `wait` segundos a que
        lleguen (o a que otra peticion asigne esta ventana) en vez de responder vacio al instante.
        """
        self.last = time.monotonic()
        end = base + count
        if wait > 0 and end > self.filled and not self.backlog and not self.closed:
            async with self.cond:
                try:
                    await asyncio.wait_for(self.cond.wait_for(
                        lambda: self.filled >= end or self.closed or len(self.backlog) > 0), wait)
                except asyncio.TimeoutError:
                    pass
            self.last = time.monotonic()
        changed = False
        while self.filled < end:
            take = min(chunk, len(self.backlog))
            self.slots[self.filled] = bytes(self.backlog[:take])
            del self.backlog[:take]
            self.filled += 1
            changed = True
        if changed:
            await self._wake()
        return [self.slots.get(base + i, b"") for i in range(count)]

    def ack(self, seq: int):
        self.last = time.monotonic()
        for k in [k for k in self.slots if k <= seq]:
            del self.slots[k]

    async def close(self):
        self.task.cancel()
        try:
            self.writer.close()
            await self.writer.wait_closed()
        except Exception:
            pass


# ---------------------------------------------------------------- servidor

class Server:
    def __init__(self, backend, max_sessions, idle, max_per_ip, poll_wait=0.8):
        self.poll_wait = poll_wait
        self.backend = backend
        self.max_sessions = max_sessions
        self.idle = idle
        self.max_per_ip = max_per_ip
        self.sessions = {}
        self.creating = {}
        self.per_ip = {}

    async def get_session(self, sid, ip=None, create=False):
        s = self.sessions.get(sid)
        if s or not create:
            return s
        fut = self.creating.get(sid)
        if fut is None:
            if len(self.sessions) + len(self.creating) >= self.max_sessions:
                log.warning("limite de sesiones alcanzado")
                return None
            if self.per_ip.get(ip, 0) >= self.max_per_ip:
                log.warning("limite de sesiones por IP alcanzado")
                return None
            fut = asyncio.ensure_future(self._create(sid, ip))
            self.creating[sid] = fut
        try:
            return await fut
        finally:
            self.creating.pop(sid, None)

    async def _create(self, sid, ip):
        try:
            r, w = await asyncio.wait_for(asyncio.open_connection(*self.backend), 5)
        except (OSError, asyncio.TimeoutError) as e:
            log.warning("no se pudo conectar al destino: %s", e)
            return None
        s = Session(sid, r, w)
        s.ip = ip
        self.per_ip[ip] = self.per_ip.get(ip, 0) + 1
        self.sessions[sid] = s
        log.info("sesion abierta (%d activas)", len(self.sessions))
        return s

    async def drop(self, sid):
        s = self.sessions.pop(sid, None)
        if s:
            left = self.per_ip.get(s.ip, 1) - 1
            if left > 0:
                self.per_ip[s.ip] = left
            else:
                self.per_ip.pop(s.ip, None)
            await s.close()
            log.info("sesion cerrada (%d activas)", len(self.sessions))

    async def janitor(self):
        while True:
            await asyncio.sleep(min(15, max(1, self.idle // 2)))
            now = time.monotonic()
            for sid, s in list(self.sessions.items()):
                if now - s.last > self.idle:
                    await self.drop(sid)

    # ---- una peticion por conexion

    async def handle(self, reader, writer):
        try:
            sock = writer.get_extra_info("socket")
            if sock is not None:
                try:
                    import socket as _s
                    sock.setsockopt(_s.SOL_SOCKET, _s.SO_KEEPALIVE, 1)
                    for name, val in (("TCP_KEEPIDLE", 60), ("TCP_KEEPINTVL", 15), ("TCP_KEEPCNT", 4)):
                        if hasattr(_s, name):
                            sock.setsockopt(_s.IPPROTO_TCP, getattr(_s, name), val)
                except OSError:
                    pass
            peer = writer.get_extra_info("peername")
            ip = peer[0] if peer else None
            for n_req in range(MAX_REQUESTS_PER_CONN):
                # la primera peticion debe llegar enseguida; las siguientes pueden tardar mas
                wait = REQUEST_TIMEOUT if n_req == 0 else KEEPALIVE_IDLE
                head = await asyncio.wait_for(reader.readexactly(HEADER), wait)
                mode = head[0]
                sid = bytes(head[1:17])
                seq = int.from_bytes(head[17:25], "big")
                n = int.from_bytes(head[25:29], "big")
                if n > MAX_REQUEST:
                    writer.write(reply(ST_ERR))
                    await writer.drain()
                    return
                data = await asyncio.wait_for(reader.readexactly(n), REQUEST_TIMEOUT) if n else b""
                out = await self.dispatch(mode, sid, seq, data, ip)
                writer.write(out)
                await writer.drain()
        except (asyncio.IncompleteReadError, asyncio.TimeoutError, ConnectionError, OSError):
            pass
        except Exception:
            log.exception("error atendiendo una peticion")
        finally:
            try:
                writer.close()
            except Exception:
                pass

    async def dispatch(self, mode, sid, seq, data, ip=None) -> bytes:
        if mode == MODE_PROBE:
            return self.probe(sid, data)

        # Solo la subida (el registro de la app) puede abrir una sesion nueva; lote y ack
        # exigen una sesion existente. Asi la basura no gasta conexiones al destino.
        if mode == MODE_UPLOAD:
            s = await self.get_session(sid, ip, create=True)
            if s is None:
                return reply(ST_ERR)
            return reply(await s.upload(seq, crypt(data, sid, MODE_UPLOAD, seq, False)))

        if mode == MODE_BATCH:
            s = self.sessions.get(sid)
            req = crypt(data, sid, MODE_BATCH, seq, False)
            if s is None or len(req) < 6:
                return reply(ST_ERR)
            chunk = struct.unpack(">i", req[:4])[0]
            count = req[5]
            if not (1 <= chunk <= MAX_CHUNK) or not (1 <= count <= MAX_BATCH):
                return reply(ST_ERR)
            out = bytearray()
            for i, raw in enumerate(await s.batch(seq, chunk, count, self.poll_wait)):
                enc = crypt(raw, sid, MODE_BATCH, seq + i, True)
                out += reply(ST_DATA, struct.pack(">I", len(enc)) + enc)
            return bytes(out)

        if mode == MODE_ACK:
            s = self.sessions.get(sid)
            if s is None:
                return reply(ST_ERR)
            s.ack(seq)
            return reply(ST_OK)

        return reply(ST_ERR)

    @staticmethod
    def probe(sid, data) -> bytes:
        plain = crypt(data, sid, MODE_PROBE, 0, False)
        if len(plain) < 10 or plain[:4] != b"BHP1" or plain[4] != 1:
            return reply(ST_ERR)
        mode = plain[5]
        param = struct.unpack(">i", plain[6:10])[0]
        length = max(10, param) if mode == MODE_DOWNLOAD else 10
        if length > MAX_PROBE_REPLY:
            return reply(ST_ERR)
        body = bytearray(length)
        body[0:4] = b"BHP1"
        body[4] = 1
        body[5] = mode
        body[6:10] = struct.pack(">i", param)
        for i in range(10, length):
            body[i] = (i * 31) & 0xFF
        return reply(ST_OK, crypt(bytes(body), sid, MODE_PROBE, 0, True))


def probe_client(target: str) -> bool:
    """Autoprueba: hace el sondeo BHP1 igual que la app y comprueba la respuesta."""
    import os
    import socket
    host, _, port = target.rpartition(":")
    try:
        sid = os.urandom(16)
        plain = bytearray(10)
        plain[0:4] = b"BHP1"
        plain[4] = 1
        plain[5] = MODE_BATCH
        plain[6:10] = struct.pack(">i", 8)
        data = crypt(bytes(plain), sid, MODE_PROBE, 0, False)
        with socket.create_connection((host or "127.0.0.1", int(port)), timeout=5) as sk:
            sk.sendall(bytes([MODE_PROBE]) + sid + (0).to_bytes(8, "big") + struct.pack(">I", len(data)) + data)
            sk.settimeout(5)
            buf = b""
            while len(buf) < 5:
                chunk = sk.recv(5 - len(buf))
                if not chunk:
                    break
                buf += chunk
            if len(buf) < 5 or buf[0] != ST_OK:
                print("el servidor respondio con error o no respondio")
                return False
            n = struct.unpack(">I", buf[1:5])[0]
            body = b""
            while len(body) < n:
                chunk = sk.recv(n - len(body))
                if not chunk:
                    break
                body += chunk
        resp = crypt(body, sid, MODE_PROBE, 0, True)
        good = (len(resp) == 10 and resp[:4] == b"BHP1" and resp[4] == 1 and resp[5] == MODE_BATCH
                and struct.unpack(">i", resp[6:10])[0] == 8)
        print("sondeo BHP1: OK" if good else "sondeo BHP1: respuesta invalida")
        return good
    except OSError as e:
        print("no se pudo conectar:", e)
        return False


async def main_async(args):
    host, _, port = args.backend.rpartition(":")
    srv = Server((host or "127.0.0.1", int(port)), args.max_sessions, args.idle, args.max_per_ip,
                 max(0, args.poll_wait_ms) / 1000.0)
    server = await asyncio.start_server(srv.handle, args.listen, args.port, backlog=1024)
    asyncio.ensure_future(srv.janitor())
    log.info("BHTTP escuchando en %s:%d -> %s", args.listen, args.port, args.backend)

    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:
            pass
    async with server:
        await stop.wait()
    for sid in list(srv.sessions):
        await srv.drop(sid)


def main():
    ap = argparse.ArgumentParser(description="Servidor BHTTP propio para la app Conecta")
    ap.add_argument("--listen", default="0.0.0.0", help="direccion donde escucha (por defecto 0.0.0.0)")
    ap.add_argument("--port", type=int, help="puerto TCP donde escucha la app")
    ap.add_argument("--probe", metavar="HOST:PUERTO", help="autoprueba: hace el sondeo BHP1 contra un servidor en marcha y sale")
    ap.add_argument("--poll-wait-ms", type=int, default=800,
                    help="milisegundos que espera datos antes de responder vacio (0 = no esperar; por defecto 800)")
    ap.add_argument("--backend", default="127.0.0.1:22", help="destino al que se reenvia (por defecto 127.0.0.1:22)")
    ap.add_argument("--max-sessions", type=int, default=128, help="sesiones simultaneas maximas")
    ap.add_argument("--max-per-ip", type=int, default=64, help="sesiones simultaneas maximas por IP de origen")
    ap.add_argument("--idle", type=int, default=120, help="segundos sin actividad para cerrar una sesion")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args()
    if args.probe:
        raise SystemExit(0 if probe_client(args.probe) else 1)
    if not args.port:
        ap.error("falta --port")
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    asyncio.run(main_async(args))


if __name__ == "__main__":
    main()
