#!/usr/bin/env bash
# el_tioNel BHTTP - instalador y administrador.
# Uso:  sudo bash install_el_tioNel.sh        (abre el menu)
#       sudo bash install_el_tioNel.sh install --port 8080
#       sudo el_tioNel                        (despues de instalar)
set -u

# ---- Nombre que se ve en el VPS (servicio, carpetas, comando, procesos). ----
# Si algun dia quieres otro nombre, cambia SOLO esta linea ANTES de instalar.
BRAND="el_tioNel"
NAME="${BRAND}-bhttp"
CMD="$BRAND"

MANAGER_VERSION="1.1"
ROOT="${BHTTP_ROOT:-}"                       # solo para pruebas; en uso normal queda vacio
APP_DIR="$ROOT/opt/$NAME"
SERVER="$APP_DIR/${NAME}-server.py"
LAUNCHER="$ROOT/usr/local/bin/${NAME}-server"   # enlace a python3: asi el proceso se ve con tu nombre
CONF_DIR="$ROOT/etc/$NAME"
CONFIG="$CONF_DIR/config"
PORTS_FILE="$CONF_DIR/ports"
FW_FILE="$CONF_DIR/firewall-added"
SYSCTL_PREV="$CONF_DIR/sysctl.prev"
SYSCTL_FILE="$ROOT/etc/sysctl.d/99-${NAME}.conf"
UNIT_FILE="$ROOT/etc/systemd/system/${NAME}@.service"
SELF_DEST="$ROOT/usr/local/sbin/${NAME}-manager"
BIN_LINK="$ROOT/usr/local/bin/$CMD"
CFG_KEYS="BACKEND POLL_WAIT_MS MAX_SESSIONS MAX_PER_IP IDLE"

if [ -t 1 ]; then C_OK='\033[1;32m'; C_ERR='\033[1;31m'; C_INF='\033[1;36m'; C_WRN='\033[1;33m'; C_OFF='\033[0m'
else C_OK=''; C_ERR=''; C_INF=''; C_WRN=''; C_OFF=''; fi
ok(){ printf '%b✔%b %s\n' "$C_OK" "$C_OFF" "$*"; }
info(){ printf '%bℹ%b %s\n' "$C_INF" "$C_OFF" "$*"; }
warn(){ printf '%b⚠%b %s\n' "$C_WRN" "$C_OFF" "$*"; }
fail(){ printf '%b✘%b %s\n' "$C_ERR" "$C_OFF" "$*" >&2; }
have(){ command -v "$1" >/dev/null 2>&1; }
need_root(){
  [ -n "${BHTTP_TEST:-}" ] && return 0
  [ "$(id -u)" -eq 0 ] || { fail "Ejecuta como root (sudo)."; exit 1; }
}
ask(){ local __v="$1"; IFS= read -r -p "$2" "$__v" || eval "$__v=''"; }
pause(){ [ -t 0 ] || return 0; echo; local _; ask _ "Presiona ENTER para continuar..."; }
confirm_word(){            # confirm_word PALABRA "mensaje"
  [ -n "${BHTTP_YES:-}" ] && return 0
  local c; ask c "$2 Escribe $1 para confirmar: "; [ "$c" = "$1" ]
}
valid_port(){ [[ "${1:-}" =~ ^[0-9]+$ ]] && [ "$1" -ge 1 ] && [ "$1" -le 65535 ]; }
valid_num(){ [[ "${2:-}" =~ ^[0-9]+$ ]] && [ "$2" -ge "$1" ] && [ "$2" -le "$3" ]; }   # valid_num min valor max

# ---------------------------------------------------------------- configuracion
cfg_default(){
  case "$1" in
    BACKEND) echo "127.0.0.1:22";; POLL_WAIT_MS) echo 800;; MAX_SESSIONS) echo 1024;;
    MAX_PER_IP) echo 64;; IDLE) echo 120;;
  esac
}
cfg_get(){
  local v; v="$(grep -m1 "^$1=" "$CONFIG" 2>/dev/null | cut -d= -f2-)"
  if [ -n "$v" ]; then printf '%s' "$v"; else cfg_default "$1"; fi
}
cfg_set(){
  local k="$1" v="$2" key out=""
  for key in $CFG_KEYS; do
    if [ "$key" = "$k" ]; then out+="$key=$v"$'\n'; else out+="$key=$(cfg_get "$key")"$'\n'; fi
  done
  mkdir -p "$CONF_DIR"; printf '%s' "$out" > "$CONFIG"; chmod 644 "$CONFIG"
}
cfg_init(){ [ -f "$CONFIG" ] || cfg_set BACKEND "$(cfg_default BACKEND)"; }
backend_port(){ cfg_get BACKEND | awk -F: '{print $NF}'; }

# ---------------------------------------------------------------- puertos
ports_list(){ [ -f "$PORTS_FILE" ] && grep -E '^[0-9]+$' "$PORTS_FILE" | sort -n -u || true; }
ports_has(){ ports_list | grep -qx "$1"; }
ports_add(){ mkdir -p "$CONF_DIR"; ports_has "$1" || echo "$1" >> "$PORTS_FILE"; }
ports_del(){ [ -f "$PORTS_FILE" ] || return 0; grep -vx "$1" "$PORTS_FILE" > "$PORTS_FILE.tmp" || true; mv "$PORTS_FILE.tmp" "$PORTS_FILE"; }
unit_name(){ echo "${NAME}@$1.service"; }
listening(){ ss -lnt 2>/dev/null | awk -v p=":$1" '$4 ~ p"$" {f=1} END{exit !f}'; }
conn_count(){ ss -tan 2>/dev/null | awk -v p=":$1" '$1=="ESTAB" && $4 ~ p"$" {n++} END{print n+0}'; }

# ---------------------------------------------------------------- firewall (solo toca lo que el mismo abrio)
ufw_active(){ have ufw && ufw status 2>/dev/null | grep -q '^Status: active'; }
firewalld_active(){ have firewall-cmd && firewall-cmd --state >/dev/null 2>&1; }
fw_open(){
  local p="$1"
  mkdir -p "$CONF_DIR"
  if ufw_active; then
    if ufw status 2>/dev/null | grep -Eq "(^|[[:space:]])${p}/tcp([[:space:]]|$)"; then
      info "ufw: el puerto $p/tcp ya estaba permitido."
    else
      ufw allow "${p}/tcp" >/dev/null && echo "ufw $p" >> "$FW_FILE" && ok "ufw: puerto $p/tcp abierto."
    fi
  elif firewalld_active; then
    if firewall-cmd --query-port="${p}/tcp" >/dev/null 2>&1; then
      info "firewalld: el puerto $p/tcp ya estaba permitido."
    else
      firewall-cmd --permanent --add-port="${p}/tcp" >/dev/null && firewall-cmd --reload >/dev/null \
        && echo "firewalld $p" >> "$FW_FILE" && ok "firewalld: puerto $p/tcp abierto."
    fi
  else
    info "No detecte ufw ni firewalld activos. Si usas iptables a mano o el firewall del proveedor, abre TCP $p."
  fi
}
fw_close(){
  local p="$1"
  [ -f "$FW_FILE" ] || return 0
  if grep -qx "ufw $p" "$FW_FILE" && have ufw; then ufw delete allow "${p}/tcp" >/dev/null 2>&1; ok "ufw: puerto $p/tcp cerrado."; fi
  if grep -qx "firewalld $p" "$FW_FILE" && have firewall-cmd; then
    firewall-cmd --permanent --remove-port="${p}/tcp" >/dev/null 2>&1; firewall-cmd --reload >/dev/null 2>&1
    ok "firewalld: puerto $p/tcp cerrado."
  fi
  grep -vxE "(ufw|firewalld) $p" "$FW_FILE" > "$FW_FILE.tmp" || true; mv "$FW_FILE.tmp" "$FW_FILE"
}

# ---------------------------------------------------------------- instalacion
ensure_python(){
  local okpy='import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)'
  if have python3 && python3 -c "$okpy" 2>/dev/null; then return 0; fi
  info "Instalando python3..."
  if have apt-get; then
    DEBIAN_FRONTEND=noninteractive apt-get install -y python3 >/dev/null 2>&1 \
      || { apt-get update -y >/dev/null 2>&1; DEBIAN_FRONTEND=noninteractive apt-get install -y python3 >/dev/null 2>&1; }
  elif have dnf; then dnf install -y python3 >/dev/null 2>&1
  elif have yum; then yum install -y python3 >/dev/null 2>&1
  fi
  have python3 && python3 -c "$okpy" 2>/dev/null || { fail "Necesito Python 3.8 o mas nuevo y no pude instalarlo."; return 1; }
}

write_server(){
  mkdir -p "$APP_DIR"
  [ -f "$SERVER" ] && cp -a "$SERVER" "$SERVER.prev"
  cat > "$SERVER" <<'BHTTP_SERVER_PY_EOF'
#!/usr/bin/env python3
"""Servidor BHTTP propio (lado VPS) para la app Conecta. Version 2.

Recibe las peticiones BHTTP de la app y las reenvia al SSH del propio VPS (127.0.0.1:22 por defecto):

    app --BHTTP--> este script --TCP--> sshd

Sin dependencias: solo Python 3.8 o mas nuevo. Uso:

    python3 bhttp_server.py --port 8080 --backend 127.0.0.1:22
    python3 bhttp_server.py --probe 127.0.0.1:8080        # autoprueba de un servidor ya en marcha

Mejoras de la version 2 sobre la 1:
  * Espera corta de datos (--poll-wait-ms): si el SSH aun no tiene nada que enviar, el servidor
    aguarda un momento antes de responder vacio, asi la respuesta sale en cuanto llegan los datos
    en vez de esperar al siguiente sondeo de la app (baja la latencia).
  * Conexiones reutilizables: varias peticiones seguidas por la misma conexion TCP (la app actual
    abre una por peticion y sigue funcionando igual).
  * Keep-alive TCP en las conexiones de la app para limpiar enlaces muertos antes.

IMPORTANTE sobre seguridad: el "cifrado" de BHTTP es solo ofuscacion (no usa ninguna clave secreta),
no protege nada por si mismo. La seguridad real es la de SSH, que va por dentro. Este servidor solo
reenvia al destino fijo que le indiques con --backend, asi que no sirve de proxy abierto.

Protocolo (lo que el cliente de la app espera):
  Peticion  : [modo:1][sid:16][seq:8][largo:4][datos]      (una peticion por conexion TCP)
  Respuesta : [estado:1][largo:4][cuerpo]
  Modos     : 0 sondeo, 1 subida, 2 bajada (solo en sondeo), 3 lote de bajada, 4 ack
  Estados   : 0 ok, 1 error, 2 datos
  Ofuscacion: XOR con SHA-256(sid | modo | seq | es_respuesta | n_bloque), bloques de 32 bytes.
"""
import argparse
import asyncio
import hashlib
import logging
import signal
import struct
import time

MODE_PROBE, MODE_UPLOAD, MODE_DOWNLOAD, MODE_BATCH, MODE_ACK = 0, 1, 2, 3, 4
ST_OK, ST_ERR, ST_DATA = 0, 1, 2

HEADER = 29                      # 1 + 16 + 8 + 4
MAX_REQUEST = 1 << 20            # 1 MiB por peticion (el cliente manda como maximo 32 KiB)
MAX_PROBE_REPLY = 1 << 20
MAX_CHUNK = 65536
MAX_BATCH = 32
REQUEST_TIMEOUT = 15             # segundos para leer una peticion completa
KEEPALIVE_IDLE = 30              # segundos que una conexion reutilizada puede esperar la siguiente peticion
MAX_REQUESTS_PER_CONN = 2048
BACKLOG_MAX = 4 << 20            # bytes que se guardan del SSH antes de dejar de leerlo
UP_PENDING_MAX = 8 << 20         # bytes de subida fuera de orden que se aceptan guardar

log = logging.getLogger("bhttp")


# ---------------------------------------------------------------- ofuscacion

def crypt(data: bytes, sid: bytes, mode: int, seq: int, is_response: bool) -> bytes:
    """XOR con un flujo derivado de SHA-256. Es simetrico: sirve para cifrar y descifrar."""
    if not data:
        return b""
    base = sid + bytes([mode]) + seq.to_bytes(8, "big") + (b"\x01" if is_response else b"\x00")
    n = len(data)
    ks = b"".join(hashlib.sha256(base + i.to_bytes(4, "big")).digest() for i in range((n + 31) // 32))
    return (int.from_bytes(data, "big") ^ int.from_bytes(ks[:n], "big")).to_bytes(n, "big")


def reply(status: int, body: bytes = b"") -> bytes:
    return bytes([status]) + struct.pack(">I", len(body)) + body


# ---------------------------------------------------------------- sesion

class Session:
    """Una conexion SSH de la app (identificada por su sid de 16 bytes)."""

    def __init__(self, sid, reader, writer):
        self.sid = sid
        self.reader = reader
        self.writer = writer
        self.last = time.monotonic()
        self.closed = False         # el SSH del VPS cerro la conexion
        # subida: se escribe al SSH estrictamente en orden de seq
        self.next_up = 0
        self.up_pending = {}
        self.up_pending_bytes = 0
        # bajada: el flujo del SSH se reparte en "casillas" numeradas; la app las pide por ventanas
        self.backlog = bytearray()
        self.slots = {}             # casilla -> bytes (se guarda hasta que la app la confirma)
        self.filled = 0             # primera casilla aun sin asignar
        self.cond = asyncio.Condition()
        self.task = asyncio.ensure_future(self._pump())

    async def _pump(self):
        """Lee del SSH y guarda los bytes hasta que la app los pida."""
        try:
            while True:
                while len(self.backlog) >= BACKLOG_MAX:
                    await asyncio.sleep(0.02)
                data = await self.reader.read(65536)
                if not data:
                    break
                self.backlog += data
                await self._wake()
        except (ConnectionError, OSError, asyncio.CancelledError):
            pass
        finally:
            self.closed = True
            try:
                await self._wake()
            except Exception:
                pass

    async def _wake(self):
        async with self.cond:
            self.cond.notify_all()

    async def upload(self, seq: int, data: bytes) -> int:
        self.last = time.monotonic()
        if not data or seq < self.next_up:
            return ST_OK            # registro, o un reintento de algo ya entregado
        if seq not in self.up_pending:
            if self.up_pending_bytes + len(data) > UP_PENDING_MAX:
                return ST_ERR
            self.up_pending[seq] = data
            self.up_pending_bytes += len(data)
        wrote = False
        while self.next_up in self.up_pending:
            chunk = self.up_pending.pop(self.next_up)
            self.up_pending_bytes -= len(chunk)
            self.next_up += 1
            self.writer.write(chunk)
            wrote = True
        if wrote:
            try:
                await self.writer.drain()
            except (ConnectionError, OSError):
                return ST_ERR
        return ST_OK

    async def batch(self, base: int, chunk: int, count: int, wait: float):
        """Devuelve las `count` casillas desde `base`.

        Los datos se asignan siempre a la primera casilla libre (en orden), igual que en la version 1.
        Si la ventana aun no esta asignada y no hay datos pendientes, espera hasta `wait` segundos a que
        lleguen (o a que otra peticion asigne esta ventana) en vez de responder vacio al instante.
        """
        self.last = time.monotonic()
        end = base + count
        if wait > 0 and end > self.filled and not self.backlog and not self.closed:
            async with self.cond:
                try:
                    await asyncio.wait_for(self.cond.wait_for(
                        lambda: self.filled >= end or self.closed or len(self.backlog) > 0), wait)
                except asyncio.TimeoutError:
                    pass
            self.last = time.monotonic()
        changed = False
        while self.filled < end:
            take = min(chunk, len(self.backlog))
            self.slots[self.filled] = bytes(self.backlog[:take])
            del self.backlog[:take]
            self.filled += 1
            changed = True
        if changed:
            await self._wake()
        return [self.slots.get(base + i, b"") for i in range(count)]

    def ack(self, seq: int):
        self.last = time.monotonic()
        for k in [k for k in self.slots if k <= seq]:
            del self.slots[k]

    async def close(self):
        self.task.cancel()
        try:
            self.writer.close()
            await self.writer.wait_closed()
        except Exception:
            pass


# ---------------------------------------------------------------- servidor

class Server:
    def __init__(self, backend, max_sessions, idle, max_per_ip, poll_wait=0.8):
        self.poll_wait = poll_wait
        self.backend = backend
        self.max_sessions = max_sessions
        self.idle = idle
        self.max_per_ip = max_per_ip
        self.sessions = {}
        self.creating = {}
        self.per_ip = {}

    async def get_session(self, sid, ip=None, create=False):
        s = self.sessions.get(sid)
        if s or not create:
            return s
        fut = self.creating.get(sid)
        if fut is None:
            if len(self.sessions) + len(self.creating) >= self.max_sessions:
                log.warning("limite de sesiones alcanzado")
                return None
            if self.per_ip.get(ip, 0) >= self.max_per_ip:
                log.warning("limite de sesiones por IP alcanzado")
                return None
            fut = asyncio.ensure_future(self._create(sid, ip))
            self.creating[sid] = fut
        try:
            return await fut
        finally:
            self.creating.pop(sid, None)

    async def _create(self, sid, ip):
        try:
            r, w = await asyncio.wait_for(asyncio.open_connection(*self.backend), 5)
        except (OSError, asyncio.TimeoutError) as e:
            log.warning("no se pudo conectar al destino: %s", e)
            return None
        s = Session(sid, r, w)
        s.ip = ip
        self.per_ip[ip] = self.per_ip.get(ip, 0) + 1
        self.sessions[sid] = s
        log.info("sesion abierta (%d activas)", len(self.sessions))
        return s

    async def drop(self, sid):
        s = self.sessions.pop(sid, None)
        if s:
            left = self.per_ip.get(s.ip, 1) - 1
            if left > 0:
                self.per_ip[s.ip] = left
            else:
                self.per_ip.pop(s.ip, None)
            await s.close()
            log.info("sesion cerrada (%d activas)", len(self.sessions))

    async def janitor(self):
        while True:
            await asyncio.sleep(min(15, max(1, self.idle // 2)))
            now = time.monotonic()
            for sid, s in list(self.sessions.items()):
                if now - s.last > self.idle:
                    await self.drop(sid)

    # ---- una peticion por conexion

    async def handle(self, reader, writer):
        try:
            sock = writer.get_extra_info("socket")
            if sock is not None:
                try:
                    import socket as _s
                    sock.setsockopt(_s.SOL_SOCKET, _s.SO_KEEPALIVE, 1)
                    for name, val in (("TCP_KEEPIDLE", 60), ("TCP_KEEPINTVL", 15), ("TCP_KEEPCNT", 4)):
                        if hasattr(_s, name):
                            sock.setsockopt(_s.IPPROTO_TCP, getattr(_s, name), val)
                except OSError:
                    pass
            peer = writer.get_extra_info("peername")
            ip = peer[0] if peer else None
            for n_req in range(MAX_REQUESTS_PER_CONN):
                # la primera peticion debe llegar enseguida; las siguientes pueden tardar mas
                wait = REQUEST_TIMEOUT if n_req == 0 else KEEPALIVE_IDLE
                head = await asyncio.wait_for(reader.readexactly(HEADER), wait)
                mode = head[0]
                sid = bytes(head[1:17])
                seq = int.from_bytes(head[17:25], "big")
                n = int.from_bytes(head[25:29], "big")
                if n > MAX_REQUEST:
                    writer.write(reply(ST_ERR))
                    await writer.drain()
                    return
                data = await asyncio.wait_for(reader.readexactly(n), REQUEST_TIMEOUT) if n else b""
                out = await self.dispatch(mode, sid, seq, data, ip)
                writer.write(out)
                await writer.drain()
        except (asyncio.IncompleteReadError, asyncio.TimeoutError, ConnectionError, OSError):
            pass
        except Exception:
            log.exception("error atendiendo una peticion")
        finally:
            try:
                writer.close()
            except Exception:
                pass

    async def dispatch(self, mode, sid, seq, data, ip=None) -> bytes:
        if mode == MODE_PROBE:
            return self.probe(sid, data)

        # Solo la subida (el registro de la app) puede abrir una sesion nueva; lote y ack
        # exigen una sesion existente. Asi la basura no gasta conexiones al destino.
        if mode == MODE_UPLOAD:
            s = await self.get_session(sid, ip, create=True)
            if s is None:
                return reply(ST_ERR)
            return reply(await s.upload(seq, crypt(data, sid, MODE_UPLOAD, seq, False)))

        if mode == MODE_BATCH:
            s = self.sessions.get(sid)
            req = crypt(data, sid, MODE_BATCH, seq, False)
            if s is None or len(req) < 6:
                return reply(ST_ERR)
            chunk = struct.unpack(">i", req[:4])[0]
            count = req[5]
            if not (1 <= chunk <= MAX_CHUNK) or not (1 <= count <= MAX_BATCH):
                return reply(ST_ERR)
            out = bytearray()
            for i, raw in enumerate(await s.batch(seq, chunk, count, self.poll_wait)):
                enc = crypt(raw, sid, MODE_BATCH, seq + i, True)
                out += reply(ST_DATA, struct.pack(">I", len(enc)) + enc)
            return bytes(out)

        if mode == MODE_ACK:
            s = self.sessions.get(sid)
            if s is None:
                return reply(ST_ERR)
            s.ack(seq)
            return reply(ST_OK)

        return reply(ST_ERR)

    @staticmethod
    def probe(sid, data) -> bytes:
        plain = crypt(data, sid, MODE_PROBE, 0, False)
        if len(plain) < 10 or plain[:4] != b"BHP1" or plain[4] != 1:
            return reply(ST_ERR)
        mode = plain[5]
        param = struct.unpack(">i", plain[6:10])[0]
        length = max(10, param) if mode == MODE_DOWNLOAD else 10
        if length > MAX_PROBE_REPLY:
            return reply(ST_ERR)
        body = bytearray(length)
        body[0:4] = b"BHP1"
        body[4] = 1
        body[5] = mode
        body[6:10] = struct.pack(">i", param)
        for i in range(10, length):
            body[i] = (i * 31) & 0xFF
        return reply(ST_OK, crypt(bytes(body), sid, MODE_PROBE, 0, True))


def probe_client(target: str) -> bool:
    """Autoprueba: hace el sondeo BHP1 igual que la app y comprueba la respuesta."""
    import os
    import socket
    host, _, port = target.rpartition(":")
    try:
        sid = os.urandom(16)
        plain = bytearray(10)
        plain[0:4] = b"BHP1"
        plain[4] = 1
        plain[5] = MODE_BATCH
        plain[6:10] = struct.pack(">i", 8)
        data = crypt(bytes(plain), sid, MODE_PROBE, 0, False)
        with socket.create_connection((host or "127.0.0.1", int(port)), timeout=5) as sk:
            sk.sendall(bytes([MODE_PROBE]) + sid + (0).to_bytes(8, "big") + struct.pack(">I", len(data)) + data)
            sk.settimeout(5)
            buf = b""
            while len(buf) < 5:
                chunk = sk.recv(5 - len(buf))
                if not chunk:
                    break
                buf += chunk
            if len(buf) < 5 or buf[0] != ST_OK:
                print("el servidor respondio con error o no respondio")
                return False
            n = struct.unpack(">I", buf[1:5])[0]
            body = b""
            while len(body) < n:
                chunk = sk.recv(n - len(body))
                if not chunk:
                    break
                body += chunk
        resp = crypt(body, sid, MODE_PROBE, 0, True)
        good = (len(resp) == 10 and resp[:4] == b"BHP1" and resp[4] == 1 and resp[5] == MODE_BATCH
                and struct.unpack(">i", resp[6:10])[0] == 8)
        print("sondeo BHP1: OK" if good else "sondeo BHP1: respuesta invalida")
        return good
    except OSError as e:
        print("no se pudo conectar:", e)
        return False


async def main_async(args):
    host, _, port = args.backend.rpartition(":")
    srv = Server((host or "127.0.0.1", int(port)), args.max_sessions, args.idle, args.max_per_ip,
                 max(0, args.poll_wait_ms) / 1000.0)
    server = await asyncio.start_server(srv.handle, args.listen, args.port, backlog=1024)
    asyncio.ensure_future(srv.janitor())
    log.info("BHTTP escuchando en %s:%d -> %s", args.listen, args.port, args.backend)

    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:
            pass
    async with server:
        await stop.wait()
    for sid in list(srv.sessions):
        await srv.drop(sid)


def main():
    ap = argparse.ArgumentParser(description="Servidor BHTTP propio para la app Conecta")
    ap.add_argument("--listen", default="0.0.0.0", help="direccion donde escucha (por defecto 0.0.0.0)")
    ap.add_argument("--port", type=int, help="puerto TCP donde escucha la app")
    ap.add_argument("--probe", metavar="HOST:PUERTO", help="autoprueba: hace el sondeo BHP1 contra un servidor en marcha y sale")
    ap.add_argument("--poll-wait-ms", type=int, default=800,
                    help="milisegundos que espera datos antes de responder vacio (0 = no esperar; por defecto 800)")
    ap.add_argument("--backend", default="127.0.0.1:22", help="destino al que se reenvia (por defecto 127.0.0.1:22)")
    ap.add_argument("--max-sessions", type=int, default=128, help="sesiones simultaneas maximas")
    ap.add_argument("--max-per-ip", type=int, default=64, help="sesiones simultaneas maximas por IP de origen")
    ap.add_argument("--idle", type=int, default=120, help="segundos sin actividad para cerrar una sesion")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args()
    if args.probe:
        raise SystemExit(0 if probe_client(args.probe) else 1)
    if not args.port:
        ap.error("falta --port")
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    asyncio.run(main_async(args))


if __name__ == "__main__":
    main()
BHTTP_SERVER_PY_EOF
  chmod 755 "$APP_DIR"; chmod 644 "$SERVER"
  python3 -c 'import ast,sys; ast.parse(open(sys.argv[1]).read())' "$SERVER" || { fail "El archivo del servidor quedo danado."; return 1; }
}

write_unit(){
  local py; py="$(command -v python3)"
  mkdir -p "$(dirname "$UNIT_FILE")"
  cat > "$UNIT_FILE" <<'UNIT_EOF'
[Unit]
Description=__BRAND__ BHTTP (puerto %i)
After=network-online.target ssh.service sshd.service
Wants=network-online.target

[Service]
Type=simple
EnvironmentFile=__CONFIG__
ExecStart=__LAUNCHER__ __SERVER__ --listen 0.0.0.0 --port %i --backend ${BACKEND} --poll-wait-ms ${POLL_WAIT_MS} --max-sessions ${MAX_SESSIONS} --max-per-ip ${MAX_PER_IP} --idle ${IDLE}
Restart=always
RestartSec=1
LimitNOFILE=65535
# Sin privilegios y con el sistema protegido
DynamicUser=yes
NoNewPrivileges=yes
ProtectSystem=strict
ProtectHome=yes
PrivateTmp=yes
# Solo hace falta para puertos menores a 1024
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE

[Install]
WantedBy=multi-user.target
UNIT_EOF
  ln -sfn "$py" "$LAUNCHER"
  sed -i -e "s|__BRAND__|$BRAND|" -e "s|__CONFIG__|${CONFIG#"$ROOT"}|" \
         -e "s|__LAUNCHER__|${LAUNCHER#"$ROOT"}|" -e "s|__SERVER__|${SERVER#"$ROOT"}|" "$UNIT_FILE"
  systemctl daemon-reload
}

install_self(){
  local src="${BASH_SOURCE[0]:-$0}"
  if [ -f "$src" ] && [ -r "$src" ]; then
    mkdir -p "$(dirname "$SELF_DEST")" "$(dirname "$BIN_LINK")"
    if [ "$(readlink -f "$src")" != "$(readlink -f "$SELF_DEST" 2>/dev/null)" ]; then cp "$src" "$SELF_DEST"; fi
    chmod 755 "$SELF_DEST"; ln -sfn "$SELF_DEST" "$BIN_LINK"
    ok "Comando instalado: sudo $CMD"
  else
    warn "No instale el comando '$CMD' (ejecuta el archivo guardado en disco, no por pipe)."
  fi
}

do_install(){
  need_root; ensure_python || return 1
  local first="${1:-}" p
  cfg_init; write_server || return 1; write_unit; install_self
  for p in $(ports_list); do systemctl enable --now "$(unit_name "$p")" >/dev/null 2>&1; systemctl restart "$(unit_name "$p")"; done
  ok "Servidor BHTTP v2 instalado/actualizado."
  if [ -z "$(ports_list)" ]; then
    if [ -n "$first" ]; then add_port "$first"
    elif [ -t 0 ]; then ask p "Puerto TCP para BHTTP, el que pondras en la app [8080]: "; add_port "${p:-8080}"
    else info "No hay puertos: usa  $CMD add-port NUMERO"; fi
  fi
  echo; selftest
}

# ---------------------------------------------------------------- puertos: agregar / quitar
add_port(){
  need_root; local p="${1:-}"
  [ -n "$p" ] || ask p "Puerto TCP a abrir: "
  valid_port "$p" || { fail "Puerto invalido."; return 1; }
  [ -f "$SERVER" ] || { fail "Primero instala (opcion 1)."; return 1; }
  if ports_has "$p"; then info "El puerto $p ya esta configurado."; return 0; fi
  if listening "$p"; then fail "El puerto $p ya esta ocupado por otro servicio. No toque nada."; ss -lntp 2>/dev/null | awk -v p=":$p" '$4 ~ p"$"'; return 1; fi
  cfg_init; ports_add "$p"
  systemctl enable --now "$(unit_name "$p")" >/dev/null 2>&1
  sleep 1
  if listening "$p"; then
    ok "Puerto BHTTP :$p activo y con arranque automatico."
    fw_open "$p"
    if python3 "$SERVER" --probe "127.0.0.1:$p" >/dev/null 2>&1; then ok "Sondeo BHP1 en :$p: OK"; else warn "El puerto escucha pero el sondeo BHP1 fallo: mira los logs (opcion 10)."; fi
  else
    fail "El puerto :$p no quedo activo. Revisa: journalctl -u $(unit_name "$p")"
    ports_del "$p"; return 1
  fi
}
remove_port(){
  need_root; local p="${1:-}"
  [ -n "$(ports_list)" ] || { info "No hay puertos configurados."; return 0; }
  [ -n "$p" ] || { echo "Puertos actuales: $(ports_list | tr '\n' ' ')"; ask p "Puerto a cerrar: "; }
  ports_has "$p" || { fail "El puerto $p no es uno de los de BHTTP."; return 1; }
  confirm_word CERRAR "Se cerrara el puerto $p." || { info "Sin cambios."; return 0; }
  systemctl disable --now "$(unit_name "$p")" >/dev/null 2>&1
  ports_del "$p"; fw_close "$p"
  ok "Puerto $p cerrado y quitado del arranque."
}

# ---------------------------------------------------------------- control
each_port(){ local p; for p in $(ports_list); do "$@" "$p"; done; }
restart_all(){
  local p n=0; for p in $(ports_list); do systemctl restart "$(unit_name "$p")"; n=$((n+1)); done
  [ "$n" -gt 0 ] && ok "Reiniciados $n puerto(s)." || info "No hay puertos configurados."
}
start_all(){ local p n=0; for p in $(ports_list); do systemctl enable --now "$(unit_name "$p")" >/dev/null 2>&1; n=$((n+1)); done; [ "$n" -gt 0 ] && ok "Iniciados $n puerto(s)." || info "No hay puertos configurados."; }
stop_all(){ local p n=0; for p in $(ports_list); do systemctl stop "$(unit_name "$p")"; n=$((n+1)); done; [ "$n" -gt 0 ] && warn "Detenidos. Siguen con arranque automatico." || info "No hay puertos configurados."; }
show_logs(){
  local p n=0
  for p in $(ports_list); do echo "===== :$p ====="; journalctl -u "$(unit_name "$p")" -n 60 --no-pager 2>/dev/null || true; n=$((n+1)); done
  [ "$n" -gt 0 ] || info "No hay puertos configurados."
}
set_backend(){
  need_root; local p="${1:-}"
  [ -n "$p" ] || ask p "Puerto del SSH (destino local) [$(backend_port)]: "
  p="${p:-$(backend_port)}"
  valid_port "$p" || { fail "Puerto invalido."; return 1; }
  cfg_set BACKEND "127.0.0.1:$p"; ok "Destino: 127.0.0.1:$p"
  listening "$p" || warn "No veo nada escuchando en :$p."
  restart_all
}
set_value(){            # set_value CLAVE min max "texto"
  need_root; local k="$1" min="$2" max="$3" label="$4" v="${5:-}"
  [ -n "$v" ] || ask v "$label [$(cfg_get "$k")]: "
  v="${v:-$(cfg_get "$k")}"
  valid_num "$min" "$v" "$max" || { fail "Valor invalido (entre $min y $max)."; return 1; }
  cfg_set "$k" "$v"; ok "$label: $v"; restart_all
}

# ---------------------------------------------------------------- ajuste de red (opcional y reversible)
tune_list(){
cat <<'TUNE_EOF'
net.core.default_qdisc|fq
net.ipv4.tcp_congestion_control|bbr
net.core.rmem_max|16777216
net.core.wmem_max|16777216
net.ipv4.tcp_rmem|4096 131072 16777216
net.ipv4.tcp_wmem|4096 131072 16777216
net.core.somaxconn|4096
net.ipv4.tcp_slow_start_after_idle|0
net.ipv4.tcp_mtu_probing|1
TUNE_EOF
}
tuning_on(){
  need_root
  have sysctl || { fail "No encontre sysctl."; return 1; }
  local line k v cur first=0 avail
  [ -s "$SYSCTL_PREV" ] || first=1
  mkdir -p "$CONF_DIR" "$(dirname "$SYSCTL_FILE")"
  [ "$first" -eq 1 ] && : > "$SYSCTL_PREV"
  printf '# %s BHTTP - ajustes de red opcionales (se quitan desde el menu: %s)\n' "$BRAND" "$CMD" > "$SYSCTL_FILE"
  have modprobe && modprobe tcp_bbr >/dev/null 2>&1 || true
  avail="$(sysctl -n net.ipv4.tcp_available_congestion_control 2>/dev/null || true)"
  while IFS='|' read -r k v; do
    [ -n "$k" ] || continue
    cur="$(sysctl -n "$k" 2>/dev/null)" || continue          # la clave no existe en este kernel
    if [ "$k" = "net.ipv4.tcp_congestion_control" ] && ! printf '%s' "$avail" | grep -qw bbr; then
      warn "Este kernel no ofrece BBR: se omite."; continue
    fi
    [ "$first" -eq 1 ] && printf '%s|%s\n' "$k" "$cur" >> "$SYSCTL_PREV"
    printf '%s = %s\n' "$k" "$v" >> "$SYSCTL_FILE"
    sysctl -w "$k=$v" >/dev/null 2>&1 || true
  done < <(tune_list)
  ok "Ajuste de red aplicado ($(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null || echo '?'))."
  info "Afecta a todo el servidor. Los valores anteriores quedaron guardados para poder revertirlo."
}
tuning_off(){
  need_root
  local k v
  if [ -s "$SYSCTL_PREV" ]; then
    while IFS='|' read -r k v; do [ -n "$k" ] && sysctl -w "$k=$v" >/dev/null 2>&1 || true; done < "$SYSCTL_PREV"
    ok "Valores anteriores restaurados."
  fi
  rm -f "$SYSCTL_FILE" "$SYSCTL_PREV"
  ok "Ajuste de red quitado."
}
tuning_state(){ [ -f "$SYSCTL_FILE" ] && echo "ACTIVO" || echo "apagado"; }

# ---------------------------------------------------------------- estado y autoprueba
show_status(){
  local p inst="NO"
  [ -f "$SERVER" ] && inst="SI"
  echo "================ $BRAND BHTTP v$MANAGER_VERSION ================"
  echo "Servidor instalado : $inst"
  echo "Destino (SSH)      : $(cfg_get BACKEND) ($(listening "$(backend_port)" && echo escuchando || echo 'NO escucha'))"
  echo "Espera de datos    : $(cfg_get POLL_WAIT_MS) ms | Max sesiones: $(cfg_get MAX_SESSIONS) | Max por IP: $(cfg_get MAX_PER_IP) | Inactividad: $(cfg_get IDLE) s"
  echo "Ajuste de red      : $(tuning_state) | congestion TCP: $(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null || echo '?')"
  echo "Puertos BHTTP      :"
  if [ -z "$(ports_list)" ]; then echo "  (ninguno) usa 'agregar puerto'"; fi
  for p in $(ports_list); do
    printf '  %-6s | %-9s | arranque: %-3s | conexiones: %s\n' "$p" \
      "$(systemctl is-active "$(unit_name "$p")" 2>/dev/null || true)" \
      "$(systemctl is-enabled --quiet "$(unit_name "$p")" 2>/dev/null && echo si || echo no)" "$(conn_count "$p")"
  done
}
selftest(){
  local fails=0 p
  echo "===== AUTOPRUEBA $BRAND BHTTP ====="
  if have python3; then ok "python3 $(python3 -V 2>&1 | awk '{print $2}')"; else fail "falta python3"; fails=$((fails+1)); fi
  if [ -f "$SERVER" ] && python3 -c 'import ast,sys; ast.parse(open(sys.argv[1]).read())' "$SERVER" 2>/dev/null; then ok "servidor instalado y sin errores de sintaxis"
  else fail "servidor no instalado o danado"; fails=$((fails+1)); fi
  if [ -L "$LAUNCHER" ] && [ -x "$LAUNCHER" ]; then ok "lanzador ${NAME}-server presente"; else fail "falta el lanzador $LAUNCHER (reinstala, opcion 1)"; fails=$((fails+1)); fi
  if listening "$(backend_port)"; then ok "el destino SSH escucha en :$(backend_port)"
  else fail "nada escucha en el destino :$(backend_port) (revisa el puerto del SSH, opcion 5)"; fails=$((fails+1)); fi
  if [ -z "$(ports_list)" ]; then info "Aun no hay puertos BHTTP: usa 'agregar puerto'."; return $(( fails > 0 )); fi
  for p in $(ports_list); do
    if systemctl is-enabled --quiet "$(unit_name "$p")" 2>/dev/null; then ok ":$p arranca con el sistema"; else fail ":$p NO arranca con el sistema"; fails=$((fails+1)); fi
    if systemctl is-active --quiet "$(unit_name "$p")" 2>/dev/null; then ok ":$p esta activo"; else fail ":$p NO esta activo"; fails=$((fails+1)); continue; fi
    if listening "$p"; then ok ":$p escucha"; else fail ":$p no escucha"; fails=$((fails+1)); continue; fi
    if python3 "$SERVER" --probe "127.0.0.1:$p" >/dev/null 2>&1; then ok ":$p responde al sondeo BHP1"; else fail ":$p no responde al sondeo BHP1"; fails=$((fails+1)); fi
  done
  if [ "$fails" -eq 0 ]; then ok "TODO OK"; else fail "$fails problema(s)"; fi
  return $(( fails > 0 ))
}
rollback(){
  need_root
  [ -f "$SERVER.prev" ] || { fail "No hay version anterior guardada."; return 1; }
  cp -a "$SERVER" "$SERVER.tmp" && cp -a "$SERVER.prev" "$SERVER" && mv "$SERVER.tmp" "$SERVER.prev"
  restart_all; ok "Version anterior del servidor restaurada."
}

uninstall_all(){
  need_root
  warn "Esto elimina SOLO $BRAND BHTTP (no toca SSH ni tus otros servicios)."
  confirm_word BHTTP "Desinstalar." || { info "Sin cambios."; return 0; }
  local p
  for p in $(ports_list); do systemctl disable --now "$(unit_name "$p")" >/dev/null 2>&1; fw_close "$p"; done
  [ -f "$SYSCTL_FILE" ] && tuning_off
  rm -f "$UNIT_FILE" "$BIN_LINK" "$SELF_DEST" "$LAUNCHER"
  rm -rf "$APP_DIR" "$CONF_DIR"
  systemctl daemon-reload >/dev/null 2>&1 || true
  ok "$BRAND BHTTP desinstalado."
}

# ---------------------------------------------------------------- menu
menu(){
  need_root
  while true; do
    clear 2>/dev/null || true
    show_status; echo
    echo " 1) Instalar / actualizar"
    echo " 2) Estado"
    echo " 3) Autoprueba"
    echo " 4) Agregar puerto BHTTP"
    echo " 5) Cambiar puerto del SSH (destino)"
    echo " 6) Cambiar espera de datos (ms)"
    echo " 7) Cambiar max. sesiones / por IP / inactividad"
    echo " 8) Ajuste de red (BBR y buffers): activar / quitar"
    echo " 9) Reiniciar     11) Iniciar     12) Detener"
    echo "10) Ver logs"
    echo "13) Cerrar un puerto BHTTP"
    echo "14) Volver a la version anterior del servidor"
    echo "15) DESINSTALAR"
    echo " 0) Salir"
    echo
    local op; ask op "Opcion: "
    case "$op" in
      1) do_install; pause;;
      2) show_status; pause;;
      3) selftest; pause;;
      4) add_port; pause;;
      5) set_backend; pause;;
      6) set_value POLL_WAIT_MS 0 5000 "Espera de datos (ms, 0 = no esperar)"; pause;;
      7) set_value MAX_SESSIONS 1 32768 "Max. sesiones"; set_value MAX_PER_IP 1 4096 "Max. sesiones por IP"; set_value IDLE 10 86400 "Segundos de inactividad"; pause;;
      8) if [ -f "$SYSCTL_FILE" ]; then tuning_off; else tuning_on; fi; pause;;
      9) restart_all; pause;;
      10) show_logs; pause;;
      11) start_all; pause;;
      12) stop_all; pause;;
      13) remove_port; pause;;
      14) rollback; pause;;
      15) uninstall_all; pause;;
      0) exit 0;;
      *) echo "Opcion invalida"; sleep 1;;
    esac
  done
}

usage(){
cat <<EOF
$BRAND BHTTP - administrador v$MANAGER_VERSION
  sudo bash install_el_tioNel.sh              abre el menu
  sudo $CMD install [--port N]        instala o actualiza (y abre el puerto N)
  sudo $CMD status | selftest | ports
  sudo $CMD add-port N | remove-port N
  sudo $CMD set-backend N             puerto del SSH local (destino)
  sudo $CMD set-poll MS               espera de datos antes de responder vacio
  sudo $CMD restart | start | stop | logs
  sudo $CMD tuning-on | tuning-off    ajuste de red opcional (BBR y buffers)
  sudo $CMD rollback | uninstall
EOF
}

main(){
  local a="${1:-menu}"; shift || true
  case "$a" in
    menu|"") menu;;
    install) if [ "${1:-}" = "--port" ]; then do_install "${2:-}"; else do_install "${1:-}"; fi;;
    status) show_status;;
    selftest|test) selftest;;
    ports) ports_list;;
    add-port) add_port "${1:-}";;
    remove-port) remove_port "${1:-}";;
    set-backend) set_backend "${1:-}";;
    set-poll) set_value POLL_WAIT_MS 0 5000 "Espera de datos (ms)" "${1:-}";;
    restart) need_root; restart_all;;
    start) need_root; start_all;;
    stop) need_root; stop_all;;
    logs) show_logs;;
    tuning-on) tuning_on;;
    tuning-off) tuning_off;;
    rollback) rollback;;
    uninstall) uninstall_all;;
    help|-h|--help) usage;;
    *) usage; exit 2;;
  esac
}

main "$@"
