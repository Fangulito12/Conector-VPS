#!/usr/bin/env python3
"""Genera el archivo de licencia de IA para UN dispositivo (cifrado con su HWID).

Uso:
  pip install cryptography
  python3 generar_licencia_ia.py --hwid hwXXXXXXXXXXXXXXXX --max 10 --dias 30

La llave de Gemini se toma de la variable GEMINI_API_KEY o se pide por teclado (no queda en el
historial). El cliente carga el archivo resultante en la app libre con "Activar IA con archivo".
"""
import argparse, base64, getpass, hashlib, json, os, re, sys, time

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

PREFIX = "CONECTAIA1:"
AAD = b"CONECTAIA1"
ITER = 150_000


def crear(hwid: str, key: str, dias: int, maximo: int) -> str:
    payload = {
        "key": key,
        "exp": int(time.time() + dias * 86400) if dias > 0 else 0,
        "max": maximo,
        "id": os.urandom(8).hex(),
    }
    salt, iv = os.urandom(16), os.urandom(12)
    k = hashlib.pbkdf2_hmac("sha256", hwid.strip().lower().encode(), salt, ITER, 32)
    ct = AESGCM(k).encrypt(iv, json.dumps(payload).encode(), AAD)   # cifrado + etiqueta, igual que Java
    return PREFIX + base64.b64encode(salt + iv + ct).decode()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--hwid", required=True, help="HWID que el cliente ve en la app (empieza con hw)")
    ap.add_argument("--max", type=int, default=10, help="consultas permitidas (0 = sin limite). Por defecto 10")
    ap.add_argument("--dias", type=int, default=0, help="dias de validez (0 = no vence)")
    ap.add_argument("--salida", help="archivo de salida (por defecto licencia_<hwid>.conectaia)")
    a = ap.parse_args()

    key = os.environ.get("GEMINI_API_KEY") or getpass.getpass("Llave de Gemini: ")
    key = key.strip()
    if not re.fullmatch(r"[A-Za-z0-9_\-]{20,100}", key):
        sys.exit("La llave no parece valida (sin espacios ni comillas).")

    out = a.salida or f"licencia_{a.hwid.strip().lower()[-8:]}.conectaia"
    with open(out, "w", encoding="utf-8") as f:
        f.write(crear(a.hwid, key, a.dias, a.max) + "\n")
    print(f"Listo: {out}  (consultas: {a.max or 'sin limite'}, dias: {a.dias or 'sin vencimiento'})")


if __name__ == "__main__":
    main()
