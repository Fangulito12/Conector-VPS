# Puente JNI del túnel nativo: el nombre de esta clase y de sus métodos native debe quedar
# EXACTO, porque la librería hev-socks5-tunnel los busca por nombre. Si R8 los renombra,
# el túnel deja de arrancar.
-keep class hev.htproxy.TProxyService { *; }

# Librería SSH (Trilead): evita que R8 rompa su selección interna de algoritmos.
-keep class com.trilead.ssh2.** { *; }
-dontwarn com.trilead.**
-dontwarn org.bouncycastle.**
-dontwarn javax.naming.**

# org.json ya viene con Android; no hace falta procesarlo.
-dontwarn org.json.**

# La librería SSH trae por dentro criptografía de Google (Tink), que a su vez espera anotaciones
# que solo se usan al compilar esa librería (nunca en tiempo de ejecución). Sin esta línea, R8
# detiene la compilación reclamándolas como "clases faltantes" aunque no hagan falta para nada.
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn com.google.crypto.tink.**
-dontwarn org.checkerframework.**
-dontwarn com.google.j2objc.annotations.**
-dontwarn edu.umd.cs.findbugs.annotations.**

-keepattributes *Annotation*, Signature, InnerClasses
