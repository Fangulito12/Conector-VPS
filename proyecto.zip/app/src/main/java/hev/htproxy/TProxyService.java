package hev.htproxy;

/**
 * Puente JNI hacia hev-socks5-tunnel. El nombre del paquete, de la clase y las FIRMAS de los
 * métodos deben coincidir exactamente con los de la librería nativa (si no, el túnel no arranca).
 */
public final class TProxyService {
    static { System.loadLibrary("hev-socks5-tunnel"); }

    public static native boolean TProxyStartService(String configPath, int fd);
    public static native boolean TProxyStopService();
    public static native boolean TProxyIsRunning();
    public static native long[] TProxyGetStats();

    private TProxyService() {}
}
