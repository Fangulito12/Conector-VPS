package com.mivpn.app;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Convierte un enlace (vmess://, vless://, trojan://, ss://) o un JSON de Xray en la configuración
 * que arranca el motor V2Ray. El motor escucha como SOCKS5 solo en 127.0.0.1 y el resto del túnel
 * (VPN de Android + hev-socks5-tunnel) es el mismo que usa el modo SSH.
 *
 * Si el servidor viene como dominio, se resuelve aquí (con el DNS de Android) y se pone la IP en la
 * configuración, porque el resolvedor de Go no funciona en Android. El nombre original se conserva
 * para el SNI y la cabecera Host.
 */
final class V2rayConfig {

    static final class Result {
        String json;
        /** Servidor y credenciales: se ocultan del registro. */
        final List<String> secrets = new ArrayList<>();
    }

    private V2rayConfig() { }

    /** @param resolve true para resolver el dominio del servidor (hace red: no llamar desde el hilo de la interfaz). */
    static Result build(String input, int socksPort, boolean resolve) throws Exception {
        String s = input == null ? "" : input.trim();
        if (s.isEmpty()) throw new IllegalArgumentException("Pega un enlace o una configuraci\u00f3n");
        Result r = new Result();
        JSONObject root;
        if (s.startsWith("{")) {
            root = new JSONObject(s);
            JSONArray outs = root.optJSONArray("outbounds");
            if (outs == null || outs.length() == 0) {
                throw new IllegalArgumentException("El JSON no tiene \"outbounds\"");
            }
            for (int i = 0; i < outs.length(); i++) {
                JSONObject ob = outs.optJSONObject(i);
                if (ob == null) continue;
                String h = pin(ob, resolve);
                if (h != null && !h.isEmpty()) r.secrets.add(h);
            }
            if (!root.has("log")) root.put("log", new JSONObject().put("loglevel", "warning"));
        } else {
            JSONObject proxy = fromLink(firstLink(s), r);
            String h = pin(proxy, resolve);
            if (h != null && !h.isEmpty() && !r.secrets.contains(h)) r.secrets.add(h);
            root = new JSONObject();
            root.put("log", new JSONObject().put("loglevel", "warning"));
            root.put("outbounds", new JSONArray()
                    .put(proxy)
                    .put(new JSONObject().put("tag", "direct").put("protocol", "freedom")));
        }
        // La entrada siempre es la nuestra: SOCKS5 local sin abrir nada m\u00e1s.
        JSONObject in = new JSONObject();
        in.put("tag", "socks-in");
        in.put("listen", "127.0.0.1");
        in.put("port", socksPort);
        in.put("protocol", "socks");
        in.put("settings", new JSONObject().put("auth", "noauth").put("udp", false));
        root.put("inbounds", new JSONArray().put(in));
        r.json = root.toString();
        return r;
    }

    // ------------------------------------------------------------------ enlaces

    private static String firstLink(String s) {
        for (String tok : s.split("\\s+")) {
            String low = tok.toLowerCase(Locale.ROOT);
            if (low.startsWith("vmess://") || low.startsWith("vless://")
                    || low.startsWith("trojan://") || low.startsWith("ss://")
                    || low.startsWith("hysteria2://") || low.startsWith("hy2://")
                    || low.startsWith("hysteria://") || low.startsWith("hy://")) return tok;
        }
        throw new IllegalArgumentException("Formato no reconocido: usa vmess://, vless://, trojan://, ss://, hysteria2:// o un JSON");
    }

    private static JSONObject fromLink(String link, Result r) throws Exception {
        String low = link.toLowerCase(Locale.ROOT);
        if (low.startsWith("vmess://")) return vmess(link, r);
        if (low.startsWith("vless://")) return vless(link, r);
        if (low.startsWith("trojan://")) return trojan(link, r);
        if (low.startsWith("hysteria2://") || low.startsWith("hy2://")) return hysteria2(link, r);
        if (low.startsWith("hysteria://") || low.startsWith("hy://")) {
            throw new IllegalArgumentException("Hysteria 1 no est\u00e1 soportado: usa Hysteria 2 (hysteria2://)");
        }
        return shadowsocks(link, r);
    }

    private static JSONObject vmess(String link, Result r) throws Exception {
        String b = link.substring(8).trim();
        int hash = b.indexOf('#');
        if (hash >= 0) b = b.substring(0, hash);
        JSONObject j = new JSONObject(new String(b64(b), StandardCharsets.UTF_8));
        String add = j.optString("add", "").trim();
        String id = j.optString("id", "").trim();
        int port = toInt(j.optString("port", ""), 443);
        if (add.isEmpty() || id.isEmpty()) throw new IllegalArgumentException("El enlace vmess no tiene servidor o id");
        checkPort(port);
        String scy = j.optString("scy", "").trim();
        JSONObject user = new JSONObject()
                .put("id", id)
                .put("alterId", toInt(j.optString("aid", ""), 0))
                .put("security", scy.isEmpty() ? "auto" : scy);
        String net = j.optString("net", "tcp");
        String path = j.optString("path", "");
        JSONObject ss = stream(net, "tls".equalsIgnoreCase(j.optString("tls", "")) ? "tls" : "none",
                j.optString("type", ""), j.optString("host", ""), path,
                j.optString("sni", ""), j.optString("alpn", ""), j.optString("fp", ""),
                "", "", "", path, "");
        r.secrets.add(add);
        r.secrets.add(id);
        return outbound("vmess", new JSONObject().put("vnext", new JSONArray().put(new JSONObject()
                .put("address", add).put("port", port).put("users", new JSONArray().put(user)))), ss);
    }

    private static JSONObject vless(String link, Result r) throws Exception {
        Link l = parse(link);
        if (l.user.isEmpty()) throw new IllegalArgumentException("El enlace vless no tiene id");
        String sec = l.q("security", "none").toLowerCase(Locale.ROOT);
        JSONObject user = new JSONObject()
                .put("id", l.user)
                .put("encryption", l.q("encryption", "none"));
        String flow = l.q("flow", "");
        if (!flow.isEmpty()) user.put("flow", flow);
        JSONObject ss = stream(l.q("type", "tcp"), sec, l.q("headerType", ""), l.q("host", ""),
                l.q("path", ""), l.q("sni", ""), l.q("alpn", ""), l.q("fp", ""),
                l.q("pbk", ""), l.q("sid", ""), l.q("spx", ""), l.q("serviceName", ""), l.q("mode", ""));
        r.secrets.add(l.host);
        r.secrets.add(l.user);
        return outbound("vless", new JSONObject().put("vnext", new JSONArray().put(new JSONObject()
                .put("address", l.host).put("port", l.port).put("users", new JSONArray().put(user)))), ss);
    }

    private static JSONObject trojan(String link, Result r) throws Exception {
        Link l = parse(link);
        if (l.user.isEmpty()) throw new IllegalArgumentException("El enlace trojan no tiene contrase\u00f1a");
        String sec = l.q("security", "tls").toLowerCase(Locale.ROOT);
        JSONObject ss = stream(l.q("type", "tcp"), sec, l.q("headerType", ""), l.q("host", ""),
                l.q("path", ""), l.q("sni", ""), l.q("alpn", ""), l.q("fp", ""),
                l.q("pbk", ""), l.q("sid", ""), l.q("spx", ""), l.q("serviceName", ""), l.q("mode", ""));
        r.secrets.add(l.host);
        r.secrets.add(l.user);
        return outbound("trojan", new JSONObject().put("servers", new JSONArray().put(new JSONObject()
                .put("address", l.host).put("port", l.port).put("password", l.user))), ss);
    }

    /**
     * hysteria2://AUTH@host:puerto/?sni=...&pinSHA256=HUELLA&obfs=salamander&obfs-password=CLAVE
     * El salto de puertos (mport) se ignora: se usa el puerto del enlace.
     */
    private static JSONObject hysteria2(String link, Result r) throws Exception {
        Link l = parse(link);
        if (l.user.isEmpty()) throw new IllegalArgumentException("El enlace hysteria2 no tiene la contrase\u00f1a de autenticaci\u00f3n");
        String pin = l.q("pinSHA256", "").replace(":", "").replace(" ", "").toLowerCase(Locale.ROOT);
        String insecure = l.q("insecure", "0");
        if (pin.isEmpty() && ("1".equals(insecure) || "true".equalsIgnoreCase(insecure))) {
            throw new IllegalArgumentException("Certificado autofirmado: agrega &pinSHA256=HUELLA al enlace "
                    + "(el motor ya no permite saltarse la verificaci\u00f3n)");
        }
        if (!pin.isEmpty() && !pin.matches("[0-9a-f]{64}")) {
            throw new IllegalArgumentException("pinSHA256 no v\u00e1lido: debe ser la huella SHA-256 (64 caracteres hexadecimales)");
        }
        String obfs = l.q("obfs", "");
        String obfsPass = l.q("obfs-password", "");

        JSONObject tls = new JSONObject().put("alpn", new JSONArray().put("h3"));
        String sni = l.q("sni", "");
        if (!sni.isEmpty()) tls.put("serverName", sni);
        if (!pin.isEmpty()) tls.put("pinnedPeerCertSha256", pin);

        JSONObject ss = new JSONObject();
        ss.put("network", "hysteria");
        ss.put("hysteriaSettings", new JSONObject().put("version", 2).put("auth", l.user));
        ss.put("security", "tls");
        ss.put("tlsSettings", tls);
        if (!obfs.isEmpty()) {
            if (!"salamander".equalsIgnoreCase(obfs)) throw new IllegalArgumentException("Ofuscaci\u00f3n no soportada: " + obfs);
            if (obfsPass.isEmpty()) throw new IllegalArgumentException("Falta obfs-password en el enlace");
            ss.put("finalmask", new JSONObject().put("udp", new JSONArray().put(new JSONObject()
                    .put("type", "salamander")
                    .put("settings", new JSONObject().put("password", obfsPass)))));
            r.secrets.add(obfsPass);
        }
        r.secrets.add(l.host);
        r.secrets.add(l.user);
        return outbound("hysteria", new JSONObject().put("version", 2).put("address", l.host).put("port", l.port), ss);
    }

    private static JSONObject shadowsocks(String link, Result r) throws Exception {
        String rest = link.substring(5);                 // despu\u00e9s de "ss://"
        int hash = rest.indexOf('#');
        if (hash >= 0) rest = rest.substring(0, hash);
        int qm = rest.indexOf('?');
        if (qm >= 0) {
            if (rest.substring(qm + 1).toLowerCase(Locale.ROOT).contains("plugin")) {
                throw new IllegalArgumentException("Shadowsocks con plugin no est\u00e1 soportado");
            }
            rest = rest.substring(0, qm);
        }
        int slash = rest.indexOf('/');
        if (slash >= 0) rest = rest.substring(0, slash);
        String cred, hp;
        int at = rest.lastIndexOf('@');
        if (at >= 0) {
            String ui = rest.substring(0, at);
            hp = rest.substring(at + 1);
            cred = ui.contains(":") ? decode(ui) : new String(b64(ui), StandardCharsets.UTF_8);
        } else {
            String all = new String(b64(rest), StandardCharsets.UTF_8);
            int a2 = all.lastIndexOf('@');
            if (a2 < 0) throw new IllegalArgumentException("Enlace ss no v\u00e1lido");
            cred = all.substring(0, a2);
            hp = all.substring(a2 + 1);
        }
        int c = cred.indexOf(':');
        if (c <= 0) throw new IllegalArgumentException("Enlace ss sin m\u00e9todo o contrase\u00f1a");
        String method = cred.substring(0, c);
        String pass = cred.substring(c + 1);
        Link hpL = parse("ss://" + hp);
        r.secrets.add(hpL.host);
        r.secrets.add(pass);
        return outbound("shadowsocks", new JSONObject().put("servers", new JSONArray().put(new JSONObject()
                .put("address", hpL.host).put("port", hpL.port).put("method", method).put("password", pass))),
                new JSONObject().put("network", "tcp"));
    }

    private static JSONObject outbound(String protocol, JSONObject settings, JSONObject stream) throws Exception {
        JSONObject o = new JSONObject();
        o.put("tag", "proxy");
        o.put("protocol", protocol);
        o.put("settings", settings);
        o.put("streamSettings", stream);
        return o;
    }

    // ------------------------------------------------------------------ transporte y seguridad

    private static JSONObject stream(String net, String sec, String hdr, String host, String path,
                                     String sni, String alpn, String fp, String pbk, String sid,
                                     String spx, String service, String mode) throws Exception {
        JSONObject ss = new JSONObject();
        String n = (net == null || net.isEmpty()) ? "tcp" : net.toLowerCase(Locale.ROOT);
        if (n.equals("tcp") || n.equals("raw")) {
            ss.put("network", "tcp");
            if ("http".equalsIgnoreCase(hdr)) {
                JSONObject req = new JSONObject();
                req.put("path", new JSONArray().put(path.isEmpty() ? "/" : path));
                if (!host.isEmpty()) req.put("headers", new JSONObject().put("Host", splitArr(host)));
                ss.put("tcpSettings", new JSONObject().put("header",
                        new JSONObject().put("type", "http").put("request", req)));
            }
        } else if (n.equals("ws")) {
            ss.put("network", "ws");
            JSONObject ws = new JSONObject().put("path", path.isEmpty() ? "/" : path);
            if (!host.isEmpty()) ws.put("headers", new JSONObject().put("Host", host));
            ss.put("wsSettings", ws);
        } else if (n.equals("grpc")) {
            ss.put("network", "grpc");
            ss.put("grpcSettings", new JSONObject()
                    .put("serviceName", service)
                    .put("multiMode", "multi".equalsIgnoreCase(mode)));
        } else if (n.equals("h2") || n.equals("http")) {
            ss.put("network", "http");
            JSONObject h = new JSONObject().put("path", path.isEmpty() ? "/" : path);
            if (!host.isEmpty()) h.put("host", splitArr(host));
            ss.put("httpSettings", h);
        } else if (n.equals("httpupgrade")) {
            ss.put("network", "httpupgrade");
            JSONObject h = new JSONObject().put("path", path.isEmpty() ? "/" : path);
            if (!host.isEmpty()) h.put("host", host);
            ss.put("httpupgradeSettings", h);
        } else if (n.equals("xhttp") || n.equals("splithttp")) {
            ss.put("network", "xhttp");
            JSONObject h = new JSONObject().put("path", path.isEmpty() ? "/" : path);
            if (!host.isEmpty()) h.put("host", host);
            if (!mode.isEmpty()) h.put("mode", mode);
            ss.put("xhttpSettings", h);
        } else {
            throw new IllegalArgumentException("Transporte no soportado: " + n);
        }

        if ("tls".equals(sec)) {
            ss.put("security", "tls");
            JSONObject t = new JSONObject();
            String name = !sni.isEmpty() ? sni : host;
            if (!name.isEmpty()) t.put("serverName", name.split(",")[0].trim());
            if (!alpn.isEmpty()) t.put("alpn", splitArr(alpn));
            if (!fp.isEmpty()) t.put("fingerprint", fp);
            ss.put("tlsSettings", t);
        } else if ("reality".equals(sec)) {
            if (pbk.isEmpty()) throw new IllegalArgumentException("Falta la clave p\u00fablica (pbk) de Reality");
            ss.put("security", "reality");
            JSONObject rs = new JSONObject();
            if (!sni.isEmpty()) rs.put("serverName", sni);
            rs.put("fingerprint", fp.isEmpty() ? "chrome" : fp);
            rs.put("publicKey", pbk);
            if (!sid.isEmpty()) rs.put("shortId", sid);
            if (!spx.isEmpty()) rs.put("spiderX", spx);
            ss.put("realitySettings", rs);
        } else {
            ss.put("security", "none");
        }
        return ss;
    }

    // ------------------------------------------------------------------ resolver el servidor

    /**
     * Si la direcci\u00f3n del servidor es un dominio, la cambia por su IP y deja el dominio como SNI /
     * Host por defecto. Devuelve el servidor original (para ocultarlo del registro).
     */
    private static String pin(JSONObject ob, boolean resolve) throws Exception {
        JSONObject st = ob.optJSONObject("settings");
        if (st == null) return null;
        JSONObject holder = null;
        JSONArray arr = st.optJSONArray("vnext");
        if (arr == null) arr = st.optJSONArray("servers");
        if (arr != null && arr.length() > 0) holder = arr.optJSONObject(0);
        else if (st.has("address")) holder = st;
        if (holder == null) return null;
        String addr = holder.optString("address", "");
        if (addr.isEmpty() || isIp(addr) || !resolve) return addr;

        holder.put("address", resolveHost(addr));

        JSONObject ss = ob.optJSONObject("streamSettings");
        if (ss == null) return addr;
        String sec = ss.optString("security", "none");
        if ("tls".equals(sec)) {
            JSONObject t = obj(ss, "tlsSettings");
            if (t.optString("serverName", "").isEmpty()) t.put("serverName", addr);
        } else if ("reality".equals(sec)) {
            JSONObject t = obj(ss, "realitySettings");
            if (t.optString("serverName", "").isEmpty()) t.put("serverName", addr);
        }
        JSONObject ws = ss.optJSONObject("wsSettings");
        if (ws != null && ws.optString("host", "").isEmpty()) {
            JSONObject hd = obj(ws, "headers");
            if (!hd.has("Host")) hd.put("Host", addr);
        }
        JSONObject xh = ss.optJSONObject("xhttpSettings");
        if (xh != null && xh.optString("host", "").isEmpty()) xh.put("host", addr);
        JSONObject hu = ss.optJSONObject("httpupgradeSettings");
        if (hu != null && hu.optString("host", "").isEmpty()) hu.put("host", addr);
        JSONObject h2 = ss.optJSONObject("httpSettings");
        if (h2 != null && !h2.has("host")) h2.put("host", new JSONArray().put(addr));
        return addr;
    }

    private static String resolveHost(String host) throws Exception {
        InetAddress[] all = InetAddress.getAllByName(host);
        for (InetAddress a : all) if (a instanceof Inet4Address) return a.getHostAddress();
        return all[0].getHostAddress();
    }

    private static boolean isIp(String a) {
        return a.contains(":") || a.matches("\\d{1,3}(\\.\\d{1,3}){3}");
    }

    private static JSONObject obj(JSONObject parent, String key) throws Exception {
        JSONObject o = parent.optJSONObject(key);
        if (o == null) { o = new JSONObject(); parent.put(key, o); }
        return o;
    }

    // ------------------------------------------------------------------ utilidades

    private static final class Link {
        String user = "", host = "";
        int port = 443;
        final Map<String, String> q = new HashMap<>();
        String q(String k, String def) {
            String v = q.get(k);
            return v == null ? def : v;
        }
    }

    private static Link parse(String link) {
        Link l = new Link();
        int i = link.indexOf("://");
        String rest = link.substring(i + 3);
        int hash = rest.indexOf('#');
        if (hash >= 0) rest = rest.substring(0, hash);
        String query = "";
        int qm = rest.indexOf('?');
        if (qm >= 0) { query = rest.substring(qm + 1); rest = rest.substring(0, qm); }
        int slash = rest.indexOf('/');
        if (slash >= 0) rest = rest.substring(0, slash);
        int at = rest.lastIndexOf('@');
        String hp = rest;
        if (at >= 0) { l.user = decode(rest.substring(0, at)); hp = rest.substring(at + 1); }
        try {
            if (hp.startsWith("[")) {
                int e = hp.indexOf(']');
                l.host = hp.substring(1, e);
                if (e + 1 < hp.length() && hp.charAt(e + 1) == ':') l.port = Integer.parseInt(hp.substring(e + 2).trim());
            } else {
                int c = hp.lastIndexOf(':');
                if (c >= 0) { l.host = hp.substring(0, c); l.port = Integer.parseInt(hp.substring(c + 1).trim()); }
                else l.host = hp;
            }
        } catch (RuntimeException e) {
            throw new IllegalArgumentException("Servidor o puerto no v\u00e1lido en el enlace");
        }
        l.host = l.host.trim();
        if (l.host.isEmpty()) throw new IllegalArgumentException("El enlace no tiene servidor");
        checkPort(l.port);
        for (String kv : query.split("&")) {
            if (kv.isEmpty()) continue;
            int eq = kv.indexOf('=');
            String k = eq >= 0 ? kv.substring(0, eq) : kv;
            String v = eq >= 0 ? decode(kv.substring(eq + 1)) : "";
            l.q.put(k, v);
        }
        return l;
    }

    /** Decodifica %xx sin convertir '+' en espacio (las rutas y contrase\u00f1as pueden llevar '+'). */
    private static String decode(String s) {
        try {
            return URLDecoder.decode(s.replace("+", "%2B"), "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    private static byte[] b64(String s) {
        return Base64.decode(s.trim().replace('-', '+').replace('_', '/'), Base64.DEFAULT);
    }

    private static JSONArray splitArr(String csv) {
        JSONArray a = new JSONArray();
        for (String p : csv.split(",")) {
            p = p.trim();
            if (!p.isEmpty()) a.put(p);
        }
        return a;
    }

    private static int toInt(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (RuntimeException e) { return def; }
    }

    private static void checkPort(int p) {
        if (p < 1 || p > 65535) throw new IllegalArgumentException("Puerto no v\u00e1lido: " + p);
    }
}
