package com.mivpn.app;

/**
 * Llave fija de los perfiles exportados. No depende de la firma del APK ni de nada que el
 * usuario escriba: cualquier copia de esta app (compilada con cualquier keystore) puede abrir
 * un archivo .conecta exportado por otra copia, porque la llave sigue siendo esta misma.
 *
 * Esto NO es secreto frente a alguien que descompile el APK: protege el archivo si se pierde,
 * se comparte por error o lo abre alguien sin la app, pero no frente a quien tenga el APK y
 * sepa buscar esta constante. Si se necesita más seguridad, cámbiese este valor (recompilando
 * todas las copias que deban seguir leyéndose entre sí) o vuélvase a pedir una contraseña.
 */
final class ProfileKey {
    static final char[] VALUE = "Cnct-Hwid-9f3Qz7LpA2vR8sKd1Y!2026".toCharArray();
    private ProfileKey() {}
}
