package com.mivpn.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.ApplicationExitInfo;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements TunnelService.Listener {
    private static final int REQ_VPN = 1;
    private static final int REQ_NOTIF = 2;
    private static final int REQ_EXPORT = 3;
    private static final int REQ_IMPORT = 4;
    private static final int REQ_AI_LICENSE = 5;

    private final int navy = Color.rgb(7, 20, 38);
    private final int card = Color.rgb(19, 43, 70);
    private final int blue = Color.rgb(0, 132, 255);
    private final int green = Color.rgb(0, 190, 125);
    private final int red = Color.rgb(214, 69, 69);
    private final int pale = Color.rgb(205, 224, 245);

    private TextView statusView, logView, hwidView;
    private EditText hostEdit, portEdit, userEdit;
    private Button mainButton, btnA, btnB, modeRufu, modeKey;
    private TextView hintView;
    private Button speedAuto, speedManual;
    private EditText manUpEdit, manDownEdit, manBatchEdit, manChunkEdit, manMtuEdit;
    private LinearLayout manualRow;
    private Switch udpSwitch, autoSwitch;
    private EditText udpPortEdit;
    private String speed = "auto";
    private int activePortIndex = 0;
    private Switch aiSwitch;
    private EditText aiPortEdit, aiTokenEdit;
    private LinearLayout aiRowView;
    private Button aiLicenseBtn;
    private Button aiOpenBtn;
    private LinearLayout portChipsRow;
    private String mode = TunnelService.MODE_RUFU;
    private String rufuId;
    private ScrollView logScroll;
    private SharedPreferences prefs;
    private String publicLine = "";
    private String keyHwid;
    private TextView ipView, lockedView, noProfileView;
    private TextView speedLabel, speedNumber, speedUnit;
    private SpeedGraphView speedGraph;
    private Button speedTestBtn;
    private static final int SPEEDTEST_PORT = 8767;   // puerto del servidor de prueba en el VPS
    private Button lockedBtn, btnImport, btnExport, btnClearLog;
    private LinearLayout lockedBox, serverRow, keyExtra, modesRow, profileRow;
    private String pendingExport;
    private boolean hwidShown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        window();
        mode = prefs.getString("mode", TunnelService.MODE_RUFU);
        speed = "manual".equals(prefs.getString("speed", "auto")) ? "manual" : "auto";   // Normal/Rápido/Máximo ya no existen
        activePortIndex = prefs.getInt("portIndex", 0);
        rufuId = DeviceIdentity.rufuHwid(this);
        try { keyHwid = DeviceIdentity.hwid(this); publicLine = DeviceIdentity.publicLine(this); }
        catch (Exception e) { keyHwid = null; publicLine = ""; }
        buildUi();
        applyFixed();
        applyMode();
        refreshPortChips();
        updateAiVisibility();
        applySpeed();
        applyLocked();
        refreshSecrets();
        reportPreviousFailure();
        handleIncomingFile(getIntent());

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIF);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        TunnelService.listener = this;
        logView.setText(TunnelService.logsSnapshot());
        applyState(TunnelService.state, TunnelService.stateText);
        ipView.setText("IP local: " + localIp());
    }

    @Override
    protected void onPause() {
        saveFields();
        if (TunnelService.listener == this) TunnelService.listener = null;
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingFile(intent);
    }

    /** Perfil recibido por "Abrir con" (VIEW) o "Compartir" (SEND), por ejemplo desde WhatsApp. */
    private void handleIncomingFile(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        Uri data = Intent.ACTION_VIEW.equals(action) ? intent.getData()
                : Intent.ACTION_SEND.equals(action) ? intent.getParcelableExtra(Intent.EXTRA_STREAM)
                : null;
        if (data == null) return;
        setIntent(new Intent());   // no reprocesar el mismo archivo si la pantalla se recrea
        try {
            String text = readText(data);
            if (AiLicense.looks(text)) { activateAiLicense(text); return; }
            if (!ProfileCrypto.looksEncrypted(text)) { toast("Ese archivo no es un perfil de Conecta"); return; }
            importProfile(text, fileName(data));
        } catch (Exception e) {
            toast("No se pudo leer el archivo recibido");
        }
    }

    // ------------------------------------------------------------------ listener del servicio

    @Override
    public void onState(final int state, final String text) {
        runOnUiThread(new Runnable() { @Override public void run() { applyState(state, text); } });
    }

    @Override
    public void onLog(final String line) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                logView.append(line + "\n");
                logScroll.post(new Runnable() { @Override public void run() { logScroll.fullScroll(ScrollView.FOCUS_DOWN); } });
            }
        });
    }

    private void applyState(int state, String text) {
        boolean idle = state == TunnelService.ST_IDLE;
        if (idle && SpeedTest.isRunning()) SpeedTest.stop();
        statusView.setText("\u25CF " + text);
        statusView.setTextColor(state == TunnelService.ST_CONNECTED ? green
                : state == TunnelService.ST_CONNECTING ? Color.rgb(240, 180, 60) : Color.rgb(150, 165, 185));
        hostEdit.setEnabled(idle);
        portEdit.setEnabled(idle);
        userEdit.setEnabled(idle);
        modeRufu.setEnabled(idle);
        modeKey.setEnabled(idle);
        speedAuto.setEnabled(idle);
        speedManual.setEnabled(idle);
        manUpEdit.setEnabled(idle);
        manDownEdit.setEnabled(idle);
        manBatchEdit.setEnabled(idle);
        manChunkEdit.setEnabled(idle);
        manMtuEdit.setEnabled(idle);
        udpSwitch.setEnabled(idle);
        udpPortEdit.setEnabled(idle);
        autoSwitch.setEnabled(idle);
        btnImport.setEnabled(idle);
        btnExport.setEnabled(idle);
        lockedBtn.setEnabled(idle);
        if (state == TunnelService.ST_CONNECTING) {
            mainButton.setText("Cancelar");
            setBg(mainButton, red);
        } else if (state == TunnelService.ST_CONNECTED) {
            mainButton.setText("Desconectar");
            setBg(mainButton, red);
        } else {
            mainButton.setText("Conectar");
            setBg(mainButton, green);
        }
    }

    /** Si la app se cerró sola la vez anterior, deja el motivo en el registro. */
    private void reportPreviousFailure() {
        String crash = App.takeCrash(this);
        if (crash != null) {
            TunnelService.appendLog("⚠ La app se cerró por este error:");
            String[] lines = crash.split("\n");
            for (int i = 0; i < lines.length && i < 14; i++) TunnelService.appendLog(lines[i]);
            return;
        }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                List<ApplicationExitInfo> l = am.getHistoricalProcessExitReasons(getPackageName(), 0, 1);
                if (l != null && !l.isEmpty()) {
                    ApplicationExitInfo i = l.get(0);
                    if (i.getTimestamp() > prefs.getLong("exitTs", 0)) {
                        prefs.edit().putLong("exitTs", i.getTimestamp()).apply();
                        int r = i.getReason();
                        // Se registran todos los motivos, incluso los que no son fallos de la app
                        // (memoria baja, ahorro de batería del fabricante, etc.), para saber por
                        // qué el sistema la cerró.
                        TunnelService.appendLog("\u26a0 La app se cerr\u00f3 antes: " + exitReasonName(r)
                                + " | " + i.getDescription());
                    }
                }
            } catch (Throwable ignored) { }
        }
    }

    private static String exitReasonName(int r) {
        switch (r) {
            case 1: return "LA APP SE CERR\u00d3 SOLA";
            case 2: return "SE\u00d1AL DEL SISTEMA (cierre forzado)";
            case 3: return "MEMORIA BAJA (el sistema la cerr\u00f3 por falta de RAM)";
            case 4: return "ERROR DE JAVA";
            case 5: return "FALLO NATIVO (t\u00fanel)";
            case 6: return "NO RESPONDE (ANR)";
            case 7: return "FALLO AL INICIAR";
            case 8: return "CAMBIO DE PERMISOS";
            case 9: return "USO EXCESIVO DE RECURSOS";
            case 10: return "CERRADA POR EL USUARIO";
            case 11: return "DETENIDA POR EL USUARIO";
            case 12: return "SE CERR\u00d3 UN COMPONENTE DEL QUE DEPEND\u00cdA";
            case 13: return "OTRO MOTIVO (posible ahorro de bater\u00eda del fabricante)";
            case 14: return "CONGELADA POR EL SISTEMA";
            case 15: return "CAMBIO EN EL PAQUETE";
            case 16: return "APP ACTUALIZADA";
            default: return "C\u00d3DIGO " + r;
        }
    }

    // ------------------------------------------------------------------ acciones

    private void onMainClick() {
        if (tuning()) { cancelAutoTune("B\u00fasqueda cancelada"); }
        if (portTesting()) { portCancel("Prueba de puertos cancelada"); }
        if (TunnelService.state != TunnelService.ST_IDLE) {
            searchOnConnect = false;
            startService(new Intent(this, TunnelService.class).setAction(TunnelService.ACTION_STOP));
            return;
        }
        boolean rufu = TunnelService.MODE_RUFU.equals(mode);
        if (hostEdit.getText().toString().trim().isEmpty()
                || (!rufu && userEdit.getText().toString().trim().isEmpty())) {
            toast(rufu ? "Completa el servidor" : "Completa servidor y usuario");
            return;
        }
        if (rufu && rufuId == null) {
            toast("Android no entregó el ID del dispositivo");
            return;
        }
        saveFields();
        Intent prep = VpnService.prepare(this);
        if (prep != null) {
            startActivityForResult(prep, REQ_VPN);
        } else {
            startTunnel();
            armAutoSearch();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_VPN) {
            if (resultCode == RESULT_OK) {
                startTunnel();
                armAutoSearch();
            } else toast("Necesitas aceptar el permiso de VPN");
        } else if (requestCode == REQ_EXPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingExport != null) {
                try (OutputStream o = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    o.write((pendingExport + "\n").getBytes(StandardCharsets.UTF_8));
                    toast("Perfil exportado y cifrado");
                } catch (Exception e) {
                    toast("No se pudo guardar el archivo");
                }
            }
            pendingExport = null;
        } else if (requestCode == REQ_AI_LICENSE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try { activateAiLicense(readText(data.getData())); }
                catch (Exception e) { toast("No se pudo leer el archivo"); }
            }
        } else if (requestCode == REQ_IMPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try {
                    String text = readText(data.getData());
                    if (AiLicense.looks(text)) activateAiLicense(text);
                    else if (!ProfileCrypto.looksEncrypted(text)) toast("Ese archivo no es un perfil de Conecta");
                    else importProfile(text, fileName(data.getData()));
                } catch (Exception e) {
                    toast("No se pudo leer el archivo");
                }
            }
        }
    }

    /** {subidas, descargas, lote, registro, MTU}: el candidato en prueba, lo guardado por Automático, o los campos Manual. */
    private int[] currentSpeedParams() {
        if (tuneCur != null) return tuneCur;
        if ("auto".equals(speed)) {
            return new int[]{prefs.getInt("autoUp", 4), prefs.getInt("autoDown", 8),
                    prefs.getInt("autoBatch", 8), prefs.getInt("autoChunk", 1399), prefs.getInt("autoMtu", 1500)};
        }
        return new int[]{manualValue(manUpEdit, 4, 1, 64), manualValue(manDownEdit, 8, 1, 128),
                manualValue(manBatchEdit, 8, 1, 32), manualValue(manChunkEdit, 1399, 64, 9000),
                manualValue(manMtuEdit, 1500, 1280, 9000)};
    }

    private void startTunnel() {
        int port = currentPort();
        int[] sp = currentSpeedParams();
        Intent i = new Intent(this, TunnelService.class)
                .setAction(TunnelService.ACTION_START)
                .putExtra(TunnelService.EXTRA_HOST, hostEdit.getText().toString().trim())
                .putExtra(TunnelService.EXTRA_PORT, port)
                .putExtra(TunnelService.EXTRA_USER, userEdit.getText().toString().trim())
                .putExtra(TunnelService.EXTRA_MODE, mode)
                .putExtra(TunnelService.EXTRA_SPEED, "manual")   // Automático y Manual usan los mismos 4 números
                .putExtra(TunnelService.EXTRA_UP, sp[0])
                .putExtra(TunnelService.EXTRA_DOWN, sp[1])
                .putExtra(TunnelService.EXTRA_BATCH, sp[2])
                .putExtra(TunnelService.EXTRA_CHUNK, sp[3])
                .putExtra(TunnelService.EXTRA_MTU, sp[4])
                .putExtra(TunnelService.EXTRA_UDP, udpSwitch.isChecked())
                .putExtra(TunnelService.EXTRA_AUTO, autoSwitch.isChecked())
                .putExtra(TunnelService.EXTRA_UDPGW_PORT, udpPort());
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private void saveFields() {
        if (hostEdit == null) return;
        prefs.edit()
                .putString("host", hostEdit.getText().toString().trim())
                .putString("port", portEdit.getText().toString().trim())
                .putString("user", userEdit.getText().toString().trim())
                .putString("udpgw", udpPortEdit.getText().toString().trim())
                .putString("manUp", String.valueOf(manualValue(manUpEdit, 4, 1, 64)))
                .putString("manDown", String.valueOf(manualValue(manDownEdit, 8, 1, 128)))
                .putString("manBatch", String.valueOf(manualValue(manBatchEdit, 8, 1, 32)))
                .putString("manChunk", String.valueOf(manualValue(manChunkEdit, 1399, 64, 9000)))
                .putString("manMtu", String.valueOf(manualValue(manMtuEdit, 1500, 1280, 9000)))
                .putBoolean("udp", udpSwitch.isChecked())
                .putBoolean("auto", autoSwitch.isChecked())
                .putInt("portIndex", activePortIndex)
                .putBoolean("ai", aiSwitch.isChecked())
                .putString("aiPort", aiPortEdit.getText().toString().trim())
                .putString("aiToken", aiTokenEdit.getText().toString().trim())
                .apply();
        refreshSecrets();
    }

    private void clip(String label, String text, String msg) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(label, text));
        toast(msg);
    }

    private void share(String text) {
        Intent sh = new Intent(Intent.ACTION_SEND);
        sh.setType("text/plain");
        sh.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(sh, "Enviar"));
    }

    /** Todos los puertos válidos, sin repetidos y sin l\u00edmite, tal como los escribi\u00f3 el administrador. */
    private List<Integer> parsePorts() {
        List<Integer> out = new ArrayList<>();
        for (String tok : portEdit.getText().toString().split(",")) {
            tok = tok.trim();
            if (tok.isEmpty()) continue;
            try {
                int p = Integer.parseInt(tok);
                if (p >= 1 && p <= 65535 && !out.contains(p)) out.add(p);
            } catch (NumberFormatException ignored) { }
        }
        return out;
    }

    /** El puerto con el que se conecta ahora mismo: el que está marcado entre los disponibles. */
    private int currentPort() {
        List<Integer> ports = parsePorts();
        if (ports.isEmpty()) return 22;
        int idx = Math.min(activePortIndex, ports.size() - 1);
        return ports.get(idx);
    }

    private void setActivePort(int index) {
        if (portTesting() || tuning()) return;   // no cambiar de puerto a mitad de una prueba
        activePortIndex = index;
        saveFields();
        refreshPortChips();
    }

    // ------------------------------------------------------------------ asistente de IA (experimental)

    private void updateAiVisibility() {
        if (isClient()) {   // la versión de los clientes no lleva IA
            aiSwitch.setVisibility(android.view.View.GONE);
            aiRowView.setVisibility(android.view.View.GONE);
            aiOpenBtn.setVisibility(android.view.View.GONE);
            aiLicenseBtn.setVisibility(android.view.View.GONE);
            return;
        }
        boolean on = aiSwitch.isChecked();
        int vis = on ? android.view.View.VISIBLE : android.view.View.GONE;
        boolean direct = AiAssistant.isDirect(this);
        aiPortEdit.setVisibility(direct ? android.view.View.GONE : vis);
        aiTokenEdit.setVisibility(direct ? android.view.View.GONE : vis);
        aiOpenBtn.setVisibility(vis);
        aiLicenseBtn.setVisibility(android.view.View.VISIBLE);
    }

    private int aiPort() {
        try { return Integer.parseInt(aiPortEdit.getText().toString().trim()); } catch (Exception e) { return 8766; }
    }

    /** Oculta IP, puerto, usuario e ID en todo lo que se muestra (o se envía) en el chat del asistente. */
    private String chatMask(String s) {
        if (s == null || s.isEmpty()) return s;
        refreshSecrets();
        s = LogMask.mask(s);
        // "port 22", "puerto 443", "(port 2222)"...
        s = s.replaceAll("(?i)\\b(port|puerto)(\\s*[:=]?\\s*)\\d{1,5}\\b", "$1$2" + LogMask.MASK);
        // los puertos configurados (servidor, UDP, IA) si aparecen sueltos
        java.util.Set<String> ports = new java.util.HashSet<>();
        for (Integer pt : parsePorts()) ports.add(String.valueOf(pt));
        ports.add(String.valueOf(udpPort()));
        ports.add(String.valueOf(aiPort()));
        for (String pt : ports) {
            if (pt.length() >= 3) s = s.replaceAll("(?<!\\d)" + java.util.regex.Pattern.quote(pt) + "(?!\\d)", LogMask.MASK);
        }
        return s;
    }

    private void openAiAssistant() {
        String host = hostEdit.getText().toString().trim();
        String token = aiTokenEdit.getText().toString().trim();
        if (isClient()) return;
        if (!AiAssistant.isDirect(this) && (host.isEmpty() || token.isEmpty())) {
            toast("La IA no est\u00e1 activada: carga tu archivo de licencia");
            return;
        }
        int port = aiPort();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(10), dp(16), 0);
        ScrollView chatScroll = new ScrollView(this);
        TextView chatView = text("Preguntale algo, o toca \"Diagnosticar el \u00faltimo error\".", 13, pale, false);
        chatScroll.addView(chatView);
        box.addView(chatScroll, new LinearLayout.LayoutParams(-1, dp(260)));
        EditText msgEdit = edit("Escribe tu consulta", "", InputType.TYPE_CLASS_TEXT);
        box.addView(msgEdit, lp(-1, dp(46), 10, 0));
        Button diagBtn = button("Diagnosticar el \u00faltimo error", Color.rgb(44, 68, 98));
        box.addView(diagBtn, lp(-1, dp(42), 10, 0));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Asistente")
                .setView(box)
                .setPositiveButton("Enviar", null)   // se sobreescribe abajo para que no cierre solo
                .setNegativeButton("Cerrar", null)
                .show();

        Runnable[] sendHolder = new Runnable[1];
        sendHolder[0] = () -> {
            String p = chatMask(msgEdit.getText().toString().trim());
            if (p.isEmpty()) return;
            chatView.append("\n\nT\u00fa: " + p + "\nAsistente: \u2026");
            chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
            msgEdit.setText("");
            AiAssistant.Callback aiCb = new AiAssistant.Callback() {
                @Override public void onReply(String text) {
                    String cur = chatView.getText().toString();
                    chatView.setText(cur.substring(0, cur.length() - 1) + chatMask(text));
                    chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
                }
                @Override public void onError(String message) {
                    String cur = chatView.getText().toString();
                    chatView.setText(cur.substring(0, cur.length() - 1) + "\u26a0 " + chatMask(message));
                    chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
                }
            };
            if (AiAssistant.isDirect(this)) AiAssistant.askDirect(this, p, aiCb);
            else AiAssistant.ask(this, host, port, token, p, aiCb);
        };
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> sendHolder[0].run());
        diagBtn.setOnClickListener(v -> {
            String log = LogMask.mask(logView.getText().toString());
            msgEdit.setText("Mi app de conexi\u00f3n VPN no funciona bien. Este es el registro (la IP y el ID ya est\u00e1n ocultos "
                    + "a prop\u00f3sito, no hace falta que los pidas): " + log
                    + "\n\u00bfCu\u00e1l es la causa m\u00e1s probable y qu\u00e9 puedo hacer?");
            sendHolder[0].run();
        });
    }

    /**
     * Un bot\u00f3n por cada puerto, sin l\u00edmite: se acomodan en filas de 5.
     * Conecta Generador muestra el n\u00famero del puerto; Conecta HWID solo "Puerto 1", "Puerto 2"...
     */
    private void refreshPortChips() {
        List<Integer> ports = parsePorts();
        if (activePortIndex >= ports.size()) activePortIndex = Math.max(0, ports.size() - 1);
        portChipsRow.removeAllViews();
        final int perRow = 5;
        LinearLayout row = null;
        for (int i = 0; i < ports.size(); i++) {
            if (i % perRow == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
                if (i > 0) rp.topMargin = dp(6);
                portChipsRow.addView(row, rp);
            }
            final int idx = i;
            Button b = button(isClient() ? "Puerto " + (i + 1) : String.valueOf(ports.get(i)), Color.rgb(44, 68, 98));
            b.setTextSize(13);
            setBg(b, i == activePortIndex ? blue : Color.rgb(44, 68, 98));
            b.setOnClickListener(v -> setActivePort(idx));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, dp(36), 1f);
            if (i % perRow > 0) clp.leftMargin = dp(6);
            row.addView(b, clp);
        }
        // Rellena la \u00faltima fila para que los botones no se estiren.
        if (row != null) {
            for (int k = ports.size() % perRow; k != 0 && k < perRow; k++) {
                LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, dp(36), 1f);
                sp.leftMargin = dp(6);
                row.addView(new android.view.View(this), sp);
            }
        }
        portChipsRow.setVisibility(ports.size() > 1 ? android.view.View.VISIBLE : android.view.View.GONE);
        if (btnPortTest != null) btnPortTest.setVisibility(ports.size() > 1 ? android.view.View.VISIBLE : android.view.View.GONE);
    }

    private int udpPort() {
        try { return Integer.parseInt(udpPortEdit.getText().toString().trim()); } catch (Exception e) { return 7300; }
    }

    private void setSpeed(String v) {
        speed = v;
        prefs.edit().putString("speed", v).apply();
        applySpeed();
    }

    private void applySpeed() {
        int off = Color.rgb(44, 68, 98);
        if (speedAuto != null) setBg(speedAuto, "auto".equals(speed) ? blue : off);
        if (speedManual != null) setBg(speedManual, "manual".equals(speed) ? blue : off);
        if (manualRow != null) manualRow.setVisibility("manual".equals(speed) && !(isLocked() || isClient()) ? android.view.View.VISIBLE : android.view.View.GONE);
        updateTuneButton();
    }

    /** El botón de búsqueda se ve en Automático (para todos) y en Manual solo si el perfil no está bloqueado. */
    private void updateTuneButton() {
        if (btnTune == null) return;
        boolean show = "auto".equals(speed) || ("manual".equals(speed) && !isLocked());
        btnTune.setVisibility(show ? android.view.View.VISIBLE : android.view.View.GONE);
    }

    /** Lee un número del campo, lo limita al rango permitido y usa el valor por defecto si está vacío. */
    private int manualValue(EditText e, int def, int min, int max) {
        int v = def;
        try { if (e != null) v = Integer.parseInt(e.getText().toString().trim()); } catch (Exception ignored) { }
        return Math.max(min, Math.min(max, v));
    }

    private void setMode(String m) {
        mode = m;
        prefs.edit().putString("mode", m).apply();
        applyMode();
    }

    private void applyMode() {
        boolean rufu = TunnelService.MODE_RUFU.equals(mode);
        setBg(modeRufu, rufu ? blue : Color.rgb(44, 68, 98));
        setBg(modeKey, rufu ? Color.rgb(44, 68, 98) : blue);
        updateVisibility();
        if (rufu) {
            renderHwid();
            btnA.setText("Copiar HWID");
            btnA.setOnClickListener(v -> { if (rufuId != null) clip("HWID", rufuId, "HWID copiado"); });
            keyExtra.setVisibility(android.view.View.GONE);
        } else {
            keyExtra.setVisibility(android.view.View.VISIBLE);
            renderHwid();
            btnA.setText("Copiar");
            btnB.setText("Compartir");
            btnA.setOnClickListener(v -> clip("HWID", publicLine, "Copiado. Envíaselo al administrador del VPS."));
            btnB.setOnClickListener(v -> share(publicLine));
            hintView.setText("Modo llave: más seguro. Registra la línea copiada en el VPS con hwid-vps.sh y usa el usuario SSH correspondiente.");
        }
    }

    // ------------------------------------------------------------------ velocidad e IP local

    // ------------------------------------------------------------------ prueba de velocidad (estilo fast.com)

    /** Kbps por debajo de 1 Mbps; desde ahí pasa a Mbps con un decimal. */
    private void showSpeed(double mbps) {
        if (mbps < 1.0) {
            speedNumber.setText(String.format(java.util.Locale.US, "%.0f", mbps * 1000));
            speedUnit.setText("Kbps");
        } else {
            speedNumber.setText(String.format(java.util.Locale.US, "%.1f", mbps));
            speedUnit.setText("Mbps");
        }
    }

    private android.app.Dialog fastDialog;
    private static final String FAST_URL = "https://fast.com/es/";

    /** Abre fast.com en el navegador del teléfono: ese sí pasa por la VPN, así que mide el túnel. */
    private void openFastInBrowser() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(FAST_URL)));
        } catch (Throwable t) {
            toast("No se pudo abrir el navegador");
        }
    }

    private void clearWebProxy() {
        try {
            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.PROXY_OVERRIDE)) {
                androidx.webkit.ProxyController.getInstance().clearProxyOverride(Runnable::run, () -> { });
            }
        } catch (Throwable ignored) { }
    }

    /**
     * fast.com dentro de la app. Esta app está excluida de la VPN (addDisallowedApplication), así
     * que un WebView normal saldría por la conexión directa. Para medir el túnel, mientras la VPN
     * esté conectada se manda el tráfico del WebView por el SOCKS local del túnel (el mismo que
     * usa SpeedTest). Si el WebView del teléfono no soporta proxy, se abre en el navegador.
     */
    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    private void openFastCom() {
        if (fastDialog != null && fastDialog.isShowing()) return;
        final boolean tunnelUp = TunnelService.state == TunnelService.ST_CONNECTED
                && TunnelService.activeSocksPort > 0;

        final android.webkit.WebView web = new android.webkit.WebView(this);
        android.webkit.WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        web.setBackgroundColor(Color.BLACK);
        web.setWebViewClient(new android.webkit.WebViewClient());

        if (tunnelUp) {
            boolean ok = false;
            try {
                if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.PROXY_OVERRIDE)) {
                    androidx.webkit.ProxyConfig cfg = new androidx.webkit.ProxyConfig.Builder()
                            .addProxyRule("socks5://127.0.0.1:" + TunnelService.activeSocksPort)
                            .build();
                    androidx.webkit.ProxyController.getInstance()
                            .setProxyOverride(cfg, Runnable::run, () -> runOnUiThread(() -> web.loadUrl(FAST_URL)));
                    ok = true;
                }
            } catch (Throwable ignored) { }
            if (!ok) {
                web.destroy();
                toast("Este WebView no soporta proxy: se abre en el navegador (usa la VPN)");
                openFastInBrowser();
                return;
            }
        } else {
            toast("VPN desconectada: esto mide la conexión directa");
            web.loadUrl(FAST_URL);
        }

        Button browser = button("Abrir en navegador", Color.rgb(44, 68, 98));
        browser.setOnClickListener(v -> openFastInBrowser());
        Button close = button("Cerrar", Color.rgb(44, 68, 98));
        close.setOnClickListener(v -> { if (fastDialog != null) fastDialog.dismiss(); });

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.addView(browser, new LinearLayout.LayoutParams(0, -1, 1f));
        buttons.addView(close, new LinearLayout.LayoutParams(0, -1, 1f));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(Color.BLACK);
        box.addView(web, new LinearLayout.LayoutParams(-1, 0, 1f));
        box.addView(buttons, new LinearLayout.LayoutParams(-1, dp(52)));

        fastDialog = new android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        fastDialog.setContentView(box);
        fastDialog.setOnKeyListener((d, keyCode, ev) -> {
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK
                    && ev.getAction() == android.view.KeyEvent.ACTION_UP) {
                if (web.canGoBack()) web.goBack(); else d.dismiss();
                return true;
            }
            return false;
        });
        fastDialog.setOnDismissListener(d -> {
            web.stopLoading();
            web.destroy();
            clearWebProxy();   // el proxy es global del proceso: se quita al cerrar
            fastDialog = null;
        });
        fastDialog.show();
    }

    // ------------------------------------------------------------------ búsqueda automática de velocidad

    /**
     * Calibraci\u00f3n autom\u00e1tica de los 5 valores: se parte de una base suave y se va subiendo un valor a la vez.
     * Cada valor se prueba hacia arriba y se acepta si la bajada mejora m\u00e1s de un 5%; en cuanto uno no mejora,
     * se deja el anterior y se pasa al siguiente valor. Orden: MTU, registro, descargas, subidas y lote.
     * \u00cdndices: 0 subidas, 1 descargas, 2 lote, 3 registro, 4 MTU.
     */
    private static final int[][] TUNE_VALUES = {
            {2, 4, 8, 16, 32, 64},     // 0 subidas (1-64)
            {4, 8, 16, 32, 64, 128},   // 1 descargas (1-128)
            {4, 8, 16, 32},            // 2 lote (1-32)
            {1399, 4000, 9000},        // 3 registro (el servidor decide cu\u00e1nto acepta)
            {1500, 8500}               // 4 MTU
    };
    private static final int[] TUNE_ORDER = {4, 3, 1, 0, 2};
    private static final int[] TUNE_BASE = {4, 8, 8, 1399, 1500};
    private static final int TUNE_MAX_EVALS = 14;   // tope de pruebas (\u22487 min), pase lo que pase
    private static final int T_NONE = 0, T_STOP = 1, T_CONNECT = 2, T_TEST = 3, T_FINAL_STOP = 4;
    private int tuneStage = T_NONE, tuneIdx;
    private int[] tuneCur;          // combinación en prueba (null fuera de la búsqueda)
    private int[] tuneBase;            // mejor combinaci\u00f3n aceptada hasta ahora
    private double tuneBaseMbps;       // su bajada (-1 = todav\u00eda sin medir)
    private int tunePos, tuneValIdx;   // valor que se est\u00e1 subiendo y posici\u00f3n dentro de su lista
    private boolean tuneIsBase;        // la prueba en curso es la de la base
    private long tuneDeadline;
    private Button btnTune;
    private final android.os.Handler tuneHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable tuneTick = new Runnable() {
        @Override public void run() { tuneStep(); }
    };

    private boolean tuning() { return tuneStage != T_NONE; }

    private boolean searchOnConnect;   // true desde que el usuario pulsa Conectar con Autom\u00e1tico marcado
    private long armDeadline;
    private final Runnable armTick = new Runnable() {
        @Override public void run() {
            if (!searchOnConnect || tuning()) return;
            if (!"auto".equals(speed)) { searchOnConnect = false; return; }
            if (TunnelService.state == TunnelService.ST_CONNECTED && TunnelService.activeSocksPort > 0) {
                searchOnConnect = false;
                TunnelService.appendLog("Auto: empieza la b\u00fasqueda de la mejor velocidad");
                tuneHandler.postDelayed(new Runnable() {
                    @Override public void run() {
                        if ("auto".equals(speed) && !tuning() && !SpeedTest.isRunning()
                                && TunnelService.state == TunnelService.ST_CONNECTED
                                && TunnelService.activeSocksPort > 0) {
                            toast("Buscando la mejor velocidad\u2026 (toca Desconectar para cancelar)");
                            beginAutoTune();
                        } else {
                            TunnelService.appendLog("Auto: no se pudo iniciar (el t\u00fanel cambi\u00f3 de estado)");
                        }
                    }
                }, 1500);
                return;
            }
            if (System.currentTimeMillis() > armDeadline) {
                searchOnConnect = false;
                TunnelService.appendLog("Auto: el t\u00fanel no conect\u00f3 a tiempo, no se hizo la b\u00fasqueda");
                return;
            }
            tuneHandler.postDelayed(this, 500);
        }
    };

    /**
     * Con Autom\u00e1tico marcado y sin resultado guardado (primera vez con el perfil), al pulsar Conectar espera a que
     * el t\u00fanel quede conectado y empieza sola la b\u00fasqueda. Se vigila con un temporizador y no con el aviso de la pantalla, as\u00ed funciona aunque salgas de la app.
     */
    private void armAutoSearch() {
        if (!"auto".equals(speed) || prefs.getBoolean("autoDone", false)) { searchOnConnect = false; return; }
        searchOnConnect = true;
        armDeadline = System.currentTimeMillis() + 90_000;
        tuneHandler.removeCallbacks(armTick);
        tuneHandler.postDelayed(armTick, 500);
    }

    private void startAutoTune() {
        if (tuning()) { cancelAutoTune("B\u00fasqueda cancelada"); return; }
        if (portTesting()) { toast("Espera a que termine la prueba de puertos"); return; }
        if (SpeedTest.isRunning()) { toast("Espera a que termine la prueba de velocidad"); return; }
        boolean rufu = TunnelService.MODE_RUFU.equals(mode);
        if (hostEdit.getText().toString().trim().isEmpty()
                || (!rufu && userEdit.getText().toString().trim().isEmpty())) {
            toast(isClient() ? "Primero importa tu perfil" : "Primero completa el servidor"); return;
        }
        if (rufu && rufuId == null) { toast("Android no entreg\u00f3 el ID del dispositivo"); return; }
        if (VpnService.prepare(this) != null) {
            toast("Primero conecta una vez para aceptar el permiso de VPN"); return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Buscar la mejor velocidad")
                .setMessage("Calibra solo los 5 valores (subidas, descargas, lote, registro y MTU): parte de una base y "
                        + "va subiendo uno a la vez mientras la velocidad mejore. En cada prueba se reconecta y mide la "
                        + "bajada por el t\u00fanel (unos 30 s cada una, entre 5 y 7 min en total, hasta 50 MB por prueba). "
                        + "Al final deja la mejor combinaci\u00f3n.")
                .setPositiveButton("Empezar", (d, w) -> beginAutoTune())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void beginAutoTune() {
        saveFields();
        prefs.edit().putBoolean("autoDone", true).apply();   // no se repite sola en cada conexi\u00f3n
        tuneBase = TUNE_BASE.clone();
        tuneBaseMbps = -1;
        tunePos = 0;
        tuneValIdx = -1;
        tuneIdx = 0;
        btnTune.setText("Cancelar b\u00fasqueda");
        tuneNext();
    }

    /** Siguiente combinaci\u00f3n a probar, o null si ya no queda ninguna (o se lleg\u00f3 al tope de pruebas). */
    private int[] tuneNextCandidate() {
        if (tuneBaseMbps < 0) { tuneIsBase = true; return tuneBase.clone(); }
        tuneIsBase = false;
        if (tuneIdx >= TUNE_MAX_EVALS) return null;
        while (tunePos < TUNE_ORDER.length) {
            int p = TUNE_ORDER[tunePos];
            int[] vals = TUNE_VALUES[p];
            for (int i = tuneValIdx + 1; i < vals.length; i++) {
                if (vals[i] > tuneBase[p]) {
                    tuneValIdx = i;
                    int[] c = tuneBase.clone();
                    c[p] = vals[i];
                    return c;
                }
            }
            tunePos++;
            tuneValIdx = -1;
        }
        return null;
    }

    private void tuneNext() {
        int[] c = tuneNextCandidate();
        if (c == null) { tuneFinish(); return; }
        tuneCur = c;
        setSpeedText("Auto " + (tuneIdx + 1) + ": subidas " + c[0] + " / descargas " + c[1]
                + " / lote " + c[2] + " / registro " + c[3] + " / MTU " + c[4]);
        speedNumber.setText("0");
        speedGraph.clear();
        tuneStage = T_STOP;
        tuneDeadline = System.currentTimeMillis() + 15_000;
        if (TunnelService.state != TunnelService.ST_IDLE) {
            startService(new Intent(this, TunnelService.class).setAction(TunnelService.ACTION_STOP));
        }
        tuneHandler.removeCallbacks(tuneTick);
        tuneHandler.post(tuneTick);
    }

    /** Revisa el estado cada medio segundo; no depende de que la pantalla est\u00e9 al frente. */
    private void tuneStep() {
        if (tuneStage == T_NONE) return;
        int st = TunnelService.state;
        long now = System.currentTimeMillis();
        switch (tuneStage) {
            case T_STOP:
                if (st == TunnelService.ST_IDLE) {
                    tuneStage = T_CONNECT;
                    tuneDeadline = now + 45_000;
                    startTunnel();
                } else if (now > tuneDeadline) {
                    cancelAutoTune("No se pudo reiniciar el t\u00fanel");
                    return;
                }
                break;
            case T_CONNECT:
                if (st == TunnelService.ST_CONNECTED && TunnelService.activeSocksPort > 0) {
                    tuneStage = T_TEST;
                    tuneDeadline = now + 45_000;
                    tuneHandler.postDelayed(this::tuneRunTest, 2000);   // deja que el t\u00fanel se asiente
                } else if (now > tuneDeadline) {
                    tuneRecord(0);
                    return;
                }
                break;
            case T_TEST:
                if (st == TunnelService.ST_IDLE) { tuneRecord(0); return; }
                if (now > tuneDeadline) { SpeedTest.stop(); tuneRecord(0); return; }
                break;
            case T_FINAL_STOP:
                if (st == TunnelService.ST_IDLE) {
                    tuneStage = T_NONE;
                    tuneCur = null;
                    startTunnel();   // vuelve a conectar con la mejor combinaci\u00f3n
                    finishTuneUi();
                    return;
                } else if (now > tuneDeadline) {
                    tuneStage = T_NONE;
                    tuneCur = null;
                    finishTuneUi();
                    return;
                }
                break;
            default: return;
        }
        tuneHandler.postDelayed(tuneTick, 500);
    }

    private void tuneRunTest() {
        if (tuneStage != T_TEST) return;
        if (TunnelService.state != TunnelService.ST_CONNECTED || TunnelService.activeSocksPort <= 0) return;
        final int my = tuneIdx;
        SpeedTest.start(this, hostEdit.getText().toString().trim(), TunnelService.activeSocksPort,
                SPEEDTEST_PORT, 50, new SpeedTest.Listener() {
            @Override public void onProgress(double mbps) { if (tuneStage == T_TEST && tuneIdx == my) { showSpeed(mbps); speedGraph.add(mbps); } }
            @Override public void onDone(double mbps) { if (tuneStage == T_TEST && tuneIdx == my) tuneRecord(mbps); }
            @Override public void onError(String message) { if (tuneStage == T_TEST && tuneIdx == my) tuneRecord(0); }
            @Override public void onCancelled() { }
        });
    }

    private void tuneRecord(double mbps) {
        tuneHandler.removeCallbacks(tuneTick);
        if (tuneStage == T_NONE) return;
        int[] c = tuneCur;
        TunnelService.appendLog("Auto: subidas " + c[0] + " / descargas " + c[1] + " / lote " + c[2]
                + " / registro " + c[3] + " / MTU " + c[4]
                + " \u2192 " + String.format(java.util.Locale.US, "%.1f", mbps) + " Mbps");
        tuneLast = c;
        tuneIdx++;
        if (tuneIsBase) {
            if (mbps <= 0) {   // sin la base no hay con qu\u00e9 comparar
                tuneBaseMbps = 0;
                tuneFinish();
                return;
            }
            tuneBaseMbps = mbps;
        } else if (mbps > tuneBaseMbps * 1.05) {
            tuneBase = c.clone();          // mejor\u00f3: se acepta y se sigue subiendo este mismo valor
            tuneBaseMbps = mbps;
        } else {
            tunePos++;                     // no mejor\u00f3: se deja el anterior y se pasa al siguiente valor
            tuneValIdx = -1;
        }
        tuneNext();
    }

    private int[] tuneLast;

    private void tuneFinish() {
        tuneHandler.removeCallbacks(tuneTick);
        if (tuneBaseMbps <= 0) {
            tuneStage = T_NONE;
            tuneCur = null;
            finishTuneUi();
            toast("No se pudo medir. Se dej\u00f3 la configuraci\u00f3n anterior.");
            return;
        }
        int[] c = tuneBase;
        if ("auto".equals(speed)) {
            prefs.edit().putInt("autoUp", c[0]).putInt("autoDown", c[1])
                    .putInt("autoBatch", c[2]).putInt("autoChunk", c[3]).putInt("autoMtu", c[4]).apply();
        } else {
            manUpEdit.setText(String.valueOf(c[0]));
            manDownEdit.setText(String.valueOf(c[1]));
            manBatchEdit.setText(String.valueOf(c[2]));
            manChunkEdit.setText(String.valueOf(c[3]));
            manMtuEdit.setText(String.valueOf(c[4]));
            saveFields();
        }
        TunnelService.appendLog("Auto: mejor combinaci\u00f3n \u2192 subidas " + c[0] + " / descargas " + c[1]
                + " / lote " + c[2] + " / registro " + c[3] + " / MTU " + c[4]
                + " (" + String.format(java.util.Locale.US, "%.1f", tuneBaseMbps) + " Mbps)");
        setSpeedText("Mejor: subidas " + c[0] + " / descargas " + c[1] + " / lote " + c[2]
                + " / registro " + c[3] + " / MTU " + c[4]);
        showSpeed(tuneBaseMbps);
        toast("Listo: " + String.format(java.util.Locale.US, "%.1f", tuneBaseMbps) + " Mbps con subidas " + c[0]
                + ", descargas " + c[1] + ", lote " + c[2] + ", registro " + c[3] + ", MTU " + c[4]);
        if (tuneLast != null && java.util.Arrays.equals(tuneLast, c) && TunnelService.state == TunnelService.ST_CONNECTED) {
            tuneStage = T_NONE;   // ya est\u00e1 conectado con la mejor combinaci\u00f3n
            tuneCur = null;
            finishTuneUi();
            return;
        }
        tuneStage = T_FINAL_STOP;
        tuneDeadline = System.currentTimeMillis() + 15_000;
        startService(new Intent(this, TunnelService.class).setAction(TunnelService.ACTION_STOP));
        tuneHandler.postDelayed(tuneTick, 500);
    }

    private void cancelAutoTune(String msg) {
        tuneHandler.removeCallbacks(tuneTick);
        if (tuneStage == T_TEST) SpeedTest.stop();
        tuneStage = T_NONE;
        tuneCur = null;
        finishTuneUi();
        toast(msg);
    }

    private void finishTuneUi() {
        if (btnTune != null) btnTune.setText("Buscar mejor velocidad (auto)");
        speedTestBtn.setText("\u25b6");
    }

    // ------------------------------------------------------------------ prueba de velocidad en cada puerto

    private static final int P_NONE = 0, P_STOP = 1, P_CONNECT = 2, P_TEST = 3, P_FINAL_STOP = 4;
    private int pStage = P_NONE, pIdx, pOrigIdx, pTarget;
    private double[] pMbps;
    private List<Integer> pPorts;
    private long pDeadline;
    private Button btnPortTest;
    private final Runnable pTick = new Runnable() {
        @Override public void run() { portStep(); }
    };

    private boolean portTesting() { return pStage != P_NONE; }

    /** Para el registro: "Puerto #2" en Conecta HWID (nunca el n\u00famero); "Puerto #2 (puerto 8080)" en Conecta Generador. */
    private String portTag(int i) { return "Puerto #" + (i + 1); }

    private String portName(int i) {
        if (isClient() || pPorts == null || i >= pPorts.size()) return portTag(i);
        return portTag(i) + " (puerto " + pPorts.get(i) + ")";
    }

    private void startPortTest() {
        if (portTesting()) { portCancel("Prueba de puertos cancelada"); return; }
        if (tuning()) { toast("Espera a que termine la b\u00fasqueda autom\u00e1tica"); return; }
        if (SpeedTest.isRunning()) { toast("Espera a que termine la prueba de velocidad"); return; }
        if (parsePorts().size() < 2) { toast("Hace falta m\u00e1s de un puerto para comparar"); return; }
        boolean rufu = TunnelService.MODE_RUFU.equals(mode);
        if (hostEdit.getText().toString().trim().isEmpty()
                || (!rufu && userEdit.getText().toString().trim().isEmpty())) {
            toast(isClient() ? "Primero importa tu perfil" : "Primero completa el servidor"); return;
        }
        if (rufu && rufuId == null) { toast("Android no entreg\u00f3 el ID del dispositivo"); return; }
        if (VpnService.prepare(this) != null) {
            toast("Primero conecta una vez para aceptar el permiso de VPN"); return;
        }
        final int n = parsePorts().size();
        new AlertDialog.Builder(this)
                .setTitle("Probar velocidad en cada puerto")
                .setMessage("Se conectar\u00e1 por cada uno de los " + n + " puertos y medir\u00e1 la bajada por el t\u00fanel "
                        + "(unos 30 s por puerto, hasta 50 MB por prueba). Al final deja marcado el m\u00e1s r\u00e1pido.")
                .setPositiveButton("Empezar", (d, w) -> beginPortTest())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void beginPortTest() {
        saveFields();
        pPorts = new ArrayList<>(parsePorts());
        pOrigIdx = activePortIndex;
        pMbps = new double[pPorts.size()];
        pIdx = 0;
        btnPortTest.setText("Cancelar prueba de puertos");
        portNext();
    }

    private void portNext() {
        if (pIdx >= pPorts.size()) { portFinish(); return; }
        activePortIndex = pIdx;
        refreshPortChips();
        setSpeedText("Puertos " + (pIdx + 1) + "/" + pPorts.size() + ": " + portTag(pIdx));
        speedNumber.setText("0");
        speedGraph.clear();
        pStage = P_STOP;
        pDeadline = System.currentTimeMillis() + 15_000;
        if (TunnelService.state != TunnelService.ST_IDLE) {
            startService(new Intent(this, TunnelService.class).setAction(TunnelService.ACTION_STOP));
        }
        tuneHandler.removeCallbacks(pTick);
        tuneHandler.post(pTick);
    }

    /** Igual que la b\u00fasqueda autom\u00e1tica: se vigila con un temporizador, as\u00ed sigue aunque salgas de la app. */
    private void portStep() {
        if (pStage == P_NONE) return;
        int st = TunnelService.state;
        long now = System.currentTimeMillis();
        switch (pStage) {
            case P_STOP:
                if (st == TunnelService.ST_IDLE) {
                    pStage = P_CONNECT;
                    pDeadline = now + 45_000;
                    startTunnel();
                } else if (now > pDeadline) {
                    portCancel("No se pudo reiniciar el t\u00fanel");
                    return;
                }
                break;
            case P_CONNECT:
                if (st == TunnelService.ST_CONNECTED && TunnelService.activeSocksPort > 0) {
                    pStage = P_TEST;
                    pDeadline = now + 45_000;
                    tuneHandler.postDelayed(this::portRunTest, 2000);
                } else if (now > pDeadline) {
                    portRecord(0);
                    return;
                }
                break;
            case P_TEST:
                if (st == TunnelService.ST_IDLE) { portRecord(0); return; }
                if (now > pDeadline) { SpeedTest.stop(); portRecord(0); return; }
                break;
            case P_FINAL_STOP:
                if (st == TunnelService.ST_IDLE) {
                    pStage = P_NONE;
                    startTunnel();   // vuelve a conectar por el mejor puerto
                    finishPortUi();
                    return;
                } else if (now > pDeadline) {
                    pStage = P_NONE;
                    finishPortUi();
                    return;
                }
                break;
            default: return;
        }
        tuneHandler.postDelayed(pTick, 500);
    }

    private void portRunTest() {
        if (pStage != P_TEST) return;
        if (TunnelService.state != TunnelService.ST_CONNECTED || TunnelService.activeSocksPort <= 0) return;
        final int my = pIdx;
        SpeedTest.start(this, hostEdit.getText().toString().trim(), TunnelService.activeSocksPort,
                SPEEDTEST_PORT, 50, new SpeedTest.Listener() {
            @Override public void onProgress(double mbps) { if (pStage == P_TEST && pIdx == my) { showSpeed(mbps); speedGraph.add(mbps); } }
            @Override public void onDone(double mbps) { if (pStage == P_TEST && pIdx == my) portRecord(mbps); }
            @Override public void onError(String message) { if (pStage == P_TEST && pIdx == my) portRecord(0); }
            @Override public void onCancelled() { }
        });
    }

    private void portRecord(double mbps) {
        tuneHandler.removeCallbacks(pTick);
        if (pStage == P_NONE) return;
        pMbps[pIdx] = mbps;
        // En el registro, LogMask oculta el n\u00famero del puerto en Conecta HWID; aqu\u00ed ya viene como "Puerto #n".
        TunnelService.appendLog("Puertos: " + portName(pIdx) + " \u2192 "
                + String.format(java.util.Locale.US, "%.1f", mbps) + " Mbps");
        pIdx++;
        portNext();
    }

    private void portFinish() {
        tuneHandler.removeCallbacks(pTick);
        double max = 0;
        for (double v : pMbps) max = Math.max(max, v);
        int target = pOrigIdx;
        if (max > 0) {
            // El primero que llegue al 95% de la mejor: se respeta el orden en que el administrador puso los puertos.
            for (int i = 0; i < pMbps.length; i++) if (pMbps[i] >= max * 0.95) { target = i; break; }
            setSpeedText("Mejor: " + portTag(target));
            showSpeed(pMbps[target]);
            toast("Listo: " + portTag(target) + " (" + String.format(java.util.Locale.US, "%.1f", pMbps[target]) + " Mbps)");
        } else {
            toast("No se pudo medir ning\u00fan puerto. Se dej\u00f3 el que ten\u00edas.");
        }
        activePortIndex = target;
        saveFields();
        refreshPortChips();
        if (target == pPorts.size() - 1 && TunnelService.state == TunnelService.ST_CONNECTED) {
            pStage = P_NONE;   // ya est\u00e1 conectado por ese puerto
            finishPortUi();
            return;
        }
        pStage = P_FINAL_STOP;
        pDeadline = System.currentTimeMillis() + 15_000;
        startService(new Intent(this, TunnelService.class).setAction(TunnelService.ACTION_STOP));
        tuneHandler.postDelayed(pTick, 500);
    }

    private void portCancel(String msg) {
        tuneHandler.removeCallbacks(pTick);
        if (pStage == P_TEST) SpeedTest.stop();
        pStage = P_NONE;
        activePortIndex = pOrigIdx;
        saveFields();
        refreshPortChips();
        finishPortUi();
        toast(msg);
    }

    private void finishPortUi() {
        if (btnPortTest != null) btnPortTest.setText("Probar velocidad en cada puerto");
        speedTestBtn.setText("\u25b6");
    }

    /** Texto de arriba del medidor: si es largo (resultados de la calibraci\u00f3n) usa letra m\u00e1s chica y varias l\u00edneas para verse completo. */
    private void setSpeedText(CharSequence t) {
        boolean longText = t != null && t.length() > 36;
        speedLabel.setTextSize(longText ? 11f : 14f);
        speedLabel.setMaxLines(longText ? 3 : 2);
        speedLabel.setGravity(Gravity.CENTER);
        speedLabel.setText(t);
        speedLabel.setVisibility(t == null || t.length() == 0 ? android.view.View.GONE : android.view.View.VISIBLE);
    }

    private void toggleSpeedTest() {
        if (tuning() || portTesting()) { toast("Espera: hay una b\u00fasqueda midiendo"); return; }
        if (SpeedTest.isRunning()) {
            SpeedTest.stop();
            return;
        }
        if (TunnelService.state != TunnelService.ST_CONNECTED || TunnelService.activeSocksPort <= 0) {
            toast("Con\u00e9ctate primero para medir tu velocidad");
            return;
        }
        String host = hostEdit.getText().toString().trim();
        if (host.isEmpty()) {
            toast("Falta el servidor");
            return;
        }
        setSpeedText("Midiendo tu velocidad\u2026");
        speedNumber.setText("0");
        speedUnit.setText("Kbps");
        speedGraph.clear();
        speedTestBtn.setText("\u25a0");
        SpeedTest.start(this, host, TunnelService.activeSocksPort, SPEEDTEST_PORT, 50, new SpeedTest.Listener() {
            @Override public void onProgress(double mbps) {
                showSpeed(mbps);
                speedGraph.add(mbps);
            }
            @Override public void onDone(double mbps) {
                showSpeed(mbps);
                setSpeedText("Tu velocidad de bajada es de");
                speedTestBtn.setText("\u25b6");
            }
            @Override public void onError(String message) {
                setSpeedText("");
                speedNumber.setText("\u2014");
                speedTestBtn.setText("\u25b6");
                toast(message);
            }
            @Override public void onCancelled() {
                setSpeedText("");
                speedNumber.setText("\u2014");
                speedTestBtn.setText("\u25b6");
            }
        });
    }

    /** IP privada del teléfono en su red real (Wi-Fi o datos), no la de la VPN. */
    private String localIp() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                if (nc == null || nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue;
                boolean wifi = nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
                boolean cell = nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR);
                boolean eth = nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET);
                if (!wifi && !cell && !eth) continue;
                LinkProperties lp = cm.getLinkProperties(n);
                if (lp == null) continue;
                for (LinkAddress la : lp.getLinkAddresses()) {
                    InetAddress a = la.getAddress();
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        return a.getHostAddress() + (wifi ? " (Wi-Fi)" : cell ? " (datos m\u00f3viles)" : " (cable)");
                    }
                }
            }
        } catch (Throwable ignored) { }
        return "\u2014";
    }

    // ------------------------------------------------------------------ HWID oculto, perfil bloqueado

    private String currentHwid() {
        boolean rufu = TunnelService.MODE_RUFU.equals(mode);
        String v = rufu ? rufuId : keyHwid;
        return v == null ? "No disponible" : v;
    }

    private void renderHwid() {
        String v = currentHwid();
        if (hwidShown || v.equals("No disponible")) { hwidView.setText(v); return; }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < v.length(); i++) sb.append(i < 2 || v.charAt(i) == '-' ? v.charAt(i) : '\u25CF');
        hwidView.setText(sb.toString());
    }

    /**
     * "Conecta HWID" (cliente): el perfil siempre queda bloqueado, sin importar lo que diga el archivo.
     * "Conecta Generador": siempre desbloqueado; los archivos que se importan salen editables.
     */
    private boolean isLocked() { return isClient(); }

    private void refreshSecrets() {
        if (hostEdit == null) return;
        LogMask.setSecrets(hostEdit.getText().toString(), userEdit.getText().toString(), rufuId, keyHwid);
        // En "Conecta HWID" (cliente) tampoco se muestran los puertos en el registro.
        java.util.List<Integer> hide = new java.util.ArrayList<>(parsePorts());
        hide.add(udpPort());
        LogMask.setPorts(isClient(), hide);
    }

    /** true en "Conecta HWID": la que reciben los clientes, sin campos para tocar, solo Importar. */
    private boolean isClient() { return BuildConfig.CLIENT_VARIANT; }

    /** Si la compilaci\u00f3n trae un servidor integrado (secretos de GitHub), lo precarga. */
    private void applyFixed() {
        if (BuildConfig.SERVER_HOST.isEmpty()) return;
        if (prefs.getBoolean("overrideImported", false)) return;   // ya se import\u00f3 un perfil propio: no pisarlo
        hostEdit.setText(BuildConfig.SERVER_HOST);
        portEdit.setText(BuildConfig.SERVER_PORTS.isEmpty()
                ? String.valueOf(BuildConfig.SERVER_PORT) : BuildConfig.SERVER_PORTS);
        udpPortEdit.setText(String.valueOf(BuildConfig.UDPGW_PORT));
        if (!BuildConfig.AI_TOKEN.isEmpty()) {
            aiSwitch.setChecked(true);
            aiPortEdit.setText(String.valueOf(BuildConfig.AI_PORT));
            aiTokenEdit.setText(BuildConfig.AI_TOKEN);
        }
        mode = TunnelService.MODE_RUFU;
        prefs.edit().putString("mode", mode).putBoolean("locked", false).apply();
    }

    private void updateVisibility() {
        boolean client = isClient();
        boolean locked = isLocked() || client;   // en la variante cliente, los campos siempre quedan ocultos
        boolean rufu = TunnelService.MODE_RUFU.equals(mode);
        boolean hasProfile = !hostEdit.getText().toString().trim().isEmpty();

        modesRow.setVisibility(client ? android.view.View.GONE : android.view.View.VISIBLE);
        profileRow.setVisibility(android.view.View.VISIBLE);
        btnExport.setVisibility(client ? android.view.View.GONE : android.view.View.VISIBLE);
        btnExport.setAlpha(isLocked() ? 0.4f : 1f);

        serverRow.setVisibility(locked ? android.view.View.GONE : android.view.View.VISIBLE);
        userEdit.setVisibility(locked || rufu ? android.view.View.GONE : android.view.View.VISIBLE);
        udpPortEdit.setVisibility(locked || !udpSwitch.isChecked() ? android.view.View.GONE : android.view.View.VISIBLE);
        if (manualRow != null) manualRow.setVisibility("manual".equals(speed) && !locked ? android.view.View.VISIBLE : android.view.View.GONE);   // perfil bloqueado: ocultar los 4 campos manuales

        boolean showInfo = isLocked() || (client && hasProfile);
        lockedBox.setVisibility(showInfo ? android.view.View.VISIBLE : android.view.View.GONE);
        lockedBtn.setVisibility(showInfo ? android.view.View.VISIBLE : android.view.View.GONE);
        String pn = prefs.getString("profileName", "");
        String pnPart = pn.isEmpty() ? "" : ": " + pn;
        lockedView.setText(client
                ? "\uD83D\uDD12 Perfil cargado" + pnPart + "\nDatos del servidor ocultos."
                : "\uD83D\uDD12 Perfil bloqueado" + pnPart + "\nDatos del servidor ocultos.");
        noProfileView.setVisibility(client && !hasProfile ? android.view.View.VISIBLE : android.view.View.GONE);
        updateTuneButton();
        updateAiVisibility();
    }

    private void applyLocked() { updateVisibility(); }

    private void removeLockedProfile() {
        new AlertDialog.Builder(this)
                .setTitle(isClient() ? "\u00bfQuitar el perfil?" : "\u00bfQuitar el perfil bloqueado?")
                .setMessage("Se borrar\u00e1n el servidor, el puerto y el usuario guardados. "
                        + "Para volver a usarlos tendr\u00e1s que importar el archivo otra vez.")
                .setPositiveButton("Quitar", (d, w) -> doRemoveLockedProfile())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void doRemoveLockedProfile() {
        hostEdit.setText("");
        portEdit.setText("");
        userEdit.setText("");
        udpPortEdit.setText("7300");
        prefs.edit().putBoolean("locked", false).putBoolean("overrideImported", false).remove("profileName").apply();
        saveFields();
        applyFixed();
        updateVisibility();
        refreshPortChips();
        toast(isClient() ? "Perfil eliminado" : "Perfil bloqueado eliminado");
    }

    // ------------------------------------------------------------------ importar / exportar

    private String profileJson(boolean lock) throws org.json.JSONException {
        JSONObject o = new JSONObject();
        o.put("v", 1);
        o.put("mode", mode);
        o.put("host", hostEdit.getText().toString().trim());
        o.put("port", portEdit.getText().toString().trim());
        o.put("portIndex", activePortIndex);
        o.put("ai", aiSwitch.isChecked());
        o.put("aiPort", aiPortEdit.getText().toString().trim());
        o.put("aiToken", aiTokenEdit.getText().toString().trim());
        o.put("user", userEdit.getText().toString().trim());
        o.put("speed", speed);
        o.put("manUp", manualValue(manUpEdit, 4, 1, 64));
        o.put("manDown", manualValue(manDownEdit, 8, 1, 128));
        o.put("manBatch", manualValue(manBatchEdit, 8, 1, 32));
        o.put("manChunk", manualValue(manChunkEdit, 1399, 64, 9000));
        o.put("manMtu", manualValue(manMtuEdit, 1500, 1280, 9000));
        o.put("udp", udpSwitch.isChecked());
        o.put("udpgw", udpPort());
        o.put("locked", lock);
        return o.toString();
    }

    private void startExport() {
        if (isClient()) return;   // esta variante no exporta; el bot\u00f3n ya est\u00e1 oculto
        if (isLocked()) { toast("Perfil bloqueado: no se puede exportar"); return; }
        if (hostEdit.getText().toString().trim().isEmpty()) { toast("Primero completa el servidor"); return; }
        final CheckBox lock = new CheckBox(this);
        lock.setText("Bloquear: ocultar los datos a quien lo importe");
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(lock);
        new AlertDialog.Builder(this)
                .setTitle("Exportar perfil")
                .setView(box)
                .setPositiveButton("Continuar", (d, w) -> {
                    try {
                        pendingExport = ProfileCrypto.encrypt(profileJson(lock.isChecked()), ProfileKey.VALUE);
                    } catch (Exception e) {
                        toast("No se pudo cifrar el perfil");
                        return;
                    }
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/octet-stream");
                    i.putExtra(Intent.EXTRA_TITLE, "perfil.conecta");
                    startActivityForResult(i, REQ_EXPORT);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void startAiLicenseImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_AI_LICENSE);
    }

    /** Abre la licencia de IA (archivo cifrado con el HWID de este dispositivo) y activa el asistente. */
    private void activateAiLicense(String text) {
        if (isClient()) { toast("Esta versi\u00f3n no incluye el asistente de IA"); return; }
        if (rufuId == null) { toast("No se pudo leer el ID de este dispositivo"); return; }
        try {
            AiLicense.activate(this, text, rufuId);
            aiSwitch.setChecked(true);
            updateAiVisibility();
            toast("IA activada en este dispositivo");
        } catch (Exception e) {
            toast("Ese archivo no es para este dispositivo o est\u00e1 da\u00f1ado");
        }
    }

    private void startImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_IMPORT);
    }

    private String readText(Uri u) throws IOException {
        try (InputStream in = getContentResolver().openInputStream(u)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n, total = 0;
            while ((n = in.read(b)) >= 0) {
                total += n;
                if (total > 65536) throw new IOException("Archivo demasiado grande");
                bo.write(b, 0, n);
            }
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    /** Nombre visible del archivo (por ejemplo "cliente1.conecta"), o "" si no se puede saber. */
    private String fileName(Uri u) {
        String name = null;
        try (android.database.Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (i >= 0) name = c.getString(i);
            }
        } catch (Exception ignored) { }
        if (name == null || name.trim().isEmpty()) name = u.getLastPathSegment();
        if (name == null) return "";
        int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        return name.trim();
    }

    private void importProfile(final String text, final String name) {
        String json;
        try {
            json = ProfileCrypto.decrypt(text, ProfileKey.VALUE);
        } catch (Exception e) {
            toast("Archivo da\u00f1ado o de otra app");
            return;
        }
        applyProfile(json, name);
    }

    private void applyProfile(String json, String name) {
        try {
            JSONObject o = new JSONObject(json);
            String h = o.optString("host", "").trim();
            if (h.isEmpty()) throw new IllegalArgumentException("sin servidor");
            hostEdit.setText(h);
            portEdit.setText(o.optString("port", ""));
            activePortIndex = o.optInt("portIndex", 0);
            aiSwitch.setChecked(o.optBoolean("ai", false));
            aiPortEdit.setText(o.optString("aiPort", "8766"));
            aiTokenEdit.setText(o.optString("aiToken", ""));
            userEdit.setText(o.optString("user", ""));
            mode = TunnelService.MODE_KEY.equals(o.optString("mode")) ? TunnelService.MODE_KEY : TunnelService.MODE_RUFU;
            speed = "manual".equals(o.optString("speed", "auto")) ? "manual" : "auto";
            manUpEdit.setText(String.valueOf(Math.max(1, Math.min(64, o.optInt("manUp", 4)))));
            manDownEdit.setText(String.valueOf(Math.max(1, Math.min(128, o.optInt("manDown", 8)))));
            manBatchEdit.setText(String.valueOf(Math.max(1, Math.min(32, o.optInt("manBatch", 8)))));
            manChunkEdit.setText(String.valueOf(Math.max(64, Math.min(9000, o.optInt("manChunk", 1399)))));
            manMtuEdit.setText(String.valueOf(Math.max(1280, Math.min(9000, o.optInt("manMtu", 1500)))));
            udpSwitch.setChecked(o.optBoolean("udp", true));
            udpPortEdit.setText(String.valueOf(o.optInt("udpgw", 7300)));
            prefs.edit()
                    .putString("mode", mode)
                    .putString("speed", speed)
                    .putBoolean("locked", isClient())   // el bloqueo lo decide la variante, no el archivo
                    .putBoolean("overrideImported", true)
                    .putBoolean("autoDone", false)   // perfil nuevo: en Automático se vuelve a buscar la mejor velocidad
                    .putString("profileName", name == null ? "" : name)
                    .apply();
            saveFields();
            applyMode();
            applySpeed();
            updateVisibility();
            refreshPortChips();
            updateAiVisibility();
            toast(isLocked() ? "Perfil importado (datos ocultos)" : "Perfil importado");
        } catch (Exception e) {
            toast("El archivo no tiene un perfil v\u00e1lido");
        }
    }

    // ------------------------------------------------------------------ interfaz

    private void window() {
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
    }

    private void buildUi() {
        final int gray = Color.rgb(44, 68, 98);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(navy);

        // ---- barra de velocidad (fija, arriba de todo) ----
        FrameLayout bar = new FrameLayout(this);
        bar.setBackgroundColor(Color.rgb(11, 28, 48));
        bar.setPadding(dp(14), dp(16), dp(14), dp(12));

        LinearLayout centerCol = new LinearLayout(this);
        centerCol.setOrientation(LinearLayout.VERTICAL);
        centerCol.setGravity(Gravity.CENTER);

        speedLabel = text("", 14, pale, false);
        speedLabel.setGravity(Gravity.CENTER);
        speedLabel.setMaxWidth(dp(320));   // si el texto es largo, baja de l\u00ednea en vez de salirse de la pantalla
        speedLabel.setVisibility(android.view.View.GONE);   // solo aparece cuando hay un avance o un resultado
        centerCol.addView(speedLabel, lp(-1, -2, 0, 6));

        LinearLayout numberRow = new LinearLayout(this);
        numberRow.setOrientation(LinearLayout.HORIZONTAL);
        numberRow.setGravity(Gravity.BOTTOM);
        speedNumber = text("\u2014", 52, Color.WHITE, true);
        speedUnit = text("Kbps", 20, pale, true);
        speedUnit.setPadding(dp(8), 0, 0, dp(10));
        numberRow.addView(speedNumber);
        numberRow.addView(speedUnit);
        centerCol.addView(numberRow, lp(-2, -2, 0, 4));

        speedGraph = new SpeedGraphView(this);
        centerCol.addView(speedGraph, lp(dp(240), dp(60), 0, 4));

        Button fastLink = button("fast.com", blue);
        fastLink.setTextSize(14);
        fastLink.setOnClickListener(v -> openFastCom());
        centerCol.addView(fastLink, lp(dp(190), dp(42), 6, 0));

        // Texto fijo debajo del bot\u00f3n, en rojo.
        TextView fastHint = text("Mide tu velocidad con fast.com", 13, Color.rgb(255, 82, 82), true);
        fastHint.setGravity(Gravity.CENTER);
        centerCol.addView(fastHint, lp(-1, -2, 6, 0));

        FrameLayout.LayoutParams colParams = new FrameLayout.LayoutParams(-2, -2);
        colParams.gravity = Gravity.CENTER;
        bar.addView(centerCol, colParams);

        speedTestBtn = button("\u25b6", Color.rgb(44, 68, 98));
        speedTestBtn.setTextSize(16);
        speedTestBtn.setOnClickListener(v -> toggleSpeedTest());
        FrameLayout.LayoutParams btnParams = new FrameLayout.LayoutParams(dp(40), dp(40));
        btnParams.gravity = Gravity.TOP | Gravity.END;
        bar.addView(speedTestBtn, btnParams);
        // Oculto: la prueba de velocidad ahora se hace con el enlace de fast.com. El bot\u00f3n sigue existiendo
        // en el c\u00f3digo (la b\u00fasqueda autom\u00e1tica usa la misma medici\u00f3n), pero nadie puede pulsarlo.
        speedTestBtn.setVisibility(android.view.View.GONE);

        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(16));
        scroll.addView(c);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        // ---- cabecera: logo + t\u00edtulo + estado + IP ----
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_logo);
        head.addView(logo, new LinearLayout.LayoutParams(dp(50), dp(50)));
        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.setPadding(dp(12), 0, 0, 0);
        ht.addView(text("Conecta HWID", 22, Color.WHITE, true));
        statusView = text("\u25CF Desconectado", 13, Color.rgb(150, 165, 185), true);
        ht.addView(statusView);
        ipView = text("IP local: \u2014", 11, pale, false);
        ht.addView(ipView);
        head.addView(ht, new LinearLayout.LayoutParams(0, -2, 1f));
        lockedBtn = button("\uD83D\uDDD1", Color.rgb(110, 48, 56));
        lockedBtn.setTextSize(18);
        lockedBtn.setPadding(0, 0, 0, 0);
        lockedBtn.setBackground(rounded(Color.rgb(110, 48, 56), 18));
        lockedBtn.setOnClickListener(v -> removeLockedProfile());
        LinearLayout.LayoutParams lbp = new LinearLayout.LayoutParams(dp(36), dp(36));
        lbp.gravity = Gravity.TOP;
        head.addView(lockedBtn, lbp);
        c.addView(head, lp(-1, -2, 0, 10));

        mainButton = button("Conectar", green);
        mainButton.setTextSize(16);
        mainButton.setOnClickListener(v -> onMainClick());
        c.addView(mainButton, lp(-1, dp(48), 0, 8));

        // ---- modo ----
        LinearLayout modes = modesRow = new LinearLayout(this);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        modeRufu = button("HWID", blue);
        modeRufu.setOnClickListener(v -> setMode(TunnelService.MODE_RUFU));
        modeKey = button("HWID por llave", blue);
        modeKey.setOnClickListener(v -> setMode(TunnelService.MODE_KEY));
        modes.addView(modeRufu, new LinearLayout.LayoutParams(0, dp(38), 1f));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        mp.leftMargin = dp(8);
        modes.addView(modeKey, mp);
        c.addView(modes, lp(-1, -2, 0, 8));

        // ---- tarjeta HWID: c\u00f3digo + bot\u00f3n copiar en la misma fila ----
        LinearLayout hw = new LinearLayout(this);
        hw.setOrientation(LinearLayout.VERTICAL);
        hw.setPadding(dp(12), dp(8), dp(8), dp(8));
        hw.setBackground(rounded(card, 14));
        LinearLayout hrow = new LinearLayout(this);
        hrow.setOrientation(LinearLayout.HORIZONTAL);
        hrow.setGravity(Gravity.CENTER_VERTICAL);
        hwidView = text("\u2026", 16, Color.WHITE, true);
        hwidView.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        hwidView.setSingleLine(true);
        hwidView.setOnClickListener(v -> { hwidShown = !hwidShown; renderHwid(); });
        hrow.addView(hwidView, new LinearLayout.LayoutParams(0, -2, 1f));
        btnA = button("Copiar HWID", blue);
        hrow.addView(btnA, new LinearLayout.LayoutParams(-2, dp(38)));
        hw.addView(hrow, new LinearLayout.LayoutParams(-1, -2));
        keyExtra = new LinearLayout(this);
        keyExtra.setOrientation(LinearLayout.VERTICAL);
        btnB = button("Compartir", gray);
        keyExtra.addView(btnB, lp(-1, dp(36), 8, 4));
        hintView = text("", 11, pale, false);
        keyExtra.addView(hintView);
        hw.addView(keyExtra, new LinearLayout.LayoutParams(-1, -2));
        c.addView(hw, lp(-1, -2, 0, 8));

        // ---- perfil bloqueado ----
        lockedBox = new LinearLayout(this);
        lockedBox.setOrientation(LinearLayout.VERTICAL);
        lockedBox.setPadding(dp(12), dp(8), dp(12), dp(8));
        lockedBox.setBackground(rounded(card, 12));
        lockedView = text("\uD83D\uDD12 Perfil bloqueado: datos del servidor ocultos.", 13, Color.WHITE, false);
        lockedBox.addView(lockedView, lp(-1, -2, 0, 0));
        c.addView(lockedBox, lp(-1, -2, 0, 8));

        noProfileView = text("Sin perfil cargado. Toca Importar o abre el archivo que te compartieron.", 13, pale, false);
        c.addView(noProfileView, lp(-1, -2, 0, 8));

        // ---- servidor + puerto(s) en una fila ----
        serverRow = new LinearLayout(this);
        serverRow.setOrientation(LinearLayout.HORIZONTAL);
        hostEdit = edit("Servidor (IP o dominio)", prefs.getString("host", ""), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        portEdit = edit("Puerto(s): 443,8080", prefs.getString("port", ""), InputType.TYPE_CLASS_TEXT);
        portEdit.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { refreshPortChips(); }
        });
        serverRow.addView(hostEdit, new LinearLayout.LayoutParams(0, dp(44), 1f));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(118), dp(44));
        pp.leftMargin = dp(8);
        serverRow.addView(portEdit, pp);
        c.addView(serverRow, lp(-1, -2, 0, 6));

        // ---- puerto activo: un bot\u00f3n por puerto (sin l\u00edmite), visible siempre que haya m\u00e1s de uno ----
        portChipsRow = new LinearLayout(this);
        portChipsRow.setOrientation(LinearLayout.VERTICAL);
        c.addView(portChipsRow, lp(-1, -2, 0, 8));
        btnPortTest = button("Probar velocidad en cada puerto", Color.rgb(44, 68, 98));
        btnPortTest.setOnClickListener(v -> startPortTest());
        btnPortTest.setVisibility(android.view.View.GONE);
        c.addView(btnPortTest, lp(-1, dp(44), 0, 8));

        userEdit = edit("Usuario SSH", prefs.getString("user", ""), InputType.TYPE_CLASS_TEXT);
        c.addView(userEdit, lp(-1, dp(44), 0, 8));

        // ---- velocidad ----
        LinearLayout sp2 = new LinearLayout(this);
        sp2.setOrientation(LinearLayout.HORIZONTAL);
        speedAuto = button("Autom\u00e1tico", blue);
        speedAuto.setOnClickListener(v -> setSpeed("auto"));
        sp2.addView(speedAuto, new LinearLayout.LayoutParams(0, dp(38), 1f));
        speedManual = button("Manual", blue);
        speedManual.setOnClickListener(v -> setSpeed("manual"));
        LinearLayout.LayoutParams l4 = new LinearLayout.LayoutParams(0, dp(38), 1f);
        l4.leftMargin = dp(8);
        sp2.addView(speedManual, l4);
        c.addView(sp2, lp(-1, -2, 0, 4));

        // ---- Manual: conexiones en paralelo elegidas por el usuario ----
        manualRow = new LinearLayout(this);
        manualRow.setOrientation(LinearLayout.VERTICAL);
        manUpEdit = edit("Subidas (1-64)", prefs.getString("manUp", "4"), InputType.TYPE_CLASS_NUMBER);
        manDownEdit = edit("Descargas (1-128)", prefs.getString("manDown", "8"), InputType.TYPE_CLASS_NUMBER);
        manBatchEdit = edit("Lote (1-32)", prefs.getString("manBatch", "8"), InputType.TYPE_CLASS_NUMBER);
        manChunkEdit = edit("Registro (64-9000)", prefs.getString("manChunk", "1399"), InputType.TYPE_CLASS_NUMBER);
        manMtuEdit = edit("MTU (1280-9000)", prefs.getString("manMtu", "1500"), InputType.TYPE_CLASS_NUMBER);
        LinearLayout mrow1 = new LinearLayout(this);
        mrow1.setOrientation(LinearLayout.HORIZONTAL);
        mrow1.addView(manUpEdit, new LinearLayout.LayoutParams(0, dp(40), 1f));
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(0, dp(40), 1f);
        ml.leftMargin = dp(8);
        mrow1.addView(manDownEdit, ml);
        LinearLayout mrow2 = new LinearLayout(this);
        mrow2.setOrientation(LinearLayout.HORIZONTAL);
        mrow2.addView(manBatchEdit, new LinearLayout.LayoutParams(0, dp(40), 1f));
        LinearLayout.LayoutParams ml2 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        ml2.leftMargin = dp(8);
        mrow2.addView(manChunkEdit, ml2);
        manualRow.addView(mrow1, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams mr2 = new LinearLayout.LayoutParams(-1, -2);
        mr2.topMargin = dp(6);
        manualRow.addView(mrow2, mr2);
        LinearLayout.LayoutParams mr3 = new LinearLayout.LayoutParams(-1, dp(40));
        mr3.topMargin = dp(6);
        manualRow.addView(manMtuEdit, mr3);
        btnTune = button("Buscar mejor velocidad (auto)", Color.rgb(44, 68, 98));
        btnTune.setOnClickListener(v -> startAutoTune());
        c.addView(manualRow, lp(-1, -2, 0, 4));
        c.addView(btnTune, lp(-1, dp(44), 0, 8));

        // ---- BadVPN: interruptor + puerto en una fila ----
        LinearLayout urow = new LinearLayout(this);
        urow.setOrientation(LinearLayout.HORIZONTAL);
        urow.setGravity(Gravity.CENTER_VERTICAL);
        udpSwitch = compactSwitch("BadVPN para juegos (UDP)", prefs.getBoolean("udp", true));
        udpPortEdit = edit("Puerto", prefs.getString("udpgw", "7300"), InputType.TYPE_CLASS_NUMBER);
        udpSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { updateVisibility(); }
        });
        urow.addView(udpSwitch, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams up = new LinearLayout.LayoutParams(dp(92), dp(40));
        up.leftMargin = dp(8);
        urow.addView(udpPortEdit, up);
        c.addView(urow, lp(-1, -2, 0, 0));

        autoSwitch = compactSwitch("Reconectar autom\u00e1ticamente", prefs.getBoolean("auto", true));
        c.addView(autoSwitch, lp(-1, -2, 0, 8));

        // ---- asistente de IA (experimental): habla con tu proxy en el VPS, nunca directo con Gemini ----
        aiSwitch = compactSwitch("Asistente IA (experimental)", prefs.getBoolean("ai", false));
        c.addView(aiSwitch, lp(-1, -2, 0, 4));
        LinearLayout aiRow = aiRowView = new LinearLayout(this);
        aiRow.setOrientation(LinearLayout.HORIZONTAL);
        aiPortEdit = edit("Puerto IA", prefs.getString("aiPort", "8766"), InputType.TYPE_CLASS_NUMBER);
        aiTokenEdit = edit("Palabra secreta", prefs.getString("aiToken", ""), InputType.TYPE_CLASS_TEXT);
        LinearLayout.LayoutParams aip = new LinearLayout.LayoutParams(dp(100), dp(44));
        aiRow.addView(aiPortEdit, aip);
        LinearLayout.LayoutParams ait = new LinearLayout.LayoutParams(0, dp(44), 1f);
        ait.leftMargin = dp(8);
        aiRow.addView(aiTokenEdit, ait);
        c.addView(aiRow, lp(-1, -2, 0, 8));
        aiOpenBtn = button("Abrir asistente", Color.rgb(44, 68, 98));
        aiOpenBtn.setOnClickListener(v -> openAiAssistant());
        c.addView(aiOpenBtn, lp(-1, dp(44), 0, 8));
        aiLicenseBtn = button("Activar IA con archivo", Color.rgb(44, 68, 98));
        aiLicenseBtn.setOnClickListener(v -> startAiLicenseImport());
        c.addView(aiLicenseBtn, lp(-1, dp(44), 0, 8));
        aiSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { updateAiVisibility(); }
        });

        // ---- perfil cifrado ----
        LinearLayout pr = profileRow = new LinearLayout(this);
        pr.setOrientation(LinearLayout.HORIZONTAL);
        btnImport = button("Importar perfil", gray);
        btnImport.setOnClickListener(v -> startImport());
        btnExport = button("Exportar perfil", gray);
        btnExport.setOnClickListener(v -> startExport());
        pr.addView(btnImport, new LinearLayout.LayoutParams(0, dp(38), 1f));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(0, dp(38), 1f);
        pl.leftMargin = dp(8);
        pr.addView(btnExport, pl);
        c.addView(pr, lp(-1, -2, 0, 10));

        // ---- registro: t\u00edtulo + copiar/borrar en una fila ----
        LinearLayout lh = new LinearLayout(this);
        lh.setOrientation(LinearLayout.HORIZONTAL);
        lh.setGravity(Gravity.CENTER_VERTICAL);
        lh.addView(text("Registro", 12, pale, false), new LinearLayout.LayoutParams(0, -2, 1f));
        Button copyLog = button("Copiar", gray);
        copyLog.setTextSize(12);
        copyLog.setOnClickListener(v -> clip("Registro", logView.getText().toString(), "Registro copiado"));
        btnClearLog = button("Borrar", gray);
        btnClearLog.setTextSize(12);
        btnClearLog.setOnClickListener(v -> { TunnelService.clearLogs(); logView.setText(TunnelService.logsSnapshot()); });
        lh.addView(copyLog, new LinearLayout.LayoutParams(-2, dp(30)));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, dp(30));
        cl.leftMargin = dp(6);
        lh.addView(btnClearLog, cl);
        c.addView(lh, lp(-1, -2, 0, 4));

        logScroll = new ScrollView(this);
        logView = text("", 11, pale, false);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setPadding(dp(10), dp(8), dp(10), dp(8));
        logScroll.setBackground(rounded(Color.rgb(11, 28, 48), 12));
        logScroll.addView(logView);
        c.addView(logScroll, new LinearLayout.LayoutParams(-1, dp(120)));

        setContentView(root);
    }

    private Switch compactSwitch(String label, boolean checked) {
        Switch sw = new Switch(this);
        sw.setText(label);
        sw.setTextColor(Color.WHITE);
        sw.setTextSize(14);
        sw.setChecked(checked);
        sw.setMinHeight(0);
        sw.setMinimumHeight(0);
        sw.setPadding(0, dp(4), 0, dp(4));
        return sw;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private EditText edit(String hint, String value, int inputType) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setInputType(inputType);
        e.setSingleLine(true);
        e.setTextSize(14);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.rgb(120, 145, 175));
        e.setPadding(dp(12), 0, dp(12), 0);
        e.setBackground(rounded(card, 12));
        return e;
    }

    private Button button(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.WHITE);
        b.setStateListAnimator(null);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        setBg(b, color);
        return b;
    }

    private void setBg(Button b, int color) { b.setBackground(rounded(color, 14)); }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top);
        p.bottomMargin = dp(bottom);
        return p;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
