package com.mivpn.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.ApplicationExitInfo;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements TunnelService.Listener {
    private static final int REQ_VPN = 1;
    private static final int REQ_NOTIF = 2;
    private static final int REQ_EXPORT = 3;
    private static final int REQ_IMPORT = 4;
    private static final int REQ_AI_LICENSE = 5;

    private final int navy = Color.rgb(7, 20, 38);
    private final int card = Color.rgb(19, 43, 70);
    private final int blue = Color.rgb(0, 132, 255);
    private final int green = Color.rgb(0, 190, 125);
    private final int red = Color.rgb(214, 69, 69);
    private final int pale = Color.rgb(205, 224, 245);

    private TextView statusView, logView, hwidView;
    private EditText hostEdit, portEdit, userEdit;
    private Button mainButton, btnA, btnB, modeRufu, modeKey;
    private TextView hintView;
    private Button speedNormal, speedRapido, speedMax;
    private Switch udpSwitch, autoSwitch;
    private EditText udpPortEdit;
    private String speed = "maximo";
    private int activePortIndex = 0;
    private Switch aiSwitch;
    private EditText aiPortEdit, aiTokenEdit;
    private LinearLayout aiRowView;
    private Button aiLicenseBtn;
    private Button aiOpenBtn;
    private Button[] portChips = new Button[5];
    private LinearLayout portChipsRow;
    private String mode = TunnelService.MODE_RUFU;
    private String rufuId;
    private ScrollView logScroll;
    private SharedPreferences prefs;
    private String publicLine = "";
    private String keyHwid;
    private TextView ipView, lockedView, noProfileView;
    private TextView speedLabel, speedNumber, speedUnit;
    private SpeedGraphView speedGraph;
    private Button speedTestBtn;
    private static final int SPEEDTEST_PORT = 8767;   // puerto del servidor de prueba en el VPS
    private Button lockedBtn, btnImport, btnExport, btnClearLog;
    private LinearLayout lockedBox, serverRow, keyExtra, modesRow, profileRow;
    private String pendingExport;
    private String pendingV2;
    private Button v2Btn;
    private boolean hwidShown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        window();
        mode = prefs.getString("mode", TunnelService.MODE_RUFU);
        speed = prefs.getString("speed", "maximo");
        activePortIndex = prefs.getInt("portIndex", 0);
        rufuId = DeviceIdentity.rufuHwid(this);
        try { keyHwid = DeviceIdentity.hwid(this); publicLine = DeviceIdentity.publicLine(this); }
        catch (Exception e) { keyHwid = null; publicLine = ""; }
        buildUi();
        applyFixed();
        applyMode();
        refreshPortChips();
        updateAiVisibility();
        applySpeed();
        applyLocked();
        refreshSecrets();
        reportPreviousFailure();
        handleIncomingFile(getIntent());

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIF);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        TunnelService.listener = this;
        logView.setText(TunnelService.logsSnapshot());
        applyState(TunnelService.state, TunnelService.stateText);
        ipView.setText("IP local: " + localIp());
    }

    @Override
    protected void onPause() {
        saveFields();
        if (TunnelService.listener == this) TunnelService.listener = null;
        super.onPause();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingFile(intent);
    }

    /** Perfil recibido por "Abrir con" (VIEW) o "Compartir" (SEND), por ejemplo desde WhatsApp. */
    private void handleIncomingFile(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        Uri data = Intent.ACTION_VIEW.equals(action) ? intent.getData()
                : Intent.ACTION_SEND.equals(action) ? intent.getParcelableExtra(Intent.EXTRA_STREAM)
                : null;
        if (data == null) return;
        setIntent(new Intent());   // no reprocesar el mismo archivo si la pantalla se recrea
        try {
            String text = readText(data);
            if (AiLicense.looks(text)) { activateAiLicense(text); return; }
            if (!ProfileCrypto.looksEncrypted(text)) { toast("Ese archivo no es un perfil de Conecta"); return; }
            importProfile(text, fileName(data));
        } catch (Exception e) {
            toast("No se pudo leer el archivo recibido");
        }
    }

    // ------------------------------------------------------------------ listener del servicio

    @Override
    public void onState(final int state, final String text) {
        runOnUiThread(new Runnable() { @Override public void run() { applyState(state, text); } });
    }

    @Override
    public void onLog(final String line) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                logView.append(line + "\n");
                logScroll.post(new Runnable() { @Override public void run() { logScroll.fullScroll(ScrollView.FOCUS_DOWN); } });
            }
        });
    }

    private void applyState(int state, String text) {
        boolean idle = state == TunnelService.ST_IDLE;
        if (idle && SpeedTest.isRunning()) SpeedTest.stop();
        statusView.setText("\u25CF " + text);
        statusView.setTextColor(state == TunnelService.ST_CONNECTED ? green
                : state == TunnelService.ST_CONNECTING ? Color.rgb(240, 180, 60) : Color.rgb(150, 165, 185));
        hostEdit.setEnabled(idle);
        portEdit.setEnabled(idle);
        userEdit.setEnabled(idle);
        modeRufu.setEnabled(idle);
        modeKey.setEnabled(idle);
        if (v2Btn != null) v2Btn.setEnabled(idle);
        speedNormal.setEnabled(idle);
        speedRapido.setEnabled(idle);
        speedMax.setEnabled(idle);
        udpSwitch.setEnabled(idle);
        udpPortEdit.setEnabled(idle);
        autoSwitch.setEnabled(idle);
        btnImport.setEnabled(idle);
        btnExport.setEnabled(idle);
        lockedBtn.setEnabled(idle);
        if (state == TunnelService.ST_CONNECTING) {
            mainButton.setText("Cancelar");
            setBg(mainButton, red);
        } else if (state == TunnelService.ST_CONNECTED) {
            mainButton.setText("Desconectar");
            setBg(mainButton, red);
        } else {
            mainButton.setText("Conectar");
            setBg(mainButton, green);
        }
    }

    /** Si la app se cerró sola la vez anterior, deja el motivo en el registro. */
    private void reportPreviousFailure() {
        String crash = App.takeCrash(this);
        if (crash != null) {
            TunnelService.appendLog("⚠ La app se cerró por este error:");
            String[] lines = crash.split("\n");
            for (int i = 0; i < lines.length && i < 14; i++) TunnelService.appendLog(lines[i]);
            return;
        }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                List<ApplicationExitInfo> l = am.getHistoricalProcessExitReasons(getPackageName(), 0, 1);
                if (l != null && !l.isEmpty()) {
                    ApplicationExitInfo i = l.get(0);
                    if (i.getTimestamp() > prefs.getLong("exitTs", 0)) {
                        prefs.edit().putLong("exitTs", i.getTimestamp()).apply();
                        int r = i.getReason();
                        // Se registran todos los motivos, incluso los que no son fallos de la app
                        // (memoria baja, ahorro de batería del fabricante, etc.), para saber por
                        // qué el sistema la cerró.
                        TunnelService.appendLog("\u26a0 La app se cerr\u00f3 antes: " + exitReasonName(r)
                                + " | " + i.getDescription());
                    }
                }
            } catch (Throwable ignored) { }
        }
    }

    private static String exitReasonName(int r) {
        switch (r) {
            case 1: return "LA APP SE CERR\u00d3 SOLA";
            case 2: return "SE\u00d1AL DEL SISTEMA (cierre forzado)";
            case 3: return "MEMORIA BAJA (el sistema la cerr\u00f3 por falta de RAM)";
            case 4: return "ERROR DE JAVA";
            case 5: return "FALLO NATIVO (t\u00fanel)";
            case 6: return "NO RESPONDE (ANR)";
            case 7: return "FALLO AL INICIAR";
            case 8: return "CAMBIO DE PERMISOS";
            case 9: return "USO EXCESIVO DE RECURSOS";
            case 10: return "CERRADA POR EL USUARIO";
            case 11: return "DETENIDA POR EL USUARIO";
            case 12: return "SE CERR\u00d3 UN COMPONENTE DEL QUE DEPEND\u00cdA";
            case 13: return "OTRO MOTIVO (posible ahorro de bater\u00eda del fabricante)";
            case 14: return "CONGELADA POR EL SISTEMA";
            case 15: return "CAMBIO EN EL PAQUETE";
            case 16: return "APP ACTUALIZADA";
            default: return "C\u00d3DIGO " + r;
        }
    }

    // ------------------------------------------------------------------ acciones

    private void onMainClick() {
        if (TunnelService.state != TunnelService.ST_IDLE) {
            startService(new Intent(this, TunnelService.class).setAction(TunnelService.ACTION_STOP));
            return;
        }
        boolean rufu = TunnelService.MODE_RUFU.equals(mode);
        if (hostEdit.getText().toString().trim().isEmpty()
                || (!rufu && userEdit.getText().toString().trim().isEmpty())) {
            toast(rufu ? "Completa el servidor" : "Completa servidor y usuario");
            return;
        }
        if (rufu && rufuId == null) {
            toast("Android no entregó el ID del dispositivo");
            return;
        }
        saveFields();
        Intent prep = VpnService.prepare(this);
        if (prep != null) {
            startActivityForResult(prep, REQ_VPN);
        } else {
            startTunnel();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_VPN) {
            String v2 = pendingV2;
            pendingV2 = null;
            if (resultCode == RESULT_OK) {
                if (v2 != null) startV2rayService(v2);
                else startTunnel();
            } else toast("Necesitas aceptar el permiso de VPN");
        } else if (requestCode == REQ_EXPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingExport != null) {
                try (OutputStream o = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    o.write((pendingExport + "\n").getBytes(StandardCharsets.UTF_8));
                    toast("Perfil exportado y cifrado");
                } catch (Exception e) {
                    toast("No se pudo guardar el archivo");
                }
            }
            pendingExport = null;
        } else if (requestCode == REQ_AI_LICENSE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try { activateAiLicense(readText(data.getData())); }
                catch (Exception e) { toast("No se pudo leer el archivo"); }
            }
        } else if (requestCode == REQ_IMPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try {
                    String text = readText(data.getData());
                    if (AiLicense.looks(text)) activateAiLicense(text);
                    else if (!ProfileCrypto.looksEncrypted(text)) toast("Ese archivo no es un perfil de Conecta");
                    else importProfile(text, fileName(data.getData()));
                } catch (Exception e) {
                    toast("No se pudo leer el archivo");
                }
            }
        }
    }

    /** Ventana para pegar un enlace (vmess, vless, trojan, ss) o un JSON de Xray y conectar con el motor V2Ray. */
    private void openV2rayDialog() {
        if (isClient()) return;
        if (!V2rayCore.available()) {
            toast("Esta compilaci\u00f3n no incluye el motor V2Ray");
            return;
        }
        final EditText in = new EditText(this);
        in.setHint("vmess://, vless://, trojan://, ss:// o JSON");
        in.setMinLines(5);
        in.setGravity(Gravity.TOP | Gravity.START);
        in.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        in.setText(prefs.getString("v2link", ""));
        new AlertDialog.Builder(this)
                .setTitle("V2Ray")
                .setView(in)
                .setPositiveButton("Conectar", (d, w) -> startV2ray(in.getText().toString().trim()))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void startV2ray(String link) {
        if (TunnelService.state != TunnelService.ST_IDLE) { toast("Primero desconecta"); return; }
        try {
            V2rayConfig.build(link, 1080, false);   // solo valida el formato (sin red)
        } catch (Exception e) {
            toast(e.getMessage() == null ? "Enlace no v\u00e1lido" : e.getMessage());
            return;
        }
        prefs.edit().putString("v2link", link).apply();
        pendingV2 = link;
        Intent prep = VpnService.prepare(this);
        if (prep != null) {
            startActivityForResult(prep, REQ_VPN);
        } else {
            pendingV2 = null;
            startV2rayService(link);
        }
    }

    private void startV2rayService(String link) {
        Intent i = new Intent(this, TunnelService.class)
                .setAction(TunnelService.ACTION_START)
                .putExtra(TunnelService.EXTRA_MODE, TunnelService.MODE_V2RAY)
                .putExtra(TunnelService.EXTRA_V2_LINK, link)
                .putExtra(TunnelService.EXTRA_SPEED, speed)
                .putExtra(TunnelService.EXTRA_UDP, false)
                .putExtra(TunnelService.EXTRA_AUTO, autoSwitch.isChecked());
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private void startTunnel() {
        int port = currentPort();
        Intent i = new Intent(this, TunnelService.class)
                .setAction(TunnelService.ACTION_START)
                .putExtra(TunnelService.EXTRA_HOST, hostEdit.getText().toString().trim())
                .putExtra(TunnelService.EXTRA_PORT, port)
                .putExtra(TunnelService.EXTRA_USER, userEdit.getText().toString().trim())
                .putExtra(TunnelService.EXTRA_MODE, mode)
                .putExtra(TunnelService.EXTRA_SPEED, speed)
                .putExtra(TunnelService.EXTRA_UDP, udpSwitch.isChecked())
                .putExtra(TunnelService.EXTRA_AUTO, autoSwitch.isChecked())
                .putExtra(TunnelService.EXTRA_UDPGW_PORT, udpPort());
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private void saveFields() {
        if (hostEdit == null) return;
        prefs.edit()
                .putString("host", hostEdit.getText().toString().trim())
                .putString("port", portEdit.getText().toString().trim())
                .putString("user", userEdit.getText().toString().trim())
                .putString("udpgw", udpPortEdit.getText().toString().trim())
                .putBoolean("udp", udpSwitch.isChecked())
                .putBoolean("auto", autoSwitch.isChecked())
                .putInt("portIndex", activePortIndex)
                .putBoolean("ai", aiSwitch.isChecked())
                .putString("aiPort", aiPortEdit.getText().toString().trim())
                .putString("aiToken", aiTokenEdit.getText().toString().trim())
                .apply();
        refreshSecrets();
    }

    private void clip(String label, String text, String msg) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(label, text));
        toast(msg);
    }

    private void share(String text) {
        Intent sh = new Intent(Intent.ACTION_SEND);
        sh.setType("text/plain");
        sh.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(sh, "Enviar"));
    }

    /** Hasta 5 puertos válidos, sin repetidos, tal como los escribió el administrador. */
    private List<Integer> parsePorts() {
        List<Integer> out = new ArrayList<>();
        for (String tok : portEdit.getText().toString().split(",")) {
            tok = tok.trim();
            if (tok.isEmpty()) continue;
            try {
                int p = Integer.parseInt(tok);
                if (p >= 1 && p <= 65535 && !out.contains(p)) out.add(p);
            } catch (NumberFormatException ignored) { }
            if (out.size() == 5) break;
        }
        return out;
    }

    /** El puerto con el que se conecta ahora mismo: el que está marcado entre los disponibles. */
    private int currentPort() {
        List<Integer> ports = parsePorts();
        if (ports.isEmpty()) return 22;
        int idx = Math.min(activePortIndex, ports.size() - 1);
        return ports.get(idx);
    }

    private void setActivePort(int index) {
        activePortIndex = index;
        saveFields();
        refreshPortChips();
    }

    /** Dibuja hasta 5 botones con los puertos disponibles; si solo hay uno, no hace falta elegir. */
    // ------------------------------------------------------------------ asistente de IA (experimental)

    private void updateAiVisibility() {
        if (isClient()) {   // la versión de los clientes no lleva IA
            aiSwitch.setVisibility(android.view.View.GONE);
            aiRowView.setVisibility(android.view.View.GONE);
            aiOpenBtn.setVisibility(android.view.View.GONE);
            aiLicenseBtn.setVisibility(android.view.View.GONE);
            return;
        }
        boolean on = aiSwitch.isChecked();
        int vis = on ? android.view.View.VISIBLE : android.view.View.GONE;
        boolean direct = AiAssistant.isDirect(this);
        aiPortEdit.setVisibility(direct ? android.view.View.GONE : vis);
        aiTokenEdit.setVisibility(direct ? android.view.View.GONE : vis);
        aiOpenBtn.setVisibility(vis);
        aiLicenseBtn.setVisibility(android.view.View.VISIBLE);
    }

    private int aiPort() {
        try { return Integer.parseInt(aiPortEdit.getText().toString().trim()); } catch (Exception e) { return 8766; }
    }

    /** Oculta IP, puerto, usuario e ID en todo lo que se muestra (o se envía) en el chat del asistente. */
    private String chatMask(String s) {
        if (s == null || s.isEmpty()) return s;
        refreshSecrets();
        s = LogMask.mask(s);
        // "port 22", "puerto 443", "(port 2222)"...
        s = s.replaceAll("(?i)\\b(port|puerto)(\\s*[:=]?\\s*)\\d{1,5}\\b", "$1$2" + LogMask.MASK);
        // los puertos configurados (servidor, UDP, IA) si aparecen sueltos
        java.util.Set<String> ports = new java.util.HashSet<>();
        for (Integer pt : parsePorts()) ports.add(String.valueOf(pt));
        ports.add(String.valueOf(udpPort()));
        ports.add(String.valueOf(aiPort()));
        for (String pt : ports) {
            if (pt.length() >= 3) s = s.replaceAll("(?<!\\d)" + java.util.regex.Pattern.quote(pt) + "(?!\\d)", LogMask.MASK);
        }
        return s;
    }

    private void openAiAssistant() {
        String host = hostEdit.getText().toString().trim();
        String token = aiTokenEdit.getText().toString().trim();
        if (isClient()) return;
        if (!AiAssistant.isDirect(this) && (host.isEmpty() || token.isEmpty())) {
            toast("La IA no est\u00e1 activada: carga tu archivo de licencia");
            return;
        }
        int port = aiPort();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(10), dp(16), 0);
        ScrollView chatScroll = new ScrollView(this);
        TextView chatView = text("Preguntale algo, o toca \"Diagnosticar el \u00faltimo error\".", 13, pale, false);
        chatScroll.addView(chatView);
        box.addView(chatScroll, new LinearLayout.LayoutParams(-1, dp(260)));
        EditText msgEdit = edit("Escribe tu consulta", "", InputType.TYPE_CLASS_TEXT);
        box.addView(msgEdit, lp(-1, dp(46), 10, 0));
        Button diagBtn = button("Diagnosticar el \u00faltimo error", Color.rgb(44, 68, 98));
        box.addView(diagBtn, lp(-1, dp(42), 10, 0));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Asistente")
                .setView(box)
                .setPositiveButton("Enviar", null)   // se sobreescribe abajo para que no cierre solo
                .setNegativeButton("Cerrar", null)
                .show();

        Runnable[] sendHolder = new Runnable[1];
        sendHolder[0] = () -> {
            String p = chatMask(msgEdit.getText().toString().trim());
            if (p.isEmpty()) return;
            chatView.append("\n\nT\u00fa: " + p + "\nAsistente: \u2026");
            chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
            msgEdit.setText("");
            AiAssistant.Callback aiCb = new AiAssistant.Callback() {
                @Override public void onReply(String text) {
                    String cur = chatView.getText().toString();
                    chatView.setText(cur.substring(0, cur.length() - 1) + chatMask(text));
                    chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
                }
                @Override public void onError(String message) {
                    String cur = chatView.getText().toString();
                    chatView.setText(cur.substring(0, cur.length() - 1) + "\u26a0 " + chatMask(message));
                    chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
                }
            };
            if (AiAssistant.isDirect(this)) AiAssistant.askDirect(this, p, aiCb);
            else AiAssistant.ask(this, host, port, token, p, aiCb);
        };
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> sendHolder[0].run());
        diagBtn.setOnClickListener(v -> {
            String log = LogMask.mask(logView.getText().toString());
            msgEdit.setText("Mi app de conexi\u00f3n VPN no funciona bien. Este es el registro (la IP y el ID ya est\u00e1n ocultos "
                    + "a prop\u00f3sito, no hace falta que los pidas): " + log
                    + "\n\u00bfCu\u00e1l es la causa m\u00e1s probable y qu\u00e9 puedo hacer?");
            sendHolder[0].run();
        });
    }

    private void refreshPortChips() {
        List<Integer> ports = parsePorts();
        if (activePortIndex >= ports.size()) activePortIndex = Math.max(0, ports.size() - 1);
        for (int i = 0; i < portChips.length; i++) {
            Button b = portChips[i];
            if (i < ports.size()) {
                b.setVisibility(android.view.View.VISIBLE);
                b.setText("Puerto " + (i + 1));
                setBg(b, i == activePortIndex ? blue : Color.rgb(44, 68, 98));
            } else {
                b.setVisibility(android.view.View.GONE);
            }
        }
        portChipsRow.setVisibility(ports.size() > 1 ? android.view.View.VISIBLE : android.view.View.GONE);
    }

    private int udpPort() {
        try { return Integer.parseInt(udpPortEdit.getText().toString().trim()); } catch (Exception e) { return 7300; }
    }

    private void setSpeed(String v) {
        speed = v;
        prefs.edit().putString("speed", v).apply();
        applySpeed();
    }

    private void applySpeed() {
        int off = Color.rgb(44, 68, 98);
        setBg(speedNormal, "normal".equals(speed) ? blue : off);
        setBg(speedRapido, "rapido".equals(speed) ? blue : off);
        setBg(speedMax, "maximo".equals(speed) ? blue : off);
    }

    private void setMode(String m) {
        mode = m;
        prefs.edit().putString("mode", m).apply();
        applyMode();
    }

    private void applyMode() {
        boolean rufu = TunnelService.MODE_RUFU.equals(mode);
        setBg(modeRufu, rufu ? blue : Color.rgb(44, 68, 98));
        setBg(modeKey, rufu ? Color.rgb(44, 68, 98) : blue);
        updateVisibility();
        if (rufu) {
            renderHwid();
            btnA.setText("Copiar HWID");
            btnA.setOnClickListener(v -> { if (rufuId != null) clip("HWID", rufuId, "HWID copiado"); });
            keyExtra.setVisibility(android.view.View.GONE);
        } else {
            keyExtra.setVisibility(android.view.View.VISIBLE);
            renderHwid();
            btnA.setText("Copiar");
            btnB.setText("Compartir");
            btnA.setOnClickListener(v -> clip("HWID", publicLine, "Copiado. Envíaselo al administrador del VPS."));
            btnB.setOnClickListener(v -> share(publicLine));
            hintView.setText("Modo llave: más seguro. Registra la línea copiada en el VPS con hwid-vps.sh y usa el usuario SSH correspondiente.");
        }
    }

    // ------------------------------------------------------------------ velocidad e IP local

    // ------------------------------------------------------------------ prueba de velocidad (estilo fast.com)

    /** Kbps por debajo de 1 Mbps; desde ahí pasa a Mbps con un decimal. */
    private void showSpeed(double mbps) {
        if (mbps < 1.0) {
            speedNumber.setText(String.format(java.util.Locale.US, "%.0f", mbps * 1000));
            speedUnit.setText("Kbps");
        } else {
            speedNumber.setText(String.format(java.util.Locale.US, "%.1f", mbps));
            speedUnit.setText("Mbps");
        }
    }

    private void toggleSpeedTest() {
        if (SpeedTest.isRunning()) {
            SpeedTest.stop();
            return;
        }
        if (TunnelService.state != TunnelService.ST_CONNECTED || TunnelService.activeSocksPort <= 0) {
            toast("Con\u00e9ctate primero para medir tu velocidad");
            return;
        }
        String host = hostEdit.getText().toString().trim();
        if (host.isEmpty()) {
            toast("Falta el servidor");
            return;
        }
        speedLabel.setText("Midiendo tu velocidad\u2026");
        speedNumber.setText("0");
        speedUnit.setText("Kbps");
        speedGraph.clear();
        speedTestBtn.setText("\u25a0");
        SpeedTest.start(this, host, TunnelService.activeSocksPort, SPEEDTEST_PORT, 50, new SpeedTest.Listener() {
            @Override public void onProgress(double mbps) {
                showSpeed(mbps);
                speedGraph.add(mbps);
            }
            @Override public void onDone(double mbps) {
                showSpeed(mbps);
                speedLabel.setText("Tu velocidad de bajada es de");
                speedTestBtn.setText("\u25b6");
            }
            @Override public void onError(String message) {
                speedLabel.setText("Toca el bot\u00f3n para medir tu velocidad");
                speedNumber.setText("\u2014");
                speedTestBtn.setText("\u25b6");
                toast(message);
            }
            @Override public void onCancelled() {
                speedLabel.setText("Toca el bot\u00f3n para medir tu velocidad");
                speedNumber.setText("\u2014");
                speedTestBtn.setText("\u25b6");
            }
        });
    }

    /** IP privada del teléfono en su red real (Wi-Fi o datos), no la de la VPN. */
    private String localIp() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                if (nc == null || nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue;
                boolean wifi = nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
                boolean cell = nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR);
                boolean eth = nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET);
                if (!wifi && !cell && !eth) continue;
                LinkProperties lp = cm.getLinkProperties(n);
                if (lp == null) continue;
                for (LinkAddress la : lp.getLinkAddresses()) {
                    InetAddress a = la.getAddress();
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        return a.getHostAddress() + (wifi ? " (Wi-Fi)" : cell ? " (datos m\u00f3viles)" : " (cable)");
                    }
                }
            }
        } catch (Throwable ignored) { }
        return "\u2014";
    }

    // ------------------------------------------------------------------ HWID oculto, perfil bloqueado

    private String currentHwid() {
        boolean rufu = TunnelService.MODE_RUFU.equals(mode);
        String v = rufu ? rufuId : keyHwid;
        return v == null ? "No disponible" : v;
    }

    private void renderHwid() {
        String v = currentHwid();
        if (hwidShown || v.equals("No disponible")) { hwidView.setText(v); return; }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < v.length(); i++) sb.append(i < 2 || v.charAt(i) == '-' ? v.charAt(i) : '\u25CF');
        hwidView.setText(sb.toString());
    }

    private boolean isLocked() { return prefs.getBoolean("locked", false); }

    private void refreshSecrets() {
        if (hostEdit == null) return;
        LogMask.setSecrets(hostEdit.getText().toString(), userEdit.getText().toString(), rufuId, keyHwid);
    }

    /** true en "Conecta HWID": la que reciben los clientes, sin campos para tocar, solo Importar. */
    private boolean isClient() { return BuildConfig.CLIENT_VARIANT; }

    /** Si la compilaci\u00f3n trae un servidor integrado (secretos de GitHub), lo precarga. */
    private void applyFixed() {
        if (BuildConfig.SERVER_HOST.isEmpty()) return;
        if (prefs.getBoolean("overrideImported", false)) return;   // ya se import\u00f3 un perfil propio: no pisarlo
        hostEdit.setText(BuildConfig.SERVER_HOST);
        portEdit.setText(BuildConfig.SERVER_PORTS.isEmpty()
                ? String.valueOf(BuildConfig.SERVER_PORT) : BuildConfig.SERVER_PORTS);
        udpPortEdit.setText(String.valueOf(BuildConfig.UDPGW_PORT));
        if (!BuildConfig.AI_TOKEN.isEmpty()) {
            aiSwitch.setChecked(true);
            aiPortEdit.setText(String.valueOf(BuildConfig.AI_PORT));
            aiTokenEdit.setText(BuildConfig.AI_TOKEN);
        }
        mode = TunnelService.MODE_RUFU;
        prefs.edit().putString("mode", mode).putBoolean("locked", false).apply();
    }

    private void updateVisibility() {
        boolean client = isClient();
        boolean locked = isLocked() || client;   // en la variante cliente, los campos siempre quedan ocultos
        boolean rufu = TunnelService.MODE_RUFU.equals(mode);
        boolean hasProfile = !hostEdit.getText().toString().trim().isEmpty();

        modesRow.setVisibility(client ? android.view.View.GONE : android.view.View.VISIBLE);
        profileRow.setVisibility(android.view.View.VISIBLE);
        btnExport.setVisibility(client ? android.view.View.GONE : android.view.View.VISIBLE);
        btnExport.setAlpha(isLocked() ? 0.4f : 1f);

        serverRow.setVisibility(locked ? android.view.View.GONE : android.view.View.VISIBLE);
        userEdit.setVisibility(locked || rufu ? android.view.View.GONE : android.view.View.VISIBLE);
        udpPortEdit.setVisibility(locked || !udpSwitch.isChecked() ? android.view.View.GONE : android.view.View.VISIBLE);

        boolean showInfo = isLocked() || (client && hasProfile);
        lockedBox.setVisibility(showInfo ? android.view.View.VISIBLE : android.view.View.GONE);
        lockedBtn.setVisibility(showInfo ? android.view.View.VISIBLE : android.view.View.GONE);
        String pn = prefs.getString("profileName", "");
        String pnPart = pn.isEmpty() ? "" : ": " + pn;
        lockedView.setText(client
                ? "\uD83D\uDD12 Perfil cargado" + pnPart + "\nDatos del servidor ocultos."
                : "\uD83D\uDD12 Perfil bloqueado" + pnPart + "\nDatos del servidor ocultos.");
        noProfileView.setVisibility(client && !hasProfile ? android.view.View.VISIBLE : android.view.View.GONE);
        updateAiVisibility();
    }

    private void applyLocked() { updateVisibility(); }

    private void removeLockedProfile() {
        new AlertDialog.Builder(this)
                .setTitle(isClient() ? "\u00bfQuitar el perfil?" : "\u00bfQuitar el perfil bloqueado?")
                .setMessage("Se borrar\u00e1n el servidor, el puerto y el usuario guardados. "
                        + "Para volver a usarlos tendr\u00e1s que importar el archivo otra vez.")
                .setPositiveButton("Quitar", (d, w) -> doRemoveLockedProfile())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void doRemoveLockedProfile() {
        hostEdit.setText("");
        portEdit.setText("");
        userEdit.setText("");
        udpPortEdit.setText("7300");
        prefs.edit().putBoolean("locked", false).putBoolean("overrideImported", false).remove("profileName").apply();
        saveFields();
        applyFixed();
        updateVisibility();
        refreshPortChips();
        toast(isClient() ? "Perfil eliminado" : "Perfil bloqueado eliminado");
    }

    // ------------------------------------------------------------------ importar / exportar

    private String profileJson(boolean lock) throws org.json.JSONException {
        JSONObject o = new JSONObject();
        o.put("v", 1);
        o.put("mode", mode);
        o.put("host", hostEdit.getText().toString().trim());
        o.put("port", portEdit.getText().toString().trim());
        o.put("portIndex", activePortIndex);
        o.put("ai", aiSwitch.isChecked());
        o.put("aiPort", aiPortEdit.getText().toString().trim());
        o.put("aiToken", aiTokenEdit.getText().toString().trim());
        o.put("user", userEdit.getText().toString().trim());
        o.put("speed", speed);
        o.put("udp", udpSwitch.isChecked());
        o.put("udpgw", udpPort());
        o.put("locked", lock);
        return o.toString();
    }

    private void startExport() {
        if (isClient()) return;   // esta variante no exporta; el bot\u00f3n ya est\u00e1 oculto
        if (isLocked()) { toast("Perfil bloqueado: no se puede exportar"); return; }
        if (hostEdit.getText().toString().trim().isEmpty()) { toast("Primero completa el servidor"); return; }
        final CheckBox lock = new CheckBox(this);
        lock.setText("Bloquear: ocultar los datos a quien lo importe");
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(lock);
        new AlertDialog.Builder(this)
                .setTitle("Exportar perfil")
                .setView(box)
                .setPositiveButton("Continuar", (d, w) -> {
                    try {
                        pendingExport = ProfileCrypto.encrypt(profileJson(lock.isChecked()), ProfileKey.VALUE);
                    } catch (Exception e) {
                        toast("No se pudo cifrar el perfil");
                        return;
                    }
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/octet-stream");
                    i.putExtra(Intent.EXTRA_TITLE, "perfil.conecta");
                    startActivityForResult(i, REQ_EXPORT);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void startAiLicenseImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_AI_LICENSE);
    }

    /** Abre la licencia de IA (archivo cifrado con el HWID de este dispositivo) y activa el asistente. */
    private void activateAiLicense(String text) {
        if (isClient()) { toast("Esta versi\u00f3n no incluye el asistente de IA"); return; }
        if (rufuId == null) { toast("No se pudo leer el ID de este dispositivo"); return; }
        try {
            AiLicense.activate(this, text, rufuId);
            aiSwitch.setChecked(true);
            updateAiVisibility();
            toast("IA activada en este dispositivo");
        } catch (Exception e) {
            toast("Ese archivo no es para este dispositivo o est\u00e1 da\u00f1ado");
        }
    }

    private void startImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_IMPORT);
    }

    private String readText(Uri u) throws IOException {
        try (InputStream in = getContentResolver().openInputStream(u)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n, total = 0;
            while ((n = in.read(b)) >= 0) {
                total += n;
                if (total > 65536) throw new IOException("Archivo demasiado grande");
                bo.write(b, 0, n);
            }
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    /** Nombre visible del archivo (por ejemplo "cliente1.conecta"), o "" si no se puede saber. */
    private String fileName(Uri u) {
        String name = null;
        try (android.database.Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (i >= 0) name = c.getString(i);
            }
        } catch (Exception ignored) { }
        if (name == null || name.trim().isEmpty()) name = u.getLastPathSegment();
        if (name == null) return "";
        int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        return name.trim();
    }

    private void importProfile(final String text, final String name) {
        String json;
        try {
            json = ProfileCrypto.decrypt(text, ProfileKey.VALUE);
        } catch (Exception e) {
            toast("Archivo da\u00f1ado o de otra app");
            return;
        }
        applyProfile(json, name);
    }

    private void applyProfile(String json, String name) {
        try {
            JSONObject o = new JSONObject(json);
            String h = o.optString("host", "").trim();
            if (h.isEmpty()) throw new IllegalArgumentException("sin servidor");
            hostEdit.setText(h);
            portEdit.setText(o.optString("port", ""));
            activePortIndex = o.optInt("portIndex", 0);
            aiSwitch.setChecked(o.optBoolean("ai", false));
            aiPortEdit.setText(o.optString("aiPort", "8766"));
            aiTokenEdit.setText(o.optString("aiToken", ""));
            userEdit.setText(o.optString("user", ""));
            mode = TunnelService.MODE_KEY.equals(o.optString("mode")) ? TunnelService.MODE_KEY : TunnelService.MODE_RUFU;
            String sp = o.optString("speed", "maximo");
            speed = "normal".equals(sp) || "rapido".equals(sp) ? sp : "maximo";
            udpSwitch.setChecked(o.optBoolean("udp", true));
            udpPortEdit.setText(String.valueOf(o.optInt("udpgw", 7300)));
            prefs.edit()
                    .putString("mode", mode)
                    .putString("speed", speed)
                    .putBoolean("locked", o.optBoolean("locked", false))
                    .putBoolean("overrideImported", true)
                    .putString("profileName", name == null ? "" : name)
                    .apply();
            saveFields();
            applyMode();
            applySpeed();
            updateVisibility();
            refreshPortChips();
            updateAiVisibility();
            toast(isLocked() ? "Perfil importado (datos ocultos)" : "Perfil importado");
        } catch (Exception e) {
            toast("El archivo no tiene un perfil v\u00e1lido");
        }
    }

    // ------------------------------------------------------------------ interfaz

    private void window() {
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
    }

    private void buildUi() {
        final int gray = Color.rgb(44, 68, 98);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(navy);

        // ---- barra de velocidad (fija, arriba de todo) ----
        FrameLayout bar = new FrameLayout(this);
        bar.setBackgroundColor(Color.rgb(11, 28, 48));
        bar.setPadding(dp(14), dp(16), dp(14), dp(12));

        LinearLayout centerCol = new LinearLayout(this);
        centerCol.setOrientation(LinearLayout.VERTICAL);
        centerCol.setGravity(Gravity.CENTER);

        speedLabel = text("Toca el bot\u00f3n para medir tu velocidad", 14, pale, false);
        speedLabel.setGravity(Gravity.CENTER);
        centerCol.addView(speedLabel, lp(-1, -2, 0, 6));

        LinearLayout numberRow = new LinearLayout(this);
        numberRow.setOrientation(LinearLayout.HORIZONTAL);
        numberRow.setGravity(Gravity.BOTTOM);
        speedNumber = text("\u2014", 52, Color.WHITE, true);
        speedUnit = text("Kbps", 20, pale, true);
        speedUnit.setPadding(dp(8), 0, 0, dp(10));
        numberRow.addView(speedNumber);
        numberRow.addView(speedUnit);
        centerCol.addView(numberRow, lp(-2, -2, 0, 4));

        speedGraph = new SpeedGraphView(this);
        centerCol.addView(speedGraph, lp(dp(240), dp(60), 0, 4));

        FrameLayout.LayoutParams colParams = new FrameLayout.LayoutParams(-2, -2);
        colParams.gravity = Gravity.CENTER;
        bar.addView(centerCol, colParams);

        speedTestBtn = button("\u25b6", Color.rgb(44, 68, 98));
        speedTestBtn.setTextSize(16);
        speedTestBtn.setOnClickListener(v -> toggleSpeedTest());
        FrameLayout.LayoutParams btnParams = new FrameLayout.LayoutParams(dp(40), dp(40));
        btnParams.gravity = Gravity.TOP | Gravity.END;
        bar.addView(speedTestBtn, btnParams);

        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(16));
        scroll.addView(c);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        // ---- cabecera: logo + t\u00edtulo + estado + IP ----
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_logo);
        head.addView(logo, new LinearLayout.LayoutParams(dp(50), dp(50)));
        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.setPadding(dp(12), 0, 0, 0);
        ht.addView(text("Conecta HWID", 22, Color.WHITE, true));
        statusView = text("\u25CF Desconectado", 13, Color.rgb(150, 165, 185), true);
        ht.addView(statusView);
        ipView = text("IP local: \u2014", 11, pale, false);
        ht.addView(ipView);
        head.addView(ht, new LinearLayout.LayoutParams(0, -2, 1f));
        lockedBtn = button("\uD83D\uDDD1", Color.rgb(110, 48, 56));
        lockedBtn.setTextSize(18);
        lockedBtn.setPadding(0, 0, 0, 0);
        lockedBtn.setBackground(rounded(Color.rgb(110, 48, 56), 18));
        lockedBtn.setOnClickListener(v -> removeLockedProfile());
        LinearLayout.LayoutParams lbp = new LinearLayout.LayoutParams(dp(36), dp(36));
        lbp.gravity = Gravity.TOP;
        head.addView(lockedBtn, lbp);
        c.addView(head, lp(-1, -2, 0, 10));

        mainButton = button("Conectar", green);
        mainButton.setTextSize(16);
        mainButton.setOnClickListener(v -> onMainClick());
        c.addView(mainButton, lp(-1, dp(48), 0, 8));

        v2Btn = button("V2Ray (enlace)", Color.rgb(44, 68, 98));
        v2Btn.setOnClickListener(v -> openV2rayDialog());
        v2Btn.setVisibility(isClient() ? android.view.View.GONE : android.view.View.VISIBLE);
        c.addView(v2Btn, lp(-1, dp(40), 0, 8));

        // ---- modo ----
        LinearLayout modes = modesRow = new LinearLayout(this);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        modeRufu = button("HWID", blue);
        modeRufu.setOnClickListener(v -> setMode(TunnelService.MODE_RUFU));
        modeKey = button("HWID por llave", blue);
        modeKey.setOnClickListener(v -> setMode(TunnelService.MODE_KEY));
        modes.addView(modeRufu, new LinearLayout.LayoutParams(0, dp(38), 1f));
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, dp(38), 1f);
        mp.leftMargin = dp(8);
        modes.addView(modeKey, mp);
        c.addView(modes, lp(-1, -2, 0, 8));

        // ---- tarjeta HWID: c\u00f3digo + bot\u00f3n copiar en la misma fila ----
        LinearLayout hw = new LinearLayout(this);
        hw.setOrientation(LinearLayout.VERTICAL);
        hw.setPadding(dp(12), dp(8), dp(8), dp(8));
        hw.setBackground(rounded(card, 14));
        LinearLayout hrow = new LinearLayout(this);
        hrow.setOrientation(LinearLayout.HORIZONTAL);
        hrow.setGravity(Gravity.CENTER_VERTICAL);
        hwidView = text("\u2026", 16, Color.WHITE, true);
        hwidView.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        hwidView.setSingleLine(true);
        hwidView.setOnClickListener(v -> { hwidShown = !hwidShown; renderHwid(); });
        hrow.addView(hwidView, new LinearLayout.LayoutParams(0, -2, 1f));
        btnA = button("Copiar HWID", blue);
        hrow.addView(btnA, new LinearLayout.LayoutParams(-2, dp(38)));
        hw.addView(hrow, new LinearLayout.LayoutParams(-1, -2));
        keyExtra = new LinearLayout(this);
        keyExtra.setOrientation(LinearLayout.VERTICAL);
        btnB = button("Compartir", gray);
        keyExtra.addView(btnB, lp(-1, dp(36), 8, 4));
        hintView = text("", 11, pale, false);
        keyExtra.addView(hintView);
        hw.addView(keyExtra, new LinearLayout.LayoutParams(-1, -2));
        c.addView(hw, lp(-1, -2, 0, 8));

        // ---- perfil bloqueado ----
        lockedBox = new LinearLayout(this);
        lockedBox.setOrientation(LinearLayout.VERTICAL);
        lockedBox.setPadding(dp(12), dp(8), dp(12), dp(8));
        lockedBox.setBackground(rounded(card, 12));
        lockedView = text("\uD83D\uDD12 Perfil bloqueado: datos del servidor ocultos.", 13, Color.WHITE, false);
        lockedBox.addView(lockedView, lp(-1, -2, 0, 0));
        c.addView(lockedBox, lp(-1, -2, 0, 8));

        noProfileView = text("Sin perfil cargado. Toca Importar o abre el archivo que te compartieron.", 13, pale, false);
        c.addView(noProfileView, lp(-1, -2, 0, 8));

        // ---- servidor + puerto(s) en una fila ----
        serverRow = new LinearLayout(this);
        serverRow.setOrientation(LinearLayout.HORIZONTAL);
        hostEdit = edit("Servidor (IP o dominio)", prefs.getString("host", ""), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        portEdit = edit("Puerto(s): 443,8080", prefs.getString("port", ""), InputType.TYPE_CLASS_TEXT);
        portEdit.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { refreshPortChips(); }
        });
        serverRow.addView(hostEdit, new LinearLayout.LayoutParams(0, dp(44), 1f));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(118), dp(44));
        pp.leftMargin = dp(8);
        serverRow.addView(portEdit, pp);
        c.addView(serverRow, lp(-1, -2, 0, 6));

        // ---- puerto activo: hasta 5 botones, visible siempre que haya m\u00e1s de uno ----
        portChipsRow = new LinearLayout(this);
        portChipsRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < portChips.length; i++) {
            final int idx = i;
            Button chip = button("", Color.rgb(44, 68, 98));
            chip.setTextSize(13);
            chip.setVisibility(android.view.View.GONE);
            chip.setOnClickListener(v -> setActivePort(idx));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, dp(36), 1f);
            if (i > 0) clp.leftMargin = dp(6);
            portChipsRow.addView(chip, clp);
            portChips[i] = chip;
        }
        c.addView(portChipsRow, lp(-1, -2, 0, 8));

        userEdit = edit("Usuario SSH", prefs.getString("user", ""), InputType.TYPE_CLASS_TEXT);
        c.addView(userEdit, lp(-1, dp(44), 0, 8));

        // ---- velocidad ----
        LinearLayout sp2 = new LinearLayout(this);
        sp2.setOrientation(LinearLayout.HORIZONTAL);
        speedNormal = button("Normal", blue);
        speedRapido = button("R\u00e1pido", blue);
        speedMax = button("M\u00e1ximo", blue);
        speedNormal.setOnClickListener(v -> setSpeed("normal"));
        speedRapido.setOnClickListener(v -> setSpeed("rapido"));
        speedMax.setOnClickListener(v -> setSpeed("maximo"));
        sp2.addView(speedNormal, new LinearLayout.LayoutParams(0, dp(38), 1f));
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, dp(38), 1f);
        l2.leftMargin = dp(8);
        sp2.addView(speedRapido, l2);
        LinearLayout.LayoutParams l3 = new LinearLayout.LayoutParams(0, dp(38), 1f);
        l3.leftMargin = dp(8);
        sp2.addView(speedMax, l3);
        c.addView(sp2, lp(-1, -2, 0, 4));

        // ---- BadVPN: interruptor + puerto en una fila ----
        LinearLayout urow = new LinearLayout(this);
        urow.setOrientation(LinearLayout.HORIZONTAL);
        urow.setGravity(Gravity.CENTER_VERTICAL);
        udpSwitch = compactSwitch("BadVPN para juegos (UDP)", prefs.getBoolean("udp", true));
        udpPortEdit = edit("Puerto", prefs.getString("udpgw", "7300"), InputType.TYPE_CLASS_NUMBER);
        udpSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { updateVisibility(); }
        });
        urow.addView(udpSwitch, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams up = new LinearLayout.LayoutParams(dp(92), dp(40));
        up.leftMargin = dp(8);
        urow.addView(udpPortEdit, up);
        c.addView(urow, lp(-1, -2, 0, 0));

        autoSwitch = compactSwitch("Reconectar autom\u00e1ticamente", prefs.getBoolean("auto", true));
        c.addView(autoSwitch, lp(-1, -2, 0, 8));

        // ---- asistente de IA (experimental): habla con tu proxy en el VPS, nunca directo con Gemini ----
        aiSwitch = compactSwitch("Asistente IA (experimental)", prefs.getBoolean("ai", false));
        c.addView(aiSwitch, lp(-1, -2, 0, 4));
        LinearLayout aiRow = aiRowView = new LinearLayout(this);
        aiRow.setOrientation(LinearLayout.HORIZONTAL);
        aiPortEdit = edit("Puerto IA", prefs.getString("aiPort", "8766"), InputType.TYPE_CLASS_NUMBER);
        aiTokenEdit = edit("Palabra secreta", prefs.getString("aiToken", ""), InputType.TYPE_CLASS_TEXT);
        LinearLayout.LayoutParams aip = new LinearLayout.LayoutParams(dp(100), dp(44));
        aiRow.addView(aiPortEdit, aip);
        LinearLayout.LayoutParams ait = new LinearLayout.LayoutParams(0, dp(44), 1f);
        ait.leftMargin = dp(8);
        aiRow.addView(aiTokenEdit, ait);
        c.addView(aiRow, lp(-1, -2, 0, 8));
        aiOpenBtn = button("Abrir asistente", Color.rgb(44, 68, 98));
        aiOpenBtn.setOnClickListener(v -> openAiAssistant());
        c.addView(aiOpenBtn, lp(-1, dp(44), 0, 8));
        aiLicenseBtn = button("Activar IA con archivo", Color.rgb(44, 68, 98));
        aiLicenseBtn.setOnClickListener(v -> startAiLicenseImport());
        c.addView(aiLicenseBtn, lp(-1, dp(44), 0, 8));
        aiSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { updateAiVisibility(); }
        });

        // ---- perfil cifrado ----
        LinearLayout pr = profileRow = new LinearLayout(this);
        pr.setOrientation(LinearLayout.HORIZONTAL);
        btnImport = button("Importar perfil", gray);
        btnImport.setOnClickListener(v -> startImport());
        btnExport = button("Exportar perfil", gray);
        btnExport.setOnClickListener(v -> startExport());
        pr.addView(btnImport, new LinearLayout.LayoutParams(0, dp(38), 1f));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(0, dp(38), 1f);
        pl.leftMargin = dp(8);
        pr.addView(btnExport, pl);
        c.addView(pr, lp(-1, -2, 0, 10));

        // ---- registro: t\u00edtulo + copiar/borrar en una fila ----
        LinearLayout lh = new LinearLayout(this);
        lh.setOrientation(LinearLayout.HORIZONTAL);
        lh.setGravity(Gravity.CENTER_VERTICAL);
        lh.addView(text("Registro", 12, pale, false), new LinearLayout.LayoutParams(0, -2, 1f));
        Button copyLog = button("Copiar", gray);
        copyLog.setTextSize(12);
        copyLog.setOnClickListener(v -> clip("Registro", logView.getText().toString(), "Registro copiado"));
        btnClearLog = button("Borrar", gray);
        btnClearLog.setTextSize(12);
        btnClearLog.setOnClickListener(v -> { TunnelService.clearLogs(); logView.setText(TunnelService.logsSnapshot()); });
        lh.addView(copyLog, new LinearLayout.LayoutParams(-2, dp(30)));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, dp(30));
        cl.leftMargin = dp(6);
        lh.addView(btnClearLog, cl);
        c.addView(lh, lp(-1, -2, 0, 4));

        logScroll = new ScrollView(this);
        logView = text("", 11, pale, false);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setPadding(dp(10), dp(8), dp(10), dp(8));
        logScroll.setBackground(rounded(Color.rgb(11, 28, 48), 12));
        logScroll.addView(logView);
        c.addView(logScroll, new LinearLayout.LayoutParams(-1, dp(120)));

        setContentView(root);
    }

    private Switch compactSwitch(String label, boolean checked) {
        Switch sw = new Switch(this);
        sw.setText(label);
        sw.setTextColor(Color.WHITE);
        sw.setTextSize(14);
        sw.setChecked(checked);
        sw.setMinHeight(0);
        sw.setMinimumHeight(0);
        sw.setPadding(0, dp(4), 0, dp(4));
        return sw;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private EditText edit(String hint, String value, int inputType) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setInputType(inputType);
        e.setSingleLine(true);
        e.setTextSize(14);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.rgb(120, 145, 175));
        e.setPadding(dp(12), 0, dp(12), 0);
        e.setBackground(rounded(card, 12));
        return e;
    }

    private Button button(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.WHITE);
        b.setStateListAnimator(null);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        setBg(b, color);
        return b;
    }

    private void setBg(Button b, int color) { b.setBackground(rounded(color, 14)); }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top);
        p.bottomMargin = dp(bottom);
        return p;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
