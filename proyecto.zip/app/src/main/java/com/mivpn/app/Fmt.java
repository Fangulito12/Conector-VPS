package com.mivpn.app;

import java.util.Locale;

/** Formato de tamaños y velocidades para la pantalla. */
public final class Fmt {
    private Fmt() {}

    public static String size(long b) {
        if (b < 0) return "\u2014";
        if (b < 1024) return b + " B";
        double kb = b / 1024.0;
        if (kb < 1024) return String.format(Locale.US, "%.1f KB", kb);
        double mb = kb / 1024.0;
        if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb);
        return String.format(Locale.US, "%.2f GB", mb / 1024.0);
    }

    public static String rate(long bytesPerSecond) {
        return bytesPerSecond < 0 ? "\u2014" : size(bytesPerSecond) + "/s";
    }
}
