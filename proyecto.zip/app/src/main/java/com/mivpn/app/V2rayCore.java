package com.mivpn.app;

import android.content.Context;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * Envoltura del motor Xray (libv2ray.aar, compilado con gomobile). Se usa por reflexión para que
 * la app compile y funcione igual aunque el .aar no esté (versión sin V2Ray) o cambie un poco su API
 * entre versiones (startLoop con o sin descriptor de TUN).
 */
final class V2rayCore {
    private static final String LIB = "libv2ray.Libv2ray";
    private static final String CALLBACK = "libv2ray.CoreCallbackHandler";

    private Object controller;

    /** true si esta compilaci\u00f3n trae el motor. */
    static boolean available() {
        try {
            Class.forName(LIB);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    void start(Context ctx, String config) throws Exception {
        try {
            Class<?> lib = Class.forName(LIB);
            Class<?> cb = Class.forName(CALLBACK);

            // Carpeta de datos del motor (si esta versi\u00f3n de la librer\u00eda la pide).
            Method init = find(lib, "initCoreEnv", 2);
            if (init != null) {
                try { init.invoke(null, ctx.getFilesDir().getAbsolutePath(), "conecta"); }
                catch (Throwable ignored) { }
            }

            Object handler = Proxy.newProxyInstance(cb.getClassLoader(), new Class<?>[]{cb},
                    (proxy, method, args) -> {
                        String name = method.getName();
                        if ("onEmitStatus".equals(name) && args != null && args.length >= 2
                                && args[1] instanceof String) {
                            String msg = ((String) args[1]).trim();
                            if (!msg.isEmpty()) {
                                TunnelService.appendLog("V2Ray: " + (msg.length() > 160 ? msg.substring(0, 160) : msg));
                            }
                        } else if ("hashCode".equals(name)) {
                            return System.identityHashCode(proxy);
                        } else if ("equals".equals(name)) {
                            return args != null && args.length == 1 && proxy == args[0];
                        } else if ("toString".equals(name)) {
                            return "V2rayCallback";
                        }
                        Class<?> rt = method.getReturnType();
                        if (rt == long.class) return 0L;
                        if (rt == int.class) return 0;
                        if (rt == boolean.class) return Boolean.FALSE;
                        return null;
                    });

            Method make = find(lib, "newCoreController", 1);
            if (make == null) throw new IllegalStateException("La librer\u00eda V2Ray no es compatible (falta newCoreController)");
            controller = make.invoke(null, handler);

            Method one = find(controller.getClass(), "startLoop", 1);
            if (one != null) {
                one.invoke(controller, config);
            } else {
                Method two = find(controller.getClass(), "startLoop", 2);
                if (two == null) throw new IllegalStateException("La librer\u00eda V2Ray no es compatible (falta startLoop)");
                two.invoke(controller, config, 0);   // sin TUN propio: el t\u00fanel lo maneja hev
            }
        } catch (InvocationTargetException e) {
            controller = null;
            Throwable c = e.getCause() != null ? e.getCause() : e;
            throw c instanceof Exception ? (Exception) c : new Exception(c);
        }
    }

    void stop() {
        Object c = controller;
        controller = null;
        if (c == null) return;
        try {
            Method m = find(c.getClass(), "stopLoop", 0);
            if (m != null) m.invoke(c);
        } catch (Throwable ignored) { }
    }

    private static Method find(Class<?> c, String name, int nParams) {
        for (Method m : c.getMethods()) {
            if (m.getName().equals(name) && m.getParameterTypes().length == nParams) return m;
        }
        return null;
    }
}
