package com.mivpn.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;

/**
 * Dos modos:
 *  - Directo: si el dispositivo tiene una licencia de IA (AiLicense, archivo ligado a su HWID) o
 *    la compilación trae GEMINI_API_KEY, habla con Gemini sin pasar por el VPS. Lo normal es
 *    usar la licencia: así ningún APK lleva la llave. Si se usa GEMINI_API_KEY, conviene
 *    restringirla al paquete y a la firma de la app en Google (ver cabeceras X-Android-*).
 *  - Proxy: si no hay llave, usa el proxy del VPS (ai_proxy.py), como antes.
 * Experimental: se puede quitar entero borrando esta clase y los botones que la usan.
 */
public final class AiAssistant {

    public interface Callback {
        void onReply(String text);
        void onError(String message);
    }

    private AiAssistant() { }

    /** Llave de Gemini a usar: la de la licencia del dispositivo, o la de la compilación si la trae. */
    private static String key(android.content.Context ctx) {
        String k = AiLicense.key(ctx);
        return k.isEmpty() ? BuildConfig.GEMINI_API_KEY : k;
    }

    /** true si hay llave de Gemini (licencia o compilación) y se habla directo, sin VPS. */
    public static boolean isDirect(android.content.Context ctx) { return !key(ctx).isEmpty(); }

    /** Igual que ask(), pero directo con Gemini (no necesita servidor ni palabra secreta). */
    public static void askDirect(final android.app.Activity ui, final String prompt, final Callback cb) {
        String limit = AiLicense.consume(ui);   // cuenta la consulta si hay licencia con límite
        if (limit != null) { cb.onError(limit); return; }
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override public void run() {
                try {
                    final String reply = callGemini(ui, prompt);
                    ui.runOnUiThread(new Runnable() { @Override public void run() { cb.onReply(reply); } });
                } catch (final Exception e) {
                    final String msg = friendly(e);
                    ui.runOnUiThread(new Runnable() { @Override public void run() { cb.onError(msg); } });
                }
            }
        });
    }

    private static String callGemini(android.content.Context ctx, String prompt) throws Exception {
        JSONObject part = new JSONObject().put("text", prompt);
        JSONObject content = new JSONObject().put("parts", new JSONArray().put(part));
        JSONObject body = new JSONObject().put("contents", new JSONArray().put(content));
        byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);

        URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/"
                + BuildConfig.GEMINI_MODEL + ":generateContent");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        try {
            c.setRequestMethod("POST");
            c.setConnectTimeout(10_000);
            c.setReadTimeout(60_000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setRequestProperty("x-goog-api-key", key(ctx));
            // Permiten restringir la llave a esta app en la consola de Google.
            c.setRequestProperty("X-Android-Package", ctx.getPackageName());
            String cert = certSha1(ctx);
            if (cert != null) c.setRequestProperty("X-Android-Cert", cert);
            try (OutputStream o = c.getOutputStream()) { o.write(data); }

            int code = c.getResponseCode();
            String text = readAll(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream());
            JSONObject resp = new JSONObject(text);
            if (code != 200) {
                JSONObject err = resp.optJSONObject("error");
                throw new IOException(err != null ? err.optString("message", "Gemini respondió " + code)
                        : "Gemini respondió " + code);
            }
            JSONArray cands = resp.optJSONArray("candidates");
            if (cands == null || cands.length() == 0) return "(sin respuesta)";
            JSONObject cc = cands.getJSONObject(0).optJSONObject("content");
            JSONArray parts = cc == null ? null : cc.optJSONArray("parts");
            if (parts == null) return "(sin respuesta)";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length(); i++) sb.append(parts.getJSONObject(i).optString("text", ""));
            return sb.length() == 0 ? "(sin respuesta)" : sb.toString().trim();
        } finally {
            c.disconnect();
        }
    }

    /** SHA-1 del certificado de firma, en hexadecimal mayúscula sin separadores. */
    @SuppressWarnings("deprecation")
    private static String certSha1(android.content.Context ctx) {
        try {
            android.content.pm.PackageManager pm = ctx.getPackageManager();
            android.content.pm.Signature[] sigs;
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                android.content.pm.SigningInfo si = pm.getPackageInfo(ctx.getPackageName(),
                        android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES).signingInfo;
                sigs = si.getApkContentsSigners();
            } else {
                sigs = pm.getPackageInfo(ctx.getPackageName(),
                        android.content.pm.PackageManager.GET_SIGNATURES).signatures;
            }
            byte[] h = java.security.MessageDigest.getInstance("SHA-1").digest(sigs[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (byte b : h) sb.append(String.format("%02X", b));
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    /** Llama al proxy en un hilo aparte y entrega el resultado en el hilo de la interfaz. */
    public static void ask(final android.app.Activity ui, final String host, final int port,
                            final String token, final String prompt, final Callback cb) {
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override public void run() {
                try {
                    final String reply = call(host, port, token, prompt);
                    ui.runOnUiThread(new Runnable() { @Override public void run() { cb.onReply(reply); } });
                } catch (final Exception e) {
                    final String msg = friendly(e);
                    ui.runOnUiThread(new Runnable() { @Override public void run() { cb.onError(msg); } });
                }
            }
        });
    }

    private static String call(String host, int port, String token, String prompt) throws Exception {
        JSONObject body = new JSONObject();
        body.put("token", token);
        body.put("prompt", prompt);
        byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);

        URL url = new URL("http://" + host + ":" + port + "/");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        try {
            c.setRequestMethod("POST");
            c.setConnectTimeout(8_000);
            c.setReadTimeout(30_000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            try (OutputStream o = c.getOutputStream()) { o.write(data); }

            int code = c.getResponseCode();
            String text = readAll(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream());
            JSONObject resp = new JSONObject(text);
            if (code != 200) {
                throw new IOException(resp.optString("error", "el servidor respondió " + code));
            }
            return resp.optString("reply", "(sin respuesta)");
        } finally {
            c.disconnect();
        }
    }

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) >= 0) bo.write(buf, 0, n);
        return bo.toString("UTF-8");
    }

    private static String friendly(Exception e) {
        if (e instanceof java.net.SocketTimeoutException) return "El servidor no respondió a tiempo.";
        if (e instanceof java.net.ConnectException || e instanceof java.net.UnknownHostException) {
            return "No se pudo conectar al asistente. Revisa el servidor y el puerto.";
        }
        String m = e.getMessage();
        return m != null && !m.isEmpty() ? m : "No se pudo hablar con el asistente.";
    }
}
