package com.mivpn.app;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;

/**
 * Habla con el proxy de IA que corre en el VPS (ai_proxy.py), nunca directo con Gemini:
 * así la llave de la API nunca viaja dentro del APK. Experimental: se puede quitar entero
 * borrando esta clase y los botones que la usan, sin afectar al resto de la app.
 */
public final class AiAssistant {

    public interface Callback {
        void onReply(String text);
        void onError(String message);
    }

    private AiAssistant() { }

    /** Llama al proxy en un hilo aparte y entrega el resultado en el hilo de la interfaz. */
    public static void ask(final android.app.Activity ui, final String host, final int port,
                            final String token, final String prompt, final Callback cb) {
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override public void run() {
                try {
                    final String reply = call(host, port, token, prompt);
                    ui.runOnUiThread(new Runnable() { @Override public void run() { cb.onReply(reply); } });
                } catch (final Exception e) {
                    final String msg = friendly(e);
                    ui.runOnUiThread(new Runnable() { @Override public void run() { cb.onError(msg); } });
                }
            }
        });
    }

    private static String call(String host, int port, String token, String prompt) throws Exception {
        JSONObject body = new JSONObject();
        body.put("token", token);
        body.put("prompt", prompt);
        byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);

        URL url = new URL("http://" + host + ":" + port + "/");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        try {
            c.setRequestMethod("POST");
            c.setConnectTimeout(8_000);
            c.setReadTimeout(30_000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            try (OutputStream o = c.getOutputStream()) { o.write(data); }

            int code = c.getResponseCode();
            String text = readAll(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream());
            JSONObject resp = new JSONObject(text);
            if (code != 200) {
                throw new IOException(resp.optString("error", "el servidor respondió " + code));
            }
            return resp.optString("reply", "(sin respuesta)");
        } finally {
            c.disconnect();
        }
    }

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) >= 0) bo.write(buf, 0, n);
        return bo.toString("UTF-8");
    }

    private static String friendly(Exception e) {
        if (e instanceof java.net.SocketTimeoutException) return "El servidor no respondió a tiempo.";
        if (e instanceof java.net.ConnectException || e instanceof java.net.UnknownHostException) {
            return "No se pudo conectar al asistente. Revisa el servidor y el puerto.";
        }
        String m = e.getMessage();
        return m != null && !m.isEmpty() ? m : "No se pudo hablar con el asistente.";
    }
}
