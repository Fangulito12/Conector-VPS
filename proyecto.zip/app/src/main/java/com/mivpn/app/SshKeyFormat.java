package com.mivpn.app;

import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.interfaces.ECPublicKey;
import java.util.Base64;

/** Convierte una llave EC P-256 al formato de OpenSSH (authorized_keys) y calcula el HWID. Java puro. */
public final class SshKeyFormat {
    private SshKeyFormat() {}

    public static byte[] blob(ECPublicKey pub) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        writeString(out, "ecdsa-sha2-nistp256".getBytes(StandardCharsets.US_ASCII));
        writeString(out, "nistp256".getBytes(StandardCharsets.US_ASCII));
        byte[] q = new byte[65];
        q[0] = 0x04;
        System.arraycopy(fixed32(pub.getW().getAffineX()), 0, q, 1, 32);
        System.arraycopy(fixed32(pub.getW().getAffineY()), 0, q, 33, 32);
        writeString(out, q);
        return out.toByteArray();
    }

    /** HWID = huella SHA-256 de la llave pública, 16 hex en grupos de 4. Ej: 3F9A-12BC-77D0-A1E4 */
    public static String hwid(ECPublicKey pub) throws Exception {
        byte[] h = MessageDigest.getInstance("SHA-256").digest(blob(pub));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            if (i > 0 && i % 2 == 0) sb.append('-');
            sb.append(String.format("%02X", h[i] & 0xFF));
        }
        return sb.toString();
    }

    /** Línea lista para pegar en el script del VPS. */
    public static String publicLine(ECPublicKey pub) throws Exception {
        return "ecdsa-sha2-nistp256 " + Base64.getEncoder().encodeToString(blob(pub)) + " hwid-" + hwid(pub);
    }

    private static byte[] fixed32(BigInteger v) {
        byte[] b = v.toByteArray();
        byte[] r = new byte[32];
        if (b.length > 32) System.arraycopy(b, b.length - 32, r, 0, 32);
        else System.arraycopy(b, 0, r, 32 - b.length, b.length);
        return r;
    }

    private static void writeString(ByteArrayOutputStream out, byte[] data) {
        out.write((data.length >>> 24) & 0xFF);
        out.write((data.length >>> 16) & 0xFF);
        out.write((data.length >>> 8) & 0xFF);
        out.write(data.length & 0xFF);
        out.write(data, 0, data.length);
    }
}
