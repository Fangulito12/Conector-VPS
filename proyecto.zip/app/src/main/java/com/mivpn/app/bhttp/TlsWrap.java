package com.mivpn.app.bhttp;

import java.io.IOException;
import java.net.Socket;
import java.util.Collections;

import javax.net.ssl.SNIHostName;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * Envuelve un socket TCP ya conectado en TLS 1.2 con un SNI elegido.
 *
 * - Solo se habilita TLSv1.2 (el servidor debe aceptarlo: nginx stream / stunnel / haproxy).
 * - La validación del certificado queda ACTIVA: se verifica contra el nombre del SNI usando
 *   los certificados de confianza de Android. No se acepta "cualquier certificado".
 * - El socket original ya pasó por VpnService.protect(), así que el TLS no entra en el túnel.
 */
final class TlsWrap {
    private static volatile SSLSocketFactory factory;

    private TlsWrap() {}

    private static SSLSocketFactory factory() throws IOException {
        SSLSocketFactory f = factory;
        if (f != null) return f;
        try {
            SSLContext ctx = SSLContext.getInstance("TLSv1.2");
            ctx.init(null, null, null);          // TrustManager y SecureRandom por defecto del sistema
            f = ctx.getSocketFactory();
            factory = f;
            return f;
        } catch (Exception e) {
            throw new IOException("No se pudo iniciar TLS 1.2: " + e.getMessage(), e);
        }
    }

    private static boolean isIpLiteral(String h) {
        return h.indexOf(':') >= 0 || h.matches("\\d{1,3}(\\.\\d{1,3}){3}");
    }

    /**
     * @param plain socket TCP ya conectado (y protegido).
     * @param name nombre del servidor: se usa como SNI (automático) y para verificar el certificado.
     *             Si es una IP no se envía SNI (el estándar no lo permite) y el certificado se
     *             verifica contra esa IP.
     */
    static SSLSocket wrap(Socket plain, String name, int port, int handshakeTimeoutMs) throws IOException {
        SSLSocket ssl = (SSLSocket) factory().createSocket(plain, name, port, true);
        try {
            ssl.setEnabledProtocols(new String[]{"TLSv1.2"});
            SSLParameters p = ssl.getSSLParameters();
            if (!isIpLiteral(name)) {
                p.setServerNames(Collections.singletonList(new SNIHostName(name)));
            }
            p.setEndpointIdentificationAlgorithm("HTTPS");   // verifica nombre del certificado
            ssl.setSSLParameters(p);
            ssl.setSoTimeout(handshakeTimeoutMs);
            ssl.startHandshake();
            return ssl;
        } catch (IOException | RuntimeException e) {
            try { ssl.close(); } catch (IOException ignored) {}
            throw e;
        }
    }
}
