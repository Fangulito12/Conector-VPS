package com.mivpn.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.View;
import java.util.ArrayList;

/** Curva de velocidad en vivo, estilo speed.cloudflare.com. */
public class SpeedGraphView extends View {
    private final ArrayList<Float> pts = new ArrayList<>();
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);

    public SpeedGraphView(Context c) {
        super(c);
        line.setColor(Color.rgb(246, 130, 31));
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(4f);
        fill.setStyle(Paint.Style.FILL);
    }

    public void clear() { pts.clear(); invalidate(); }

    public void add(double mbps) { pts.add((float) mbps); invalidate(); }

    @Override protected void onDraw(Canvas cv) {
        if (pts.size() < 2) return;
        float w = getWidth(), h = getHeight(), max = 0.1f;
        for (float p : pts) max = Math.max(max, p);
        max *= 1.15f;

        Path path = new Path();
        for (int i = 0; i < pts.size(); i++) {
            float x = w * i / (pts.size() - 1);
            float y = h - (pts.get(i) / max) * h;
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        Path area = new Path(path);
        area.lineTo(w, h);
        area.lineTo(0, h);
        area.close();

        fill.setShader(new LinearGradient(0, 0, 0, h,
                Color.argb(120, 246, 130, 31), Color.argb(0, 246, 130, 31),
                Shader.TileMode.CLAMP));
        cv.drawPath(area, fill);
        cv.drawPath(path, line);
    }
}
