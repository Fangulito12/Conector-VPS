package com.mivpn.app.bhttp;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.Locale;

import javax.net.ssl.SNIHostName;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Capa de transporte opcional para BhttpBridge:
 *   1) Proxy HTTP (método CONNECT) hacia el servidor, si se configura.
 *   2) TLS 1.2 (solo 1.2, sin 1.0/1.1/1.3) con SNI, si se activa.
 *
 * El servidor debe estar escuchando TLS en ese puerto (nginx stream / stunnel / haproxy,
 * reenviando en claro hacia el puerto BHTTP real).
 *
 * Verificación del certificado:
 *   - Si se da pinSha256 (huella SHA-256 del certificado del servidor, en hex): se compara
 *     contra esa huella (sirve con certificados autofirmados y con IP en vez de dominio).
 *   - Si no: validación normal de Android (CA del sistema + nombre de host del SNI).
 */
public final class TlsTransport {
    public static final TlsTransport NONE = new TlsTransport(false, null, null, 0, null);

    public final boolean tls;
    public final String sni;          // nombre para SNI y para validar el certificado
    public final String proxyHost;    // null = sin proxy
    public final int proxyPort;
    public final String pinSha256;    // hex sin ':' en minúsculas, o null

    public TlsTransport(boolean tls, String sni, String proxyHost, int proxyPort, String pinSha256) {
        this.tls = tls;
        this.sni = (sni == null || sni.trim().isEmpty()) ? null : sni.trim();
        this.proxyHost = (proxyHost == null || proxyHost.trim().isEmpty() || proxyPort <= 0) ? null : proxyHost.trim();
        this.proxyPort = this.proxyHost == null ? 0 : proxyPort;
        this.pinSha256 = normPin(pinSha256);
    }

    public boolean isPlain() { return !tls && proxyHost == null; }

    /** Acepta "host:puerto" (ej. "127.0.0.1:8080"). Devuelve null si no es válido. */
    public static String[] parseHostPort(String s) {
        if (s == null) return null;
        s = s.trim();
        int i = s.lastIndexOf(':');
        if (i <= 0 || i == s.length() - 1) return null;
        try {
            int p = Integer.parseInt(s.substring(i + 1));
            if (p < 1 || p > 65535) return null;
            return new String[]{s.substring(0, i), String.valueOf(p)};
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static String normPin(String p) {
        if (p == null) return null;
        String n = p.replace(":", "").replace(" ", "").toLowerCase(Locale.ROOT);
        return n.matches("[0-9a-f]{64}") ? n : null;
    }

    /**
     * Conecta (a través del proxy si hay) y devuelve el socket listo para usar.
     * 'socket' ya viene creado, enlazado y protegido (protect) por quien llama, sin conectar.
     */
    public Socket connect(Socket socket, String host, int port, int connectTimeoutMs) throws IOException {
        if (proxyHost != null) {
            socket.connect(new InetSocketAddress(proxyHost, proxyPort), connectTimeoutMs);
            socket.setSoTimeout(connectTimeoutMs);
            httpConnect(socket, host, port);
        } else {
            socket.connect(new InetSocketAddress(host, port), connectTimeoutMs);
            socket.setSoTimeout(connectTimeoutMs);
        }
        if (!tls) return socket;

        try {
            SSLContext ctx = SSLContext.getInstance("TLSv1.2");
            TrustManager[] tms = (pinSha256 == null) ? null : new TrustManager[]{new PinTrust(pinSha256)};
            ctx.init(null, tms, new SecureRandom());
            SSLSocketFactory f = ctx.getSocketFactory();
            String name = (sni != null) ? sni : host;
            SSLSocket ssl = (SSLSocket) f.createSocket(socket, name, port, true);
            ssl.setEnabledProtocols(new String[]{"TLSv1.2"});
            SSLParameters sp = ssl.getSSLParameters();
            if (!isIp(name)) sp.setServerNames(Collections.singletonList(new SNIHostName(name)));
            if (pinSha256 == null && !isIp(name)) sp.setEndpointIdentificationAlgorithm("HTTPS");
            ssl.setSSLParameters(sp);
            ssl.startHandshake();
            return ssl;
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("TLS 1.2: " + e.getMessage(), e);
        }
    }

    private static void httpConnect(Socket s, String host, int port) throws IOException {
        String req = "CONNECT " + host + ":" + port + " HTTP/1.1\r\n"
                + "Host: " + host + ":" + port + "\r\n"
                + "Proxy-Connection: keep-alive\r\n\r\n";
        OutputStream out = s.getOutputStream();
        out.write(req.getBytes(StandardCharsets.US_ASCII));
        out.flush();

        // Leer solo hasta el final de las cabeceras (\r\n\r\n), byte a byte, para no
        // comerse datos del túnel que vengan pegados.
        InputStream in = s.getInputStream();
        StringBuilder sb = new StringBuilder();
        int state = 0;
        while (state < 4) {
            int b = in.read();
            if (b < 0) throw new IOException("Proxy cerró la conexión");
            sb.append((char) b);
            if (sb.length() > 8192) throw new IOException("Respuesta del proxy demasiado larga");
            if ((b == '\r' && (state == 0 || state == 2)) || (b == '\n' && (state == 1 || state == 3))) state++;
            else state = (b == '\r') ? 1 : 0;
        }
        String first = sb.substring(0, Math.max(0, sb.indexOf("\r\n")));
        String[] parts = first.split(" ");
        if (parts.length < 2 || !parts[1].startsWith("2")) {
            throw new IOException("Proxy rechazó CONNECT: " + first);
        }
    }

    private static boolean isIp(String h) {
        return h.matches("\\d{1,3}(\\.\\d{1,3}){3}") || h.contains(":");
    }

    /** Valida el certificado del servidor comparando su huella SHA-256 con la configurada. */
    private static final class PinTrust implements X509TrustManager {
        private final String pin;
        PinTrust(String pin) { this.pin = pin; }

        @Override public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            throw new CertificateException("No se usa autenticación de cliente");
        }

        @Override public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            if (chain == null || chain.length == 0) throw new CertificateException("Sin certificado");
            try {
                byte[] d = MessageDigest.getInstance("SHA-256").digest(chain[0].getEncoded());
                StringBuilder sb = new StringBuilder();
                for (byte b : d) sb.append(String.format("%02x", b));
                if (!MessageDigest.isEqual(sb.toString().getBytes(StandardCharsets.US_ASCII),
                        pin.getBytes(StandardCharsets.US_ASCII))) {
                    throw new CertificateException("La huella del certificado no coincide");
                }
            } catch (CertificateException e) {
                throw e;
            } catch (Exception e) {
                throw new CertificateException(e);
            }
        }

        @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
    }
}
