package com.mivpn.app;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadFactory;

/**
 * Compartir la conexi\u00f3n del t\u00fanel con otros dispositivos (hotspot / Wi-Fi).
 *
 * Escucha en todas las interfaces y entiende, en el mismo puerto, proxy HTTP (CONNECT y peticiones http://)
 * y SOCKS5. Todo lo que recibe sale por el SOCKS5 local del SSH, es decir, por dentro del t\u00fanel.
 * Solo acepta clientes de redes locales (192.168.x.x, 10.x.x.x, 172.16-31.x.x, etc.); nunca de internet.
 * El otro dispositivo debe configurar el proxy a mano (IP del tel\u00e9fono + puerto): Android no deja
 * meter el tr\u00e1fico del hotspot dentro de una VPN sin root.
 */
final class SharedProxy {
    interface Logger { void log(String line); }

    private static final int MAX_CLIENTS = 256;
    private static final int HEAD_LIMIT = 32 * 1024;

    private final int port;
    private final int upstreamPort;
    private final Logger logger;
    private final Set<Socket> open = ConcurrentHashMap.newKeySet();
    private final Set<String> seenClients = ConcurrentHashMap.newKeySet();
    private final Semaphore slots = new Semaphore(MAX_CLIENTS);
    private final ExecutorService pool = Executors.newCachedThreadPool(new ThreadFactory() {
        @Override public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "shared-proxy");
            t.setDaemon(true);
            return t;
        }
    });
    private volatile boolean running;
    private ServerSocket server;

    SharedProxy(int port, int upstreamSocksPort, Logger logger) {
        this.port = port;
        this.upstreamPort = upstreamSocksPort;
        this.logger = logger;
    }

    void start() throws IOException {
        ServerSocket s = new ServerSocket();
        s.setReuseAddress(true);
        s.bind(new InetSocketAddress(port));   // todas las interfaces (el hotspot incluido)
        server = s;
        running = true;
        pool.execute(() -> acceptLoop(s));
    }

    void close() {
        running = false;
        try { if (server != null) server.close(); } catch (IOException ignored) { }
        for (Socket s : open) closeQuiet(s);
        open.clear();
        pool.shutdownNow();
    }

    /** Direcciones IPv4 locales del tel\u00e9fono (incluida la del hotspot si est\u00e1 encendido), con el puerto: "192.168.43.1:8080". */
    static String addresses(int port) {
        List<String> out = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) out.add(a.getHostAddress() + ":" + port);
                }
            }
        } catch (Throwable ignored) { }
        if (out.isEmpty()) return "(enciende el hotspot o el Wi-Fi para ver la IP)";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < out.size(); i++) { if (i > 0) sb.append("  \u00b7  "); sb.append(out.get(i)); }
        return sb.toString();
    }

    // ------------------------------------------------------------------ servidor

    private void acceptLoop(ServerSocket s) {
        while (running) {
            final Socket c;
            try {
                c = s.accept();
            } catch (IOException e) {
                break;
            }
            if (!allowed(c.getInetAddress()) || !slots.tryAcquire()) {
                closeQuiet(c);
                continue;
            }
            open.add(c);
            pool.execute(() -> {
                try {
                    String ip = c.getInetAddress().getHostAddress();
                    if (seenClients.size() < 50 && seenClients.add(ip)) logger.log("Compartir: cliente " + ip + " conectado");
                    handle(c);
                } catch (Throwable ignored) {
                } finally {
                    open.remove(c);
                    closeQuiet(c);
                    slots.release();
                }
            });
        }
    }

    private static boolean allowed(InetAddress a) {
        if (a == null) return false;
        if (a.isLoopbackAddress() || a.isSiteLocalAddress() || a.isLinkLocalAddress()) return true;
        byte[] b = a.getAddress();
        return b.length == 16 && (b[0] & 0xFE) == 0xFC;   // IPv6 local (fc00::/7)
    }

    private void handle(Socket c) throws IOException {
        c.setTcpNoDelay(true);
        c.setSoTimeout(60_000);   // espera de la primera petici\u00f3n
        InputStream in = new BufferedInputStream(c.getInputStream(), 8192);
        OutputStream out = c.getOutputStream();
        in.mark(1);
        int first = in.read();
        if (first < 0) return;
        in.reset();
        if (first == 5) {
            // SOCKS5: se pasa tal cual al SOCKS5 del t\u00fanel
            Socket up = new Socket();
            up.connect(new InetSocketAddress("127.0.0.1", upstreamPort), 5000);
            open.add(up);
            pipeBoth(c, in, out, up);
        } else {
            handleHttp(c, in, out);
        }
    }

    private void handleHttp(Socket c, InputStream in, OutputStream out) throws IOException {
        byte[] head = readHead(in);
        if (head == null) { httpError(out, 400, "Bad Request"); return; }
        String text = new String(head, StandardCharsets.ISO_8859_1);
        int eol = text.indexOf("\r\n");
        String[] p = text.substring(0, eol).split(" ");
        if (p.length < 3) { httpError(out, 400, "Bad Request"); return; }
        String method = p[0], target = p[1], version = p[2];

        if ("CONNECT".equalsIgnoreCase(method)) {
            Socket up;
            try {
                String[] hp = hostPort(target, 443);
                up = connectViaSocks(hp[0], Integer.parseInt(hp[1]));
            } catch (Exception e) {
                httpError(out, 502, "Bad Gateway");
                return;
            }
            open.add(up);
            out.write("HTTP/1.1 200 Connection Established\r\n\r\n".getBytes(StandardCharsets.ISO_8859_1));
            out.flush();
            pipeBoth(c, in, out, up);
            return;
        }

        if (!target.regionMatches(true, 0, "http://", 0, 7)) { httpError(out, 400, "Bad Request"); return; }
        String rest = target.substring(7);
        int slash = rest.indexOf('/');
        String hostPart = slash < 0 ? rest : rest.substring(0, slash);
        String path = slash < 0 ? "/" : rest.substring(slash);
        Socket up;
        try {
            String[] hp = hostPort(hostPart, 80);
            up = connectViaSocks(hp[0], Integer.parseInt(hp[1]));
        } catch (Exception e) {
            httpError(out, 502, "Bad Gateway");
            return;
        }
        open.add(up);
        // La petici\u00f3n se reenv\u00eda en formato normal (sin la URL completa) y con "Connection: close":
        // una conexi\u00f3n por petici\u00f3n, el navegador abre otra para la siguiente.
        StringBuilder sb = new StringBuilder();
        sb.append(method).append(' ').append(path).append(' ').append(version).append("\r\n");
        for (String line : text.substring(eol + 2).split("\r\n")) {
            if (line.isEmpty()) continue;
            String low = line.toLowerCase(Locale.ROOT);
            if (low.startsWith("proxy-connection:") || low.startsWith("connection:")
                    || low.startsWith("proxy-authorization:") || low.startsWith("keep-alive:")) continue;
            sb.append(line).append("\r\n");
        }
        sb.append("Connection: close\r\n\r\n");
        OutputStream uo = up.getOutputStream();
        uo.write(sb.toString().getBytes(StandardCharsets.ISO_8859_1));
        uo.flush();
        pipeBoth(c, in, out, up);   // el cuerpo de la petici\u00f3n (si hay) sigue saliendo de "in"
    }

    // ------------------------------------------------------------------ auxiliares

    private static byte[] readHead(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(512);
        int b, matched = 0;
        while ((b = in.read()) >= 0) {
            bo.write(b);
            if (bo.size() > HEAD_LIMIT) return null;
            if ((matched == 0 || matched == 2) && b == '\r') matched++;
            else if ((matched == 1 || matched == 3) && b == '\n') matched++;
            else matched = (b == '\r') ? 1 : 0;
            if (matched == 4) return bo.toByteArray();
        }
        return null;
    }

    private static String[] hostPort(String hp, int def) {
        String h = hp.trim();
        if (h.startsWith("[")) {   // IPv6: [::1]:443
            int e = h.indexOf(']');
            String host = h.substring(1, e);
            String port = (h.length() > e + 2 && h.charAt(e + 1) == ':') ? h.substring(e + 2) : String.valueOf(def);
            return new String[]{host, port};
        }
        int c = h.lastIndexOf(':');
        if (c > 0 && h.indexOf(':') == c) return new String[]{h.substring(0, c), h.substring(c + 1)};
        return new String[]{h, String.valueOf(def)};
    }

    private static byte[] readFully(InputStream in, int n) throws IOException {
        byte[] b = new byte[n];
        int off = 0;
        while (off < n) {
            int r = in.read(b, off, n - off);
            if (r < 0) throw new IOException("conexi\u00f3n cerrada");
            off += r;
        }
        return b;
    }

    /** Abre una conexi\u00f3n al destino a trav\u00e9s del SOCKS5 del t\u00fanel (sin usuario). */
    private Socket connectViaSocks(String host, int port) throws IOException {
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress("127.0.0.1", upstreamPort), 5000);
            s.setTcpNoDelay(true);
            s.setSoTimeout(30_000);   // saludo + conexi\u00f3n al destino
            OutputStream o = s.getOutputStream();
            InputStream i = s.getInputStream();
            o.write(new byte[]{5, 1, 0});
            o.flush();
            byte[] r = readFully(i, 2);
            if (r[0] != 5 || r[1] != 0) throw new IOException("SOCKS5 sin autenticaci\u00f3n no aceptado");
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            b.write(5); b.write(1); b.write(0);
            byte[] lit = literalIp(host);
            if (lit != null) {
                b.write(lit.length == 4 ? 1 : 4);
                b.write(lit);
            } else {
                byte[] h = host.getBytes(StandardCharsets.UTF_8);
                if (h.length == 0 || h.length > 255) throw new IOException("nombre de destino inv\u00e1lido");
                b.write(3); b.write(h.length); b.write(h);
            }
            b.write(port >> 8); b.write(port & 0xFF);
            o.write(b.toByteArray());
            o.flush();
            byte[] hd = readFully(i, 4);
            if (hd[1] != 0) throw new IOException("destino rechazado (SOCKS " + hd[1] + ")");
            if (hd[3] == 1) readFully(i, 6);
            else if (hd[3] == 4) readFully(i, 18);
            else { int len = readFully(i, 1)[0] & 0xFF; readFully(i, len + 2); }
            return s;
        } catch (IOException | RuntimeException e) {
            closeQuiet(s);
            throw e;
        }
    }

    /** Devuelve los bytes de una IP escrita en n\u00fameros (IPv4 o IPv6), o null si es un nombre. No hace DNS. */
    private static byte[] literalIp(String host) {
        try {
            if (host.matches("\\d{1,3}(\\.\\d{1,3}){3}") || host.indexOf(':') >= 0) {
                return InetAddress.getByName(host).getAddress();
            }
        } catch (Exception ignored) { }
        return null;
    }

    private void pipeBoth(final Socket a, InputStream ain, OutputStream aout, final Socket b) throws IOException {
        b.setTcpNoDelay(true);
        a.setSoTimeout(300_000);
        b.setSoTimeout(300_000);
        final InputStream bin = b.getInputStream();
        final OutputStream bout = b.getOutputStream();
        final OutputStream aoutF = aout;
        pool.execute(() -> {
            copy(bin, aoutF);
            closeQuiet(a);
            closeQuiet(b);
        });
        copy(ain, bout);
        closeQuiet(a);
        closeQuiet(b);
        open.remove(b);
    }

    private static void copy(InputStream in, OutputStream out) {
        byte[] buf = new byte[16384];
        try {
            int n;
            while ((n = in.read(buf)) >= 0) {
                out.write(buf, 0, n);
                out.flush();
            }
        } catch (IOException ignored) {
        }
    }

    private static void httpError(OutputStream out, int code, String msg) {
        try {
            out.write(("HTTP/1.1 " + code + " " + msg + "\r\nConnection: close\r\nContent-Length: 0\r\n\r\n")
                    .getBytes(StandardCharsets.ISO_8859_1));
            out.flush();
        } catch (IOException ignored) { }
    }

    private static void closeQuiet(Socket s) {
        try { s.close(); } catch (IOException ignored) { }
    }
}
