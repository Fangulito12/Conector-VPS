package com.mivpn.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInstaller;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Actualizador integrado. Al abrir la app consulta el \u00faltimo Release de GitHub (BuildConfig.UPDATE_REPO);
 * si su versi\u00f3n es mayor que la instalada, ofrece actualizar: descarga el APK directo al instalador de
 * Android (PackageInstaller) y Android pide un solo toque de confirmaci\u00f3n. El APK nuevo solo se instala
 * si est\u00e1 firmado con la misma clave que la app (la firma fija conecta.p12).
 * Si UPDATE_REPO queda vac\u00edo (compilaci\u00f3n local), no hace nada.
 */
final class Updater {
    private Updater() {}

    private static final long MIN_INTERVAL_MS = 10 * 60 * 1000L;   // consulta autom\u00e1tica: m\u00e1ximo 1 vez cada 10 min
    private static final Handler UI = new Handler(Looper.getMainLooper());
    private static volatile boolean busy;
    private static Info pending;                  // actualizaci\u00f3n a la espera de que se d\u00e9 el permiso de instalar
    private static BroadcastReceiver receiver;
    private static String dismissedTag;            // versi\u00f3n que ya se rechaz\u00f3 con "Despu\u00e9s" (no se vuelve a ofrecer sola)

    private static final class Info {
        String tag, notes, url;
        long size;
    }

    private interface Progress { void on(long done, long total); }

    /** Consulta autom\u00e1tica (al abrir/volver a la app). Solo avisa si hay versi\u00f3n nueva. */
    static void check(final Activity act) { check(act, false); }

    /**
     * manual = true cuando el usuario toca el bot\u00f3n "Actualizar": ignora el l\u00edmite de tiempo y siempre
     * responde (hay versi\u00f3n nueva, ya tienes la \u00faltima, o por qu\u00e9 no se pudo consultar).
     */
    static void check(final Activity act, final boolean manual) {
        if (BuildConfig.UPDATE_REPO.isEmpty()) {
            if (manual) Toast.makeText(act, "Esta compilaci\u00f3n no tiene actualizador (se compil\u00f3 fuera de GitHub).", Toast.LENGTH_LONG).show();
            return;
        }
        if (busy) {
            if (manual) Toast.makeText(act, "Ya se est\u00e1 buscando\u2026", Toast.LENGTH_SHORT).show();
            return;
        }
        final SharedPreferences prefs = act.getSharedPreferences("cfg", Context.MODE_PRIVATE);
        final long now = System.currentTimeMillis();
        if (!manual && now - prefs.getLong("updLast", 0) < MIN_INTERVAL_MS) return;
        busy = true;
        if (manual) Toast.makeText(act, "Buscando actualizaci\u00f3n\u2026", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            Info found = null;
            String error = null;
            try {
                found = fetchLatest();
                prefs.edit().putLong("updLast", now).apply();   // solo si la consulta funcion\u00f3
            } catch (Exception e) {
                error = e.getMessage() == null ? e.toString() : e.getMessage();
                TunnelService.appendLog("Actualizador: no se pudo consultar (" + error + ")");
            }
            busy = false;
            final Info info = found;
            final String err = error;
            UI.post(() -> {
                if (act.isFinishing() || act.isDestroyed()) return;
                if (info != null) {
                    if (manual || !info.tag.equals(dismissedTag)) offer(act, info);
                } else if (manual) {
                    Toast.makeText(act, err != null ? "No se pudo consultar: " + err
                            : "Ya tienes la \u00faltima versi\u00f3n (" + BuildConfig.VERSION_NAME + ").", Toast.LENGTH_LONG).show();
                }
            });
        }, "updater-check").start();
    }

    /** Llamar en onResume: si el usuario fue a dar el permiso de instalar, vuelve a ofrecer la actualizaci\u00f3n. */
    static void resumePending(Activity act) {
        if (pending == null) return;
        Info i = pending;
        pending = null;
        if (Build.VERSION.SDK_INT < 26 || act.getPackageManager().canRequestPackageInstalls()) offer(act, i);
    }

    private static boolean tunnelUp() {
        return TunnelService.state == TunnelService.ST_CONNECTED && TunnelService.activeSocksPort > 0;
    }

    /**
     * Esta app está excluida de la VPN (para que el túnel no se enrede consigo mismo), así que con el túnel
     * conectado sus consultas salen por la conexión directa, que además compite con las conexiones del propio
     * túnel. Con el túnel activo se sale por su SOCKS local; si no, o si falla, se usa la conexión directa.
     */
    private static HttpURLConnection open(String url, boolean viaTunnel) throws Exception {
        URL u = new URL(url);
        if (viaTunnel && tunnelUp()) {
            Proxy px = new Proxy(Proxy.Type.SOCKS, new InetSocketAddress("127.0.0.1", TunnelService.activeSocksPort));
            return (HttpURLConnection) u.openConnection(px);
        }
        return (HttpURLConnection) u.openConnection();
    }

    private static Info fetchLatest() throws Exception {
        if (tunnelUp()) {
            try {
                return fetchLatest(true);
            } catch (java.io.IOException e) {   // fallo de red por el t\u00fanel: se prueba directo
                TunnelService.appendLog("Actualizador: por el t\u00fanel no se pudo (" + e + "); se prueba directo");
            }
        }
        return fetchLatest(false);
    }

    private static Info fetchLatest(boolean viaTunnel) throws Exception {
        HttpURLConnection c = open(
                "https://api.github.com/repos/" + BuildConfig.UPDATE_REPO + "/releases/latest", viaTunnel);
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setRequestProperty("User-Agent", "Conecta-Updater");
        try {
            int code = c.getResponseCode();
            if (code == 404) throw new Exception("HTTP 404: no hay Releases publicados o el repositorio es privado");
            if (code != 200) throw new Exception("HTTP " + code);
            JSONObject j = new JSONObject(readAll(c.getInputStream()));
            String tag = j.optString("tag_name", "");
            TunnelService.appendLog("Actualizador: instalada " + BuildConfig.VERSION_NAME + " | \u00faltima en GitHub " + tag);
            if (!isNewer(tag, BuildConfig.VERSION_NAME)) return null;
            JSONArray assets = j.optJSONArray("assets");
            if (assets == null) return null;
            List<JSONObject> apks = new ArrayList<>();
            for (int i = 0; i < assets.length(); i++) {
                JSONObject a = assets.optJSONObject(i);
                if (a != null && a.optString("name", "").toLowerCase().endsWith(".apk")) apks.add(a);
            }
            JSONObject pick = null;
            if (apks.size() == 1) {
                pick = apks.get(0);
            } else {
                String hint = BuildConfig.UPDATE_ASSET.toLowerCase();
                for (JSONObject a : apks) {
                    if (a.optString("name", "").toLowerCase().contains(hint)) { pick = a; break; }
                }
            }
            if (pick == null) {
                TunnelService.appendLog("Actualizador: hay versi\u00f3n " + tag + " pero ning\u00fan APK coincide con '" + BuildConfig.UPDATE_ASSET + "'");
                return null;
            }
            Info info = new Info();
            info.tag = tag;
            info.notes = j.optString("body", "").trim();
            info.url = pick.optString("browser_download_url", "");
            info.size = pick.optLong("size", -1);
            return info.url.isEmpty() ? null : info;
        } finally {
            c.disconnect();
        }
    }

    private static String readAll(InputStream in) throws Exception {
        try (InputStream is = in) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) != -1) bo.write(buf, 0, n);
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    /** true si la versi\u00f3n de la etiqueta (ej. v1.24.57) es mayor que la instalada (ej. 1.24.56). */
    private static boolean isNewer(String tag, String current) {
        List<Integer> a = numbers(tag), b = numbers(current);
        if (a.isEmpty()) return false;
        int n = Math.max(a.size(), b.size());
        for (int i = 0; i < n; i++) {
            int x = i < a.size() ? a.get(i) : 0, y = i < b.size() ? b.get(i) : 0;
            if (x != y) return x > y;
        }
        return false;
    }

    private static List<Integer> numbers(String s) {
        List<Integer> out = new ArrayList<>();
        Matcher m = Pattern.compile("\\d{1,9}").matcher(s == null ? "" : s);
        while (m.find()) out.add(Integer.parseInt(m.group()));
        return out;
    }

    private static void offer(final Activity act, final Info info) {
        if (act.isFinishing() || act.isDestroyed()) return;
        String msg = "Hay una versi\u00f3n nueva: " + info.tag + " (tienes " + BuildConfig.VERSION_NAME + ").";
        if (!info.notes.isEmpty()) {
            msg += "\n\n" + (info.notes.length() > 400 ? info.notes.substring(0, 400) + "\u2026" : info.notes);
        }
        new AlertDialog.Builder(act)
                .setTitle("Actualizaci\u00f3n disponible")
                .setMessage(msg)
                .setPositiveButton("Actualizar", (d, w) -> start(act, info))
                .setNegativeButton("Despu\u00e9s", (d, w) -> dismissedTag = info.tag)
                .setOnCancelListener(d -> dismissedTag = info.tag)
                .show();
    }

    private static void start(Activity act, Info info) {
        if (Build.VERSION.SDK_INT >= 26 && !act.getPackageManager().canRequestPackageInstalls()) {
            pending = info;
            Toast.makeText(act, "Activa \u201cPermitir de esta fuente\u201d y vuelve a la app.", Toast.LENGTH_LONG).show();
            act.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + act.getPackageName())));
            return;
        }
        download(act, info);
    }

    private static void download(final Activity act, final Info info) {
        if (busy) return;
        busy = true;
        final boolean[] cancel = {false};
        final TextView txt = new TextView(act);
        txt.setText("Descargando\u2026");
        final ProgressBar bar = new ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setIndeterminate(info.size <= 0);
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (20 * act.getResources().getDisplayMetrics().density);
        box.setPadding(p, p, p, p);
        box.addView(txt);
        box.addView(bar);
        final AlertDialog dlg = new AlertDialog.Builder(act)
                .setTitle("Actualizando")
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("Cancelar", (d, w) -> cancel[0] = true)
                .create();
        dlg.show();

        final int[] lastPct = {-1};
        new Thread(() -> {
            String err = null;
            try {
                install(act.getApplicationContext(), info, (done, total) -> {
                    if (total <= 0) return;
                    final int pct = (int) (done * 100 / total);
                    if (pct == lastPct[0]) return;
                    lastPct[0] = pct;
                    UI.post(() -> { bar.setProgress(pct); txt.setText("Descargando\u2026 " + pct + "%"); });
                }, cancel);
            } catch (Exception e) {
                err = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            final String fe = err;
            UI.post(() -> {
                busy = false;
                try { dlg.dismiss(); } catch (Exception ignored) { }
                if (fe != null && !cancel[0]) {
                    Toast.makeText(act, "No se pudo actualizar: " + fe, Toast.LENGTH_LONG).show();
                }
            });
        }, "updater-download").start();
    }

    /** Descarga el APK directo a una sesi\u00f3n del instalador de Android y la confirma. */
    private static void install(Context ctx, Info info, Progress progress, boolean[] cancel) throws Exception {
        PackageInstaller pi = ctx.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams sp = new PackageInstaller.SessionParams(
                PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        sp.setAppPackageName(ctx.getPackageName());
        if (info.size > 0) sp.setSize(info.size);
        if (Build.VERSION.SDK_INT >= 31) {
            // En Android 12+ puede actualizar sin pedir confirmaci\u00f3n si esta app instal\u00f3 la versi\u00f3n anterior.
            sp.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
        }
        int id = pi.createSession(sp);
        PackageInstaller.Session s = pi.openSession(id);
        boolean committed = false;
        HttpURLConnection c = null;
        try {
            int code;
            boolean viaTunnel = tunnelUp();
            while (true) {
                c = open(info.url, viaTunnel);
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setRequestProperty("User-Agent", "Conecta-Updater");
                try {
                    code = c.getResponseCode();
                    break;
                } catch (java.io.IOException e) {
                    c.disconnect();
                    if (!viaTunnel) throw e;
                    TunnelService.appendLog("Actualizador: por el t\u00fanel no se pudo descargar (" + e + "); se prueba directo");
                    viaTunnel = false;   // un segundo intento, directo
                }
            }
            if (code != 200) throw new Exception("HTTP " + code);
            long total = info.size > 0 ? info.size : c.getContentLengthLong();
            try (InputStream in = c.getInputStream();
                 OutputStream out = s.openWrite("update.apk", 0, total > 0 ? total : -1)) {
                byte[] buf = new byte[65536];
                long done = 0;
                int n;
                while ((n = in.read(buf)) != -1) {
                    if (cancel[0]) throw new Exception("cancelado");
                    out.write(buf, 0, n);
                    done += n;
                    progress.on(done, total);
                }
                s.fsync(out);
            }
            registerResult(ctx);
            Intent result = new Intent(ctx.getPackageName() + ".UPDATE_RESULT").setPackage(ctx.getPackageName());
            PendingIntent pend = PendingIntent.getBroadcast(ctx, id, result,
                    PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0));
            s.commit(pend.getIntentSender());
            committed = true;
        } finally {
            if (c != null) c.disconnect();
            s.close();
            if (!committed) {
                try { pi.abandonSession(id); } catch (Exception ignored) { }
            }
        }
    }

    /** Recibe el resultado del instalador: abre la confirmaci\u00f3n de Android o avisa si fall\u00f3. */
    private static void registerResult(Context ctx) {
        if (receiver != null) {
            try { ctx.unregisterReceiver(receiver); } catch (Exception ignored) { }
        }
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                int st = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
                if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                    Intent confirm = i.getParcelableExtra(Intent.EXTRA_INTENT);
                    if (confirm != null) {
                        confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        c.startActivity(confirm);
                    }
                } else if (st != PackageInstaller.STATUS_SUCCESS) {
                    String m = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
                    Toast.makeText(c, "Actualizaci\u00f3n fallida" + (m == null ? "" : ": " + m), Toast.LENGTH_LONG).show();
                }
            }
        };
        IntentFilter f = new IntentFilter(ctx.getPackageName() + ".UPDATE_RESULT");
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
        else ctx.registerReceiver(receiver, f);
    }
}
