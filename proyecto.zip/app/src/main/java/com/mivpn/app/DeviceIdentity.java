package com.mivpn.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.util.Base64;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

/**
 * Identidad del dispositivo: una llave EC P-256 que se genera una sola vez y se guarda en el
 * almacenamiento privado de la app. El HWID es su huella. Al reinstalar la app se genera otra
 * (nuevo HWID) y hay que volver a autorizarla en el VPS.
 */
public final class DeviceIdentity {
    private static final String PREFS = "identity";
    private static KeyPair cached;

    private DeviceIdentity() {}

    public static synchronized KeyPair keyPair(Context ctx) throws Exception {
        if (cached != null) return cached;
        SharedPreferences sp = ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String priv = sp.getString("priv", null);
        String pub = sp.getString("pub", null);
        if (priv != null && pub != null) {
            try {
                KeyFactory kf = KeyFactory.getInstance("EC");
                cached = new KeyPair(
                        kf.generatePublic(new X509EncodedKeySpec(Base64.decode(pub, Base64.NO_WRAP))),
                        kf.generatePrivate(new PKCS8EncodedKeySpec(Base64.decode(priv, Base64.NO_WRAP))));
                return cached;
            } catch (Exception ignored) {
                // llave dañada: se genera una nueva
            }
        }
        KeyPairGenerator g = KeyPairGenerator.getInstance("EC");
        g.initialize(new ECGenParameterSpec("secp256r1"));
        KeyPair kp = g.generateKeyPair();
        sp.edit()
                .putString("priv", Base64.encodeToString(kp.getPrivate().getEncoded(), Base64.NO_WRAP))
                .putString("pub", Base64.encodeToString(kp.getPublic().getEncoded(), Base64.NO_WRAP))
                .apply();
        cached = kp;
        return kp;
    }

    /**
     * HWID "estilo Rufu": "hw" + ANDROID_ID. En el VPS es un usuario Linux cuyo nombre y
     * contraseña son ese mismo texto. Devuelve null si Android no entrega el ID.
     */
    public static String rufuHwid(Context ctx) {
        String id = Settings.Secure.getString(ctx.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (id == null || id.trim().isEmpty()) return null;
        return "hw" + id.trim();
    }

    public static String hwid(Context ctx) throws Exception {
        return SshKeyFormat.hwid((ECPublicKey) keyPair(ctx).getPublic());
    }

    public static String publicLine(Context ctx) throws Exception {
        return SshKeyFormat.publicLine((ECPublicKey) keyPair(ctx).getPublic());
    }
}
