package com.mivpn.app;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Cifrado de perfiles con contraseña: PBKDF2-HMAC-SHA256 (150 000 vueltas) + AES-256-GCM.
 * Formato del archivo: "CONECTA1:" + Base64( sal[16] + iv[12] + cifrado+etiqueta ).
 * GCM detecta contraseña incorrecta y archivos alterados.
 */
public final class ProfileCrypto {
    public static final String PREFIX = "CONECTA1:";
    private static final int ITER = 150_000;
    private static final byte[] AAD = "CONECTA1".getBytes(StandardCharsets.US_ASCII);

    private ProfileCrypto() {}

    public static boolean looksEncrypted(String text) {
        return text != null && text.trim().startsWith(PREFIX);
    }

    public static String encrypt(String plain, char[] password) throws GeneralSecurityException {
        SecureRandom rnd = new SecureRandom();
        byte[] salt = new byte[16];
        byte[] iv = new byte[12];
        rnd.nextBytes(salt);
        rnd.nextBytes(iv);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key(password, salt), new GCMParameterSpec(128, iv));
        c.updateAAD(AAD);
        byte[] ct = c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        byte[] all = new byte[16 + 12 + ct.length];
        System.arraycopy(salt, 0, all, 0, 16);
        System.arraycopy(iv, 0, all, 16, 12);
        System.arraycopy(ct, 0, all, 28, ct.length);
        return PREFIX + Base64.getEncoder().encodeToString(all);
    }

    /** Lanza GeneralSecurityException si la contraseña es incorrecta o el archivo está dañado. */
    public static String decrypt(String text, char[] password) throws GeneralSecurityException {
        if (!looksEncrypted(text)) throw new GeneralSecurityException("No es un archivo cifrado de Conecta");
        byte[] all;
        try {
            all = Base64.getDecoder().decode(text.trim().substring(PREFIX.length()));
        } catch (IllegalArgumentException e) {
            throw new GeneralSecurityException("Archivo dañado");
        }
        if (all.length < 16 + 12 + 16) throw new GeneralSecurityException("Archivo dañado");
        byte[] salt = new byte[16];
        byte[] iv = new byte[12];
        System.arraycopy(all, 0, salt, 0, 16);
        System.arraycopy(all, 16, iv, 0, 12);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key(password, salt), new GCMParameterSpec(128, iv));
        c.updateAAD(AAD);
        byte[] pt = c.doFinal(all, 28, all.length - 28);
        return new String(pt, StandardCharsets.UTF_8);
    }

    private static SecretKeySpec key(char[] password, byte[] salt) throws GeneralSecurityException {
        PBEKeySpec spec = new PBEKeySpec(password, salt, ITER, 256);
        try {
            byte[] k = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return new SecretKeySpec(k, "AES");
        } finally {
            spec.clearPassword();
        }
    }
}
