package com.mivpn.app;

import android.app.Application;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;

/** Guarda el error que cierre la app para mostrarlo la próxima vez que se abra. */
public class App extends Application {
    private static final String FILE = "crash.txt";

    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    String txt = "Hilo: " + t.getName() + "\n" + sw;
                    try (FileOutputStream fo = new FileOutputStream(new File(getFilesDir(), FILE))) {
                        fo.write(txt.getBytes(StandardCharsets.UTF_8));
                    }
                } catch (Throwable ignored) { }
                if (prev != null) prev.uncaughtException(t, e);
            }
        });
    }

    /** Devuelve el último error guardado (y lo borra), o null. */
    public static String takeCrash(android.content.Context c) {
        try {
            File f = new File(c.getFilesDir(), FILE);
            if (!f.exists()) return null;
            byte[] b = new byte[(int) Math.min(f.length(), 6000)];
            try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                int n = in.read(b);
                f.delete();
                return new String(b, 0, Math.max(n, 0), StandardCharsets.UTF_8);
            }
        } catch (Throwable t) {
            return null;
        }
    }
}
