package com.mivpn.app.bhttp;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.security.MessageDigest;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collections;
import javax.net.ssl.SNIHostName;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

public final class BhttpBridge implements AutoCloseable {
    private static final int BATCH_COUNT = 8;
    private static final int CALIBRATION_TIMEOUT_MS = 3000;
    private static final int DEFAULT_DOWNLOAD_SLOTS = 32;
    private static final int DEFAULT_UPLOAD_SLOTS = 16;
    private static final long EMPTY_BATCH_DELAY_MS = 750;
    private static final int MIN_PROBE_CHUNK_SIZE = 10;
    private static final int MODE_PROBE = 0;
    private static final int MODE_UPLOAD = 1;
    private static final int MODE_DOWNLOAD = 2;
    private static final int MODE_BATCH = 3;
    private static final int MODE_ACK = 4;
    private static final int REFERENCE_DOWNLOAD_CHUNK_SIZE = 1399;
    private static final int REFERENCE_UPLOAD_CHUNK_SIZE = 32768;
    private static final int STATUS_OK = 0;
    private static final int STATUS_DATA = 2;
    private static final long UPLOAD_CALIBRATION_COOLDOWN_MS = 750;
    private static final long UPLOAD_COALESCE_MS = 5;

    private static final int[] CHUNK_FALLBACK_STEPS = {1024, 768, 512, 256, 128, 64, 32, 16, 10};
    private static final int[] UPLOAD_CALIBRATION_STEPS = {4096, 8192, 12288, 16384, 20480, 24576, 32768};
    private static final int[] UPLOAD_LOW_FALLBACK_STEPS = {2048, 1024, 512, 256, 128, 64, 32, 16, 10};

    private final String host;
    private final int port;
    private final Listener listener;
    private final SocketProtector protector;
    private final int uploadConnections;
    private final int downloadConnections;
    private final long windowStride;
    private final long[] windowBases;
    private final byte[] sid = new byte[16];

    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicBoolean protectWarningLogged = new AtomicBoolean(false);
    private final AtomicReference<Throwable> terminalError = new AtomicReference<>();
    private final List<Socket> requestSockets = Collections.synchronizedList(new ArrayList<>());

    // ---- reutilizacion de conexiones (solo si el servidor la soporta: se detecta al arrancar) ----
    private static final long IDLE_MAX_MS = 8000L;      // una conexion ociosa mas de esto se descarta (el servidor aguanta 30 s)
    private static final int IDLE_MAX_COUNT = 64;
    private volatile boolean reuse = false;
    private final java.util.concurrent.ConcurrentLinkedDeque<IdleSocket> idleSockets = new java.util.concurrent.ConcurrentLinkedDeque<>();

    private static final class IdleSocket {
        final Socket socket;
        final long since;
        IdleSocket(Socket socket) { this.socket = socket; this.since = System.nanoTime(); }
    }
    private final List<Thread> threads = Collections.synchronizedList(new ArrayList<>());
    private final Object downstreamLock = new Object();
    private final Object downloadWakeup = new Object();
    private final Map<Long, byte[]> pending = new HashMap<>();
    private final BlockingQueue<UploadFrame> uploadQueue;
    private final AtomicLong uploadedBytes = new AtomicLong();

    private int downloadChunkSize = REFERENCE_DOWNLOAD_CHUNK_SIZE;
    private int uploadChunkSize = REFERENCE_UPLOAD_CHUNK_SIZE;
    private volatile long downloadedBytes;
    private volatile long lastUploadNanos;
    private long nextRead;
    private long nextAck = 186L;

    private ServerSocket localListener;
    private Socket localSocket;

    public interface Listener {
        void fatal(Throwable th);
        void log(String str);
    }

    public interface SocketProtector {
        boolean protect(Socket socket);
    }

    public BhttpBridge(String host, int port, Listener listener, SocketProtector socketProtector) {
        this(host, port, listener, socketProtector, DEFAULT_UPLOAD_SLOTS, DEFAULT_DOWNLOAD_SLOTS);
    }

    public BhttpBridge(String host, int port, Listener listener, SocketProtector socketProtector, int uploadSlots, int downloadSlots) {
        this.host = host;
        this.port = port;
        this.listener = listener;
        this.protector = socketProtector;
        this.uploadConnections = clamp(uploadSlots, 1, 16);
        this.downloadConnections = clamp(downloadSlots, 1, 32);
        this.windowStride = (long) this.downloadConnections * BATCH_COUNT;
        this.windowBases = new long[this.downloadConnections];

        for (int i = 0; i < this.windowBases.length; i++) {
            this.windowBases[i] = (long) i * BATCH_COUNT;
        }
        this.uploadQueue = new ArrayBlockingQueue<>(this.uploadConnections * 2);
        new SecureRandom().nextBytes(this.sid);
    }

    public int start() throws Exception {
        if (!this.running.compareAndSet(false, true)) {
            throw new IllegalStateException("BHTTP bridge already started");
        }
        try {
            log("BHTTP SID " + hex(this.sid, 0, 4));
            probe(MODE_PROBE, 0);
            probe(MODE_UPLOAD, 10);
            this.downloadChunkSize = calibrateChunkSize();
            this.uploadChunkSize = calibrateUploadChunkSize();
            probe(MODE_BATCH, 8);
            probe(MODE_ACK, 1);
            log("Probe BHP1: todos los modos aceptados");
            log("Perfil funcional 1.0.11 invertido: downloadConns=" + this.downloadConnections
                    + ", uploadConns=" + this.uploadConnections
                    + ", batch=8, download=" + this.downloadChunkSize
                    + ", upload=" + this.uploadChunkSize
                    + " fijos, stride=" + this.windowStride);
            detectReuse();
            registerSession();
            log("Registro BHTTP seq=0 aceptado");

            this.localListener = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"));
            startThread(new Thread(this::acceptLocalSsh, "BHTTP-local-accept"));
            return this.localListener.getLocalPort();
        } catch (Throwable th) {
            this.running.set(false);
            closeQuietly();
            if (th instanceof Exception) {
                throw (Exception) th;
            }
            throw new IOException(th);
        }
    }

    private void acceptLocalSsh() {
        try {
            this.localSocket = this.localListener.accept();
            this.localSocket.setTcpNoDelay(true);
            log("SSH conectado al bridge local");

            startThread(new Thread(this::uploadReadLoop, "BHTTP-upload-reader"));
            for (int i = 0; i < this.uploadConnections; i++) {
                startThread(new Thread(this::uploadWorkerLoop, "BHTTP-upload-" + i));
            }
            for (long base : this.windowBases) {
                final long windowBase = base;
                startThread(new Thread(() -> downloadLoop(windowBase), "BHTTP-download-" + windowBase));
            }
        } catch (Throwable th) {
            fail(th);
        }
    }

    private void probe(int mode, int param) throws Exception {
        probe(mode, param, 15000);
    }

    /** Comprueba si el servidor atiende varias peticiones por la misma conexion; si no, todo sigue como antes. */
    private void detectReuse() {
        this.reuse = false;
        Socket socket = null;
        try {
            socket = openRequestSocket(8000);
            byte[] payload = crypt(makeProbePayload(MODE_BATCH, 8), MODE_PROBE, 0L, false);
            for (int i = 0; i < 2; i++) {               // dos sondeos seguidos por la MISMA conexion
                sendRequest(socket, MODE_PROBE, 0L, payload);
                Response resp = readResponse(socket);
                if (resp.status != STATUS_OK) throw new IOException("status " + resp.status);
                validateProbeResponse(crypt(resp.body, MODE_PROBE, 0L, true), MODE_BATCH, 8);
            }
            this.reuse = true;
            releaseRequestSocket(socket);
            socket = null;
            log("Reutilizacion de conexiones: SI");
        } catch (Exception e) {
            log("Reutilizacion de conexiones: NO (" + concise(e) + ")");
        } finally {
            closeRequestSocket(socket);
        }
    }

    private void probe(int mode, int param, int timeoutMs) throws Exception {
        byte[] payload = crypt(makeProbePayload(mode, param), MODE_PROBE, 0L, false);
        Socket socket = openRequestSocket(timeoutMs);
        try {
            sendRequest(socket, MODE_PROBE, 0L, payload);
            Response resp = readResponse(socket);
            if (resp.status != STATUS_OK) {
                throw new IOException("BHP1 mode " + mode + " status " + resp.status);
            }
            validateProbeResponse(crypt(resp.body, MODE_PROBE, 0L, true), mode, param);
            releaseRequestSocket(socket);
            socket = null;
        } finally {
            closeRequestSocket(socket);
        }
    }

    private static byte[] makeProbePayload(int mode, int param) {
        int length = mode == MODE_UPLOAD ? Math.max(MIN_PROBE_CHUNK_SIZE, param) : MIN_PROBE_CHUNK_SIZE;
        byte[] buf = new byte[length];
        buf[0] = 66; // 'B'
        buf[1] = 72; // 'H'
        buf[2] = 80; // 'P'
        buf[3] = 49; // '1'
        buf[4] = 1;  // Version
        buf[5] = (byte) mode;
        putInt(buf, 6, param);
        for (int i = 10; i < length; i++) {
            buf[i] = (byte) ((i * 31) & 0xFF);
        }
        return buf;
    }

    private static void validateProbeResponse(byte[] buf, int mode, int param) throws IOException {
        int expectedLen = mode == MODE_DOWNLOAD ? Math.max(MIN_PROBE_CHUNK_SIZE, param) : MIN_PROBE_CHUNK_SIZE;
        if (buf.length != expectedLen || buf[0] != 66 || buf[1] != 72 || buf[2] != 80 || buf[3] != 49 || buf[4] != 1 ||
                (buf[5] & 0xFF) != mode || getInt(buf, 6) != param) {
            throw new IOException("Respuesta BHP1 inválida en modo " + mode + ": tamaño=" + buf.length + ", esperado=" + expectedLen);
        }
        for (int i = 10; i < buf.length; i++) {
            if (buf[i] != (byte) ((i * 31) & 0xFF)) {
                throw new IOException("Respuesta BHP1 corrupta en el byte " + i);
            }
        }
    }

    private int calibrateChunkSize() throws Exception {
        log("Calibrando envelope batch=8 del perfil 1.0.5 (chunk máximo 1399)...");
        int upper = REFERENCE_DOWNLOAD_CHUNK_SIZE;
        if (acceptsChunkSize(REFERENCE_DOWNLOAD_CHUNK_SIZE)) {
            log("Calibración BHTTP: envelope completo aceptado; chunk fijado en 1399 bytes");
            return REFERENCE_DOWNLOAD_CHUNK_SIZE;
        }

        int found = -1;
        for (int step : CHUNK_FALLBACK_STEPS) {
            if (acceptsChunkSize(step)) {
                found = step;
                break;
            }
            upper = step;
        }
        if (found < 0) {
            throw new IOException("Calibración BHTTP falló hasta 10 bytes");
        }

        int low = found;
        int high = upper - 1;
        while (low < high) {
            int mid = low + (((high - low) + 1) >>> 1);
            if (acceptsChunkSize(mid)) {
                low = mid;
            } else {
                high = mid - 1;
            }
        }
        log("Calibración BHTTP: envelope limitado; chunk fijado en " + low
                + " bytes en esta sesión (máximo 1.0.5=1399)");
        return low;
    }

    private int calibrateUploadChunkSize() throws Exception {
        log("Calibrando upload BHTTP con " + this.uploadConnections + " conexiones concurrentes...");
        int lastAccepted = -1;
        for (int step : UPLOAD_CALIBRATION_STEPS) {
            if (!acceptsUploadChunkSize(step)) {
                if (lastAccepted < 0) {
                    lastAccepted = findLowUploadFallback();
                }
                sleep(UPLOAD_CALIBRATION_COOLDOWN_MS);
                log("Calibración upload: rango " + step + " inestable; margen operacional fijado en "
                        + lastAccepted + " bytes con " + this.uploadConnections + " conexiones");
                return lastAccepted;
            }
            lastAccepted = step;
        }
        log("Calibración upload: perfil máximo 32768 bytes aceptado con "
                + this.uploadConnections + " conexiones");
        return REFERENCE_UPLOAD_CHUNK_SIZE;
    }

    private int findLowUploadFallback() throws Exception {
        for (int step : UPLOAD_LOW_FALLBACK_STEPS) {
            if (acceptsUploadChunkSize(step)) {
                return step;
            }
        }
        throw new IOException("Calibración de upload falló hasta 10 bytes");
    }

    private boolean acceptsChunkSize(int size) throws Exception {
        return acceptsStableProbe(MODE_DOWNLOAD, batchEnvelopeProbeParameter(size), "download", size);
    }

    private boolean acceptsUploadChunkSize(int size) throws Exception {
        IOException lastError = null;
        for (int round = 1; round <= 2; round++) {
            try {
                runConcurrentUploadProbeRound(size);
                if (round == 2) {
                    log("Calibración upload=" + size + " recuperada en la segunda ronda concurrente");
                }
                return true;
            } catch (IOException e) {
                lastError = e;
                if (round == 1) {
                    sleep(100L);
                }
            }
        }
        log("Calibración upload=" + size + " rechazada en 2 rondas: " + concise(lastError));
        return false;
    }

    private void runConcurrentUploadProbeRound(int size) throws IOException {
        CountDownLatch startSignal = new CountDownLatch(this.uploadConnections);
        CountDownLatch runSignal = new CountDownLatch(1);
        CountDownLatch doneSignal = new CountDownLatch(this.uploadConnections);
        AtomicReference<Throwable> errorRef = new AtomicReference<>();

        for (int i = 0; i < this.uploadConnections; i++) {
            Thread thread = new Thread(() -> {
                startSignal.countDown();
                try {
                    runSignal.await();
                    probe(MODE_UPLOAD, size, CALIBRATION_TIMEOUT_MS);
                } catch (Throwable th) {
                    errorRef.compareAndSet(null, th);
                } finally {
                    doneSignal.countDown();
                }
            }, "BHTTP-upload-calibration-" + i);
            thread.setDaemon(true);
            thread.start();
        }

        try {
            if (!startSignal.await(5L, TimeUnit.SECONDS)) {
                throw new IOException("los hilos de calibración no iniciaron");
            }
            runSignal.countDown();
            if (!doneSignal.await(12L, TimeUnit.SECONDS)) {
                throw new IOException("tiempo de espera agotado en la ronda concurrente de upload");
            }
            Throwable err = errorRef.get();
            if (err != null) {
                if (err instanceof IOException) {
                    throw (IOException) err;
                }
                throw new IOException(err);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("calibración de upload interrumpida", e);
        }
    }

    private boolean acceptsStableProbe(int mode, int param, String label, int value) throws Exception {
        IOException lastError = null;
        int successCount = 0;
        int failureCount = 0;
        for (int attempt = 1; attempt <= 3; attempt++) {
            try {
                probe(mode, param, CALIBRATION_TIMEOUT_MS);
                successCount++;
                if (successCount == 2) {
                    if (attempt > 2) {
                        log("Calibración " + label + "=" + value
                                + " recuperada y confirmada después de falla transitoria");
                    }
                    return true;
                }
            } catch (IOException e) {
                lastError = e;
                failureCount++;
                if (failureCount == 2) {
                    log("Calibración " + label + "=" + value + " rechazada 2x: " + concise(lastError));
                    return false;
                }
            }
            sleep(100L);
        }
        log("Calibración " + label + "=" + value + " inestable: " + concise(lastError));
        return false;
    }

    private static int batchEnvelopeProbeParameter(int chunkSize) {
        return (int) Math.max(10L, ((long) (chunkSize + 9) * BATCH_COUNT) - UPLOAD_COALESCE_MS);
    }

    private void registerSession() throws Exception {
        Socket socket = openRequestSocket();
        try {
            sendRequest(socket, MODE_UPLOAD, 0L, new byte[0]);
            Response resp = readResponse(socket);
            if (resp.status != STATUS_OK) {
                throw new IOException("Registro BHTTP rechazado: " + resp.status);
            }
            releaseRequestSocket(socket);
            socket = null;
        } finally {
            closeRequestSocket(socket);
        }
    }

    private void uploadReadLoop() {
        int maxChunk = this.uploadChunkSize;
        byte[] buffer = new byte[maxChunk];
        try {
            BufferedInputStream in = new BufferedInputStream(this.localSocket.getInputStream());
            long sequence = 0;
            int read;
            while (this.running.get() && (read = in.read(buffer)) >= 0) {
                if (read > 0) {
                    sleep(UPLOAD_COALESCE_MS);
                    while (read < maxChunk && in.available() > 0) {
                        int extra = in.read(buffer, read, maxChunk - read);
                        if (extra <= 0) break;
                        read += extra;
                    }
                    byte[] rawData = new byte[read];
                    System.arraycopy(buffer, 0, rawData, 0, read);
                    byte[] encrypted = crypt(rawData, MODE_UPLOAD, sequence, false);
                    this.uploadQueue.put(new UploadFrame(sequence, read, encrypted));
                    sequence++;
                }
            }
        } catch (Throwable th) {
            fail(th);
        }
    }

    private void uploadWorkerLoop() {
        while (this.running.get()) {
            try {
                UploadFrame frame = this.uploadQueue.take();
                int retries = 0;
                while (this.running.get()) {
                    try {
                        uploadFrame(frame.sequence, frame.encrypted);
                        break;
                    } catch (IOException e) {
                        if (!this.running.get()) return;
                        retries++;
                        if (retries > 10) throw e;
                        log("Retry upload seq=" + frame.sequence + " bytes=" + frame.clearLength + " intento=" + retries + " error=" + concise(e));
                        sleep((long) retries * 250L);
                    }
                }
                this.uploadedBytes.addAndGet(frame.clearLength);
                this.lastUploadNanos = System.nanoTime();
                synchronized (this.downloadWakeup) {
                    this.downloadWakeup.notifyAll();
                }
            } catch (InterruptedException unused) {
                Thread.currentThread().interrupt();
                return;
            } catch (Throwable th) {
                fail(th);
                return;
            }
        }
    }

    private void uploadFrame(long sequence, byte[] data) throws Exception {
        Socket socket = openRequestSocket();
        try {
            sendRequest(socket, MODE_UPLOAD, sequence, data);
            Response resp = readResponse(socket);
            if (resp.status != STATUS_OK) {
                throw new IOException("Upload seq=" + sequence + " status=" + resp.status);
            }
            releaseRequestSocket(socket);
            socket = null;
        } finally {
            closeRequestSocket(socket);
        }
    }

    private void downloadLoop(long sequence) {
        int emptyCount = 0;
        int retries = 0;
        while (this.running.get()) {
            try {
                boolean hasData = downloadBatch(sequence);
                sequence += this.windowStride;
                if (hasData) {
                    emptyCount = 0;
                } else {
                    emptyCount++;
                    boolean recentUpload = (System.nanoTime() - this.lastUploadNanos) < 2_000_000_000L;
                    long waitMs = Math.min(EMPTY_BATCH_DELAY_MS, 25L << Math.min(emptyCount, 5));
                    if (recentUpload) {
                        waitMs = Math.min(50L, waitMs);
                    }
                    waitForDownload(waitMs);
                }
                retries = 0;
            } catch (Throwable th) {
                if (!this.running.get()) {
                    return;
                }
                retries++;
                log("Retry batch seq=" + sequence + " intento=" + retries + " error=" + concise(th));
                if (retries > 10) {
                    fail(th);
                    return;
                }
                sleep(Math.min(2000L, (long) retries * 200L));
            }
        }
    }

    private boolean downloadBatch(long sequence) throws Exception {
        byte[] requestBody = new byte[6];
        putInt(requestBody, 0, this.downloadChunkSize);
        requestBody[4] = 0;
        requestBody[5] = (byte) BATCH_COUNT;

        byte[] encryptedRequest = crypt(requestBody, MODE_BATCH, sequence, false);
        List<Long> acksToSend = new ArrayList<>();
        Socket socket = openRequestSocket();
        try {
            sendRequest(socket, MODE_BATCH, sequence, encryptedRequest);
            DataInputStream in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            byte[][] decryptedChunks = new byte[BATCH_COUNT][];
            boolean hasData = false;

            for (int i = 0; i < BATCH_COUNT; i++) {
                Response resp = readResponse(in);
                if (resp.status != STATUS_DATA || resp.body.length < 4) {
                    throw new IOException("Batch seq=" + (sequence + i) + " status=" + resp.status);
                }
                int dataLen = getInt(resp.body, 0);
                if (dataLen < 0 || dataLen != resp.body.length - 4) {
                    throw new IOException("Longitud DATA inválida: " + dataLen);
                }
                if (dataLen == 0) {
                    decryptedChunks[i] = new byte[0];
                } else {
                    byte[] enc = new byte[dataLen];
                    System.arraycopy(resp.body, 4, enc, 0, dataLen);
                    decryptedChunks[i] = crypt(enc, MODE_BATCH, sequence + i, true);
                    hasData = true;
                }
            }

            synchronized (this.downstreamLock) {
                for (int i = 0; i < BATCH_COUNT; i++) {
                    this.pending.put(sequence + i, decryptedChunks[i]);
                }
                OutputStream out = this.localSocket.getOutputStream();
                while (this.pending.containsKey(this.nextRead)) {
                    byte[] chunk = this.pending.remove(this.nextRead);
                    if (chunk != null && chunk.length > 0) {
                        out.write(chunk);
                        out.flush();
                        this.downloadedBytes += chunk.length;
                    }
                    this.nextRead++;
                }

                while ((this.nextRead - 1) >= this.nextAck) {
                    acksToSend.add(this.nextAck);
                    this.nextAck += 187L;
                }
            }

            releaseRequestSocket(socket);
            socket = null;

            for (Long ackSeq : acksToSend) {
                try {
                    acknowledge(ackSeq);
                } catch (Exception e) {
                    if (this.running.get()) {
                        log("ACK seq=" + ackSeq + " aplazado: " + concise(e));
                    }
                }
            }
            return hasData;
        } finally {
            closeRequestSocket(socket);
        }
    }

    private void acknowledge(long sequence) throws Exception {
        Socket socket = openRequestSocket();
        try {
            sendRequest(socket, MODE_ACK, sequence, new byte[0]);
            Response resp = readResponse(socket);
            if (resp.status != STATUS_OK) {
                throw new IOException("ACK seq=" + sequence + " status=" + resp.status);
            }
            releaseRequestSocket(socket);
            socket = null;
        } finally {
            closeRequestSocket(socket);
        }
    }

    private Socket openRequestSocket() throws IOException {
        return openRequestSocket(15000);
    }

    // ---- TLS opcional: la app manda el SNI que se le indique y puede fijar la huella del certificado ----
    private volatile String tlsSni;                 // null = sin TLS
    private volatile byte[] tlsPin;                 // null = no verificar el certificado
    private volatile SSLSocketFactory tlsFactory;

    /**
     * Activa TLS para las conexiones al servidor. Llamar antes de start().
     * @param sni dominio que se envia como SNI (no puede ser una IP)
     * @param pinHex huella SHA-256 del certificado del servidor (hex, con o sin ':'), o vacio para no verificar
     */
    public void setTls(String sni, String pinHex) {
        String name = sni == null ? "" : sni.trim();
        if (name.isEmpty() || name.matches("[0-9.]+") || name.contains(":")) {
            throw new IllegalArgumentException("El SNI debe ser un dominio (no una IP)");
        }
        byte[] pin = null;
        String hex = pinHex == null ? "" : pinHex.replace(":", "").replace(" ", "").toLowerCase();
        if (!hex.isEmpty()) {
            if (!hex.matches("[0-9a-f]{64}")) throw new IllegalArgumentException("La huella SHA-256 debe tener 64 caracteres hexadecimales");
            pin = new byte[32];
            for (int i = 0; i < 32; i++) pin[i] = (byte) Integer.parseInt(hex.substring(2 * i, 2 * i + 2), 16);
        }
        this.tlsPin = pin;
        this.tlsSni = name;
        this.tlsFactory = null;
    }

    private SSLSocketFactory tlsFactory() throws IOException {
        SSLSocketFactory f = tlsFactory;
        if (f != null) return f;
        synchronized (this) {
            if (tlsFactory != null) return tlsFactory;
            final byte[] pin = tlsPin;
            try {
                SSLContext ctx = SSLContext.getInstance("TLS");
                ctx.init(null, new TrustManager[]{new X509TrustManager() {
                    @Override public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                        throw new CertificateException("no se aceptan certificados de cliente");
                    }
                    @Override public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                        if (pin == null) return;                       // sin huella: se acepta (el SSH interno sigue autenticando)
                        if (chain == null || chain.length == 0) throw new CertificateException("el servidor no envio certificado");
                        try {
                            byte[] got = MessageDigest.getInstance("SHA-256").digest(chain[0].getEncoded());
                            if (!MessageDigest.isEqual(got, pin)) throw new CertificateException("La huella del certificado no coincide");
                        } catch (java.security.NoSuchAlgorithmException e) {
                            throw new CertificateException(e);
                        }
                    }
                    @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                }}, null);
                tlsFactory = ctx.getSocketFactory();
                return tlsFactory;
            } catch (java.security.GeneralSecurityException e) {
                throw new IOException("No se pudo preparar TLS: " + e.getMessage());
            }
        }
    }

    private Socket wrapTls(Socket plain, int timeoutMs) throws IOException {
        String name = tlsSni;
        SSLSocket s = (SSLSocket) tlsFactory().createSocket(plain, name, this.port, true);
        SSLParameters p = s.getSSLParameters();
        p.setServerNames(Collections.singletonList(new SNIHostName(name)));
        p.setEndpointIdentificationAlgorithm(null);      // no se compara el nombre: el SNI es solo el que se eligio
        s.setSSLParameters(p);
        s.setSoTimeout(timeoutMs);
        s.startHandshake();
        return s;
    }

    private Socket takeIdle(int timeoutMs) {
        IdleSocket it;
        while ((it = idleSockets.pollFirst()) != null) {
            boolean stale = (System.nanoTime() - it.since) / 1_000_000L > IDLE_MAX_MS;
            if (stale || it.socket.isClosed() || !it.socket.isConnected()) {
                closeRequestSocket(it.socket);
                continue;
            }
            try {
                it.socket.setSoTimeout(timeoutMs);
                return it.socket;
            } catch (IOException e) {
                closeRequestSocket(it.socket);
            }
        }
        return null;
    }

    /** Devuelve la conexion al pool si se puede reutilizar; si no, la cierra. Llamar solo tras leer la respuesta completa. */
    private void releaseRequestSocket(Socket socket) {
        if (socket == null) return;
        if (reuse && running.get() && idleSockets.size() < IDLE_MAX_COUNT && !socket.isClosed()) {
            idleSockets.addFirst(new IdleSocket(socket));
        } else {
            closeRequestSocket(socket);
        }
    }

    private Socket openRequestSocket(int timeoutMs) throws IOException {
        if (reuse) {
            Socket pooled = takeIdle(timeoutMs);
            if (pooled != null) return pooled;
        }
        Socket socket = new Socket();
        try {
            // Frontera crea el FD antes de protect(): bind(0) -> protect -> connect.
            socket.bind(new InetSocketAddress(0));
            if (this.protector != null) {
                boolean protectedOk = this.protector.protect(socket);
                if (!protectedOk && this.protectWarningLogged.compareAndSet(false, true)) {
                    log("Aviso: protect(socket) retornó false; continuando porque el paquete está excluido de la VPN");
                }
            }
            socket.setTcpNoDelay(true);
            socket.setKeepAlive(true);
            socket.connect(new InetSocketAddress(this.host, this.port), 8000);
            socket.setSoTimeout(timeoutMs);
            if (tlsSni != null) socket = wrapTls(socket, timeoutMs);
            this.requestSockets.add(socket);
            return socket;
        } catch (IOException | RuntimeException e) {
            try {
                socket.close();
            } catch (IOException ignored) {
            }
            throw e;
        }
    }

    private void closeRequestSocket(Socket socket) {
        if (socket != null) {
            this.requestSockets.remove(socket);
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }
    }

    private void sendRequest(Socket socket, int mode, long sequence, byte[] data) throws IOException {
        sendRequest(new DataOutputStream(new BufferedOutputStream(socket.getOutputStream())), mode, sequence, data);
    }

    private void sendRequest(DataOutputStream out, int mode, long sequence, byte[] data) throws IOException {
        out.writeByte(mode);
        out.write(this.sid);
        out.writeLong(sequence);
        out.writeInt(data.length);
        out.write(data);
        out.flush();
    }

    private Response readResponse(Socket socket) throws IOException {
        return readResponse(new DataInputStream(new BufferedInputStream(socket.getInputStream())));
    }

    private Response readResponse(DataInputStream in) throws IOException {
        try {
            int status = in.readUnsignedByte();
            int length = in.readInt();
            if (length < 0 || length > 2097152) { // 2MB max
                throw new IOException("Resposta BHTTP grande/inválida: " + length);
            }
            byte[] body = new byte[length];
            in.readFully(body);
            return new Response(status, body);
        } catch (EOFException e) {
            throw new IOException("Resposta BHTTP truncada", e);
        }
    }

    private byte[] crypt(byte[] input, int mode, long sequence, boolean isResponse) throws Exception {
        byte[] output = new byte[input.length];
        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");

        ByteBuffer state = ByteBuffer.allocate(30).order(ByteOrder.BIG_ENDIAN);
        state.put(this.sid);
        state.put((byte) mode);
        state.putLong(sequence);
        state.put((byte) (isResponse ? 1 : 0));

        int offset = 0;
        int blockIndex = 0;
        while (offset < input.length) {
            state.putInt(26, blockIndex);
            byte[] digest = sha256.digest(state.array());
            int blockSize = Math.min(32, input.length - offset);
            for (int i = 0; i < blockSize; i++) {
                output[offset + i] = (byte) (input[offset + i] ^ digest[i]);
            }
            offset += blockSize;
            blockIndex++;
        }
        return output;
    }

    private void startThread(Thread t) {
        t.setDaemon(true);
        this.threads.add(t);
        t.start();
    }

    private void fail(Throwable th) {
        if (this.running.get() && this.terminalError.compareAndSet(null, th)) {
            this.listener.fatal(th);
        }
    }

    public long getUploadedBytes() {
        return this.uploadedBytes.get();
    }

    public long getDownloadedBytes() {
        return this.downloadedBytes;
    }

    @Override
    public void close() {
        this.running.set(false);
        closeQuietly();
    }

    private void closeQuietly() {
        this.uploadQueue.clear();
        synchronized (this.downloadWakeup) {
            this.downloadWakeup.notifyAll();
        }
        if (this.localListener != null) {
            try {
                this.localListener.close();
            } catch (IOException ignored) {
            }
        }
        if (this.localSocket != null) {
            try {
                this.localSocket.close();
            } catch (IOException ignored) {
            }
        }
        this.idleSockets.clear();
        synchronized (this.requestSockets) {
            for (Socket s : new ArrayList<>(this.requestSockets)) {
                try {
                    s.close();
                } catch (IOException ignored) {
                }
            }
            this.requestSockets.clear();
        }
        synchronized (this.threads) {
            for (Thread t : this.threads) {
                t.interrupt();
            }
        }
    }

    private void log(String msg) {
        this.listener.log(msg);
    }

    private void waitForDownload(long ms) {
        synchronized (this.downloadWakeup) {
            if (this.running.get()) {
                try {
                    this.downloadWakeup.wait(ms);
                } catch (InterruptedException unused) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
    }

    private static String concise(Throwable th) {
        String msg = th.getMessage();
        return msg == null ? th.getClass().getSimpleName() : msg;
    }

    private static int getInt(byte[] b, int off) {
        return ((b[off] & 0xFF) << 24) |
               ((b[off + 1] & 0xFF) << 16) |
               ((b[off + 2] & 0xFF) << 8) |
               (b[off + 3] & 0xFF);
    }

    private static void putInt(byte[] b, int off, int val) {
        b[off] = (byte) (val >>> 24);
        b[off + 1] = (byte) (val >>> 16);
        b[off + 2] = (byte) (val >>> 8);
        b[off + 3] = (byte) val;
    }

    private static int clamp(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }

    private static String hex(byte[] data, int off, int len) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) {
            sb.append(String.format("%02x", data[off + i] & 0xFF));
        }
        return sb.toString();
    }

    public static final class Response {
        public final int status;
        public final byte[] body;

        public Response(int status, byte[] body) {
            this.status = status;
            this.body = body;
        }
    }

    public static final class UploadFrame {
        public final long sequence;
        public final int clearLength;
        public final byte[] encrypted;

        public UploadFrame(long sequence, int clearLength, byte[] encrypted) {
            this.sequence = sequence;
            this.clearLength = clearLength;
            this.encrypted = encrypted;
        }
    }
}
