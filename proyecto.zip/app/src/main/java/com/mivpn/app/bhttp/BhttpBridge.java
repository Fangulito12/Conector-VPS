package com.mivpn.app.bhttp;

import java.util.concurrent.ConcurrentLinkedDeque;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

public final class BhttpBridge implements AutoCloseable {
    private static final int BATCH_COUNT = 8;
    private static final int CALIBRATION_TIMEOUT_MS = 3000;
    /**
     * Tiempo máximo para recibir la respuesta de un sondeo de bajada. Una respuesta normal llega en menos de 1 s;
     * antes se esperaban 15 s, y mientras tanto esa ventana frenaba los datos siguientes (el corte se notaba
     * como una pausa de ~15 s). Con 6 s la ventana se reintenta en una conexión nueva mucho antes.
     */
    private static final int DOWNLOAD_READ_TIMEOUT_MS = 6000;
    private static final int DEFAULT_DOWNLOAD_SLOTS = 32;
    private static final int DEFAULT_UPLOAD_SLOTS = 16;
    private static final long EMPTY_BATCH_DELAY_MS = 750;
    private static final int MIN_PROBE_CHUNK_SIZE = 10;
    private static final int MODE_PROBE = 0;
    private static final int MODE_UPLOAD = 1;
    private static final int MODE_DOWNLOAD = 2;
    private static final int MODE_BATCH = 3;
    private static final int MODE_ACK = 4;
    private static final int REFERENCE_DOWNLOAD_CHUNK_SIZE = 1399;
    /** Tope del modo Manual: se intenta subir de 1399 hasta este valor, y el servidor decide cuánto acepta. */
    private static final int MAX_MANUAL_CHUNK_SIZE = 9000;
    private static final int REFERENCE_UPLOAD_CHUNK_SIZE = 9000;   // tope de subida: lo que acepta el VPS
    private static final int STATUS_OK = 0;
    private static final int STATUS_DATA = 2;
    private static final long UPLOAD_CALIBRATION_COOLDOWN_MS = 750;
    private static final long UPLOAD_COALESCE_MS = 5;

    private static final int[] CHUNK_FALLBACK_STEPS = {1024, 768, 512, 256, 128, 64, 32, 16, 10};
    private static final int[] UPLOAD_CALIBRATION_STEPS = {4096, 8192, 9000};
    private static final int[] UPLOAD_LOW_FALLBACK_STEPS = {2048, 1024, 512, 256, 128, 64, 32, 16, 10};

    private final String host;
    private final int port;
    private final Listener listener;
    private final SocketProtector protector;
    /** Si no es null, cada conexión al servidor se envuelve en TLS 1.2 con este SNI. */
    private volatile String tlsSni;
    /** Conexiones TLS ya establecidas y libres, para no repetir el handshake en cada petición. */
    /** Tiempo máximo que una conexión libre se reutiliza; se acorta solo si el servidor las cierra antes. */
    private volatile long poolMaxIdleNanos = 5_000_000_000L;
    /** El servidor (engine ...-keepalive, --max-requests-per-conn) admite varias peticiones por conexion: se reutiliza tambien sin TLS.
     *  Si el servidor cierra la conexion libre, el propio codigo lo detecta, reintenta y acorta o apaga la reutilizacion. */
    private static final boolean REUSE_PLAIN = true;
    private final ConcurrentLinkedDeque<Object[]> idlePool = new ConcurrentLinkedDeque<>();
    // Estadísticas para diagnosticar velocidad (se imprimen cada 10 s en el registro)
    private final java.util.concurrent.atomic.AtomicLong statConns = new java.util.concurrent.atomic.AtomicLong();
    private final java.util.concurrent.atomic.AtomicLong statConnNanos = new java.util.concurrent.atomic.AtomicLong();
    private final java.util.concurrent.atomic.AtomicLong statReused = new java.util.concurrent.atomic.AtomicLong();
    private final java.util.concurrent.atomic.AtomicLong statUpBytes = new java.util.concurrent.atomic.AtomicLong();
    /** Reutilizaciones fallidas seguidas: si el servidor cierra cada conexión al responder, se deja de reutilizar. */
    private final java.util.concurrent.atomic.AtomicInteger staleFails = new java.util.concurrent.atomic.AtomicInteger();
    /**
     * Máximo de conexiones nuevas en curso a la vez. Antes era fijo en 8, y eso anulaba las subidas y descargas
     * en paralelo: con 16 + 32 configuradas, solo 8 podían estar conectando al mismo tiempo (la versión 1.19 no
     * tenía ese tope). Ahora se ajusta a la cantidad de subidas + descargas elegidas.
     */
    private final java.util.concurrent.Semaphore connectGate;
    private final java.util.concurrent.atomic.AtomicLong statFails = new java.util.concurrent.atomic.AtomicLong();
    private final java.util.concurrent.atomic.AtomicLong statNetDrops = new java.util.concurrent.atomic.AtomicLong();    // caidas de la red del telefono (no culpa del servidor)
    private final java.util.concurrent.atomic.AtomicLong statResets = new java.util.concurrent.atomic.AtomicLong();       // errores DESPUES de conectar (Connection reset, etc.)
    private final java.util.concurrent.atomic.AtomicLong statDeepRetries = new java.util.concurrent.atomic.AtomicLong();  // reintentos seguidos (3 o mas) del mismo registro
    private final int uploadConnections;
    private final int downloadConnections;
    private long windowStride;
    /** Próxima secuencia de descarga sin pedir: cada conexión libre reclama la siguiente ventana disponible. */
    private final java.util.concurrent.atomic.AtomicLong nextDownloadClaim = new java.util.concurrent.atomic.AtomicLong();
    private final long[] windowBases;
    private final byte[] sid = new byte[16];

    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicBoolean protectWarningLogged = new AtomicBoolean(false);
    private final AtomicReference<Throwable> terminalError = new AtomicReference<>();
    private final List<Socket> requestSockets = Collections.synchronizedList(new ArrayList<>());
    private final List<Thread> threads = Collections.synchronizedList(new ArrayList<>());
    private final Object downstreamLock = new Object();
    private final Object downloadWakeup = new Object();
    private final Map<Long, byte[]> pending = new HashMap<>();
    private final BlockingQueue<UploadFrame> uploadQueue;
    private final AtomicLong uploadedBytes = new AtomicLong();

    // --- Auto+: ajuste en vivo de las conexiones activas (el maximo es uploadConnections / downloadConnections) ---
    private volatile boolean liveTune;
    private volatile int liveUp = 4, liveDown = 8;
    private long liveLastFails, liveLastResets, liveLastDeep, liveLastDrops;
    private int liveCalm;
    private long liveCooldownUntil, liveBadAt;
    private int liveBadUp, liveBadDown;
    private static final int LIVE_MIN_DOWN = 2;
    private static final int LIVE_MIN_UP = 2;

    private int downloadChunkSize = REFERENCE_DOWNLOAD_CHUNK_SIZE;
    /** Registros por pedido de descarga (8 por defecto; se puede cambiar en modo Manual). */
    private volatile int batchCount = BATCH_COUNT;
    /** Si es mayor que 0, tope manual del tamaño de registro (nunca supera lo que el servidor acepta). */
    private int chunkCap = 0;
    private int uploadChunkSize = REFERENCE_UPLOAD_CHUNK_SIZE;
    private volatile long downloadedBytes;
    private volatile long lastUploadNanos;
    private long nextRead;
    private long nextAck = 186L;

    private ServerSocket localListener;
    private Socket localSocket;

    public interface Listener {
        void fatal(Throwable th);
        void log(String str);
    }

    public interface SocketProtector {
        boolean protect(Socket socket);
    }

    public BhttpBridge(String host, int port, Listener listener, SocketProtector socketProtector) {
        this(host, port, listener, socketProtector, DEFAULT_UPLOAD_SLOTS, DEFAULT_DOWNLOAD_SLOTS);
    }

    public BhttpBridge(String host, int port, Listener listener, SocketProtector socketProtector, int uploadSlots, int downloadSlots) {
        this.host = host;
        this.port = port;
        this.listener = listener;
        this.protector = socketProtector;
        this.uploadConnections = clamp(uploadSlots, 1, 64);
        this.downloadConnections = clamp(downloadSlots, 1, 128);
        this.windowStride = (long) this.downloadConnections * BATCH_COUNT;
        this.windowBases = new long[this.downloadConnections];
        this.connectGate = new java.util.concurrent.Semaphore(Math.max(8, this.uploadConnections + this.downloadConnections));

        for (int i = 0; i < this.windowBases.length; i++) {
            this.windowBases[i] = (long) i * BATCH_COUNT;
        }
        this.uploadQueue = new ArrayBlockingQueue<>(this.uploadConnections * 2);
        new SecureRandom().nextBytes(this.sid);
    }

    /** Activa TLS 1.2 con SNI hacia el servidor. Llamar antes de start(). null o vacío = sin TLS. */
    public void setTlsSni(String sni) {
        this.tlsSni = (sni == null || sni.trim().isEmpty()) ? null : sni.trim();
    }

    /** Modo Manual: lote de descarga (1-32) y tope del tamaño de registro (64-9000, 0 = el calibrado). Llamar antes de start(). */
    public void setBatch(int batch, int chunkCap) {
        this.batchCount = clamp(batch, 1, 32);
        this.chunkCap = chunkCap <= 0 ? 0 : clamp(chunkCap, 64, MAX_MANUAL_CHUNK_SIZE);
        this.windowStride = (long) this.downloadConnections * this.batchCount;
        for (int i = 0; i < this.windowBases.length; i++) {
            this.windowBases[i] = (long) i * this.batchCount;
        }
    }

    /** Auto+: las conexiones configuradas pasan a ser el MAXIMO. Arranca con pocas y sube o baja segun los fallos. Llamar antes de start(). */
    public void setLiveTune() {
        this.liveTune = true;
        int minUp = Math.min(LIVE_MIN_UP, this.uploadConnections);
        int minDown = Math.min(LIVE_MIN_DOWN, this.downloadConnections);
        this.liveUp = clamp(4, minUp, this.uploadConnections);
        this.liveDown = clamp(8, minDown, this.downloadConnections);
        try {
            android.content.SharedPreferences sp = chunkPrefs;
            String v = sp == null ? null : sp.getString(liveKey(), null);
            if (v != null) {
                String[] a = v.split(",");
                // lo guardado solo puede SUBIR el arranque: un valor bajo de un mal momento no deja la conexion chica
                this.liveUp = clamp(Math.max(this.liveUp, Integer.parseInt(a[0])), minUp, this.uploadConnections);
                this.liveDown = clamp(Math.max(this.liveDown, Integer.parseInt(a[1])), minDown, this.downloadConnections);
            }
        } catch (Throwable ignored) { }
        log("Auto+: arranca con " + this.liveUp + " de subida / " + this.liveDown + " de bajada (máximo "
                + this.uploadConnections + " / " + this.downloadConnections + ")");
    }

    private String liveKey() {
        return "live:" + this.host + ":" + this.port;
    }

    private void saveLive() {
        try {
            android.content.SharedPreferences sp = chunkPrefs;
            if (sp != null) sp.edit().putString(liveKey(), this.liveUp + "," + this.liveDown).apply();
        } catch (Throwable ignored) { }
    }

    /** Conexiones simultaneas que usa la calibracion de subida (en Auto+ las de arranque, no el maximo). */
    private int calibUploadConns() {
        return this.liveTune ? Math.min(this.liveUp, this.uploadConnections) : this.uploadConnections;
    }

    /** Se llama cada 10 s: baja las conexiones si hay fallos o resets del servidor y las sube rapido si todo esta calmo y hay trafico. */
    private void liveAdjust(long failsNow, long resetsNow, long deepNow, long dropsNow, long downBytes, long upBytes) {
        long fails = failsNow - this.liveLastFails;
        long resets = resetsNow - this.liveLastResets;
        long deep = deepNow - this.liveLastDeep;
        long drops = dropsNow - this.liveLastDrops;
        this.liveLastFails = failsNow;
        this.liveLastResets = resetsNow;
        this.liveLastDeep = deepNow;
        this.liveLastDrops = dropsNow;
        long now = System.currentTimeMillis();
        int minUp = Math.min(LIVE_MIN_UP, this.uploadConnections);
        int minDown = Math.min(LIVE_MIN_DOWN, this.downloadConnections);
        if (drops > 0) {
            // se cayo la red del telefono (sin ruta, cambio de Wi-Fi/datos): no es culpa del servidor, no se toca nada
            this.liveCalm = 0;
            log("Auto+: la red del teléfono se cayó (" + drops + " errores); se mantienen las conexiones en "
                    + this.liveUp + " / " + this.liveDown);
            return;
        }
        // mal: no se pudo abrir conexiones, muchos resets, o un mismo registro reintentado 3+ veces seguidas
        if (fails >= 3 || resets >= 6 || deep >= 1) {
            this.liveBadUp = this.liveUp;
            this.liveBadDown = this.liveDown;
            this.liveBadAt = now;
            int nd = Math.max(minDown, this.liveDown * 3 / 4);
            int nu = Math.max(minUp, this.liveUp * 3 / 4);
            this.liveCalm = 0;
            this.liveCooldownUntil = now + 30_000L;
            if (nd != this.liveDown || nu != this.liveUp) {
                this.liveDown = nd;
                this.liveUp = nu;
                log("Auto+: " + fails + " fallos, " + resets + " resets y " + deep + " reintentos seguidos en 10 s; se bajan las conexiones a "
                        + nu + " de subida / " + nd + " de bajada");
            }
            return;
        }
        if (fails == 0 && resets <= 1 && deep == 0) this.liveCalm++; else this.liveCalm = 0;
        if (now >= this.liveCooldownUntil && this.liveCalm >= 2) {
            int capDown = this.downloadConnections;
            int capUp = this.uploadConnections;
            if (this.liveBadAt > 0 && now - this.liveBadAt < 300_000L) {
                // hace poco fallo con ese nivel: no vuelve a pasarlo durante 5 minutos
                capDown = Math.max(minDown, this.liveBadDown - 1);
                capUp = Math.max(minUp, this.liveBadUp - 1);
            }
            int nd = this.liveDown;
            int nu = this.liveUp;
            if (downBytes > 60_000L) nd = Math.min(capDown, this.liveDown + 2);
            if (upBytes > 20_000L) nu = Math.min(capUp, this.liveUp + 2);
            if (nd > this.liveDown || nu > this.liveUp) {
                this.liveDown = Math.max(nd, this.liveDown);
                this.liveUp = Math.max(nu, this.liveUp);
                this.liveCalm = 0;
                log("Auto+: todo estable; se suben las conexiones a " + this.liveUp + " de subida / " + this.liveDown + " de bajada");
            }
        }
        if (this.liveCalm >= 6) saveLive();   // un minuto estable: se recuerda para la proxima conexion
    }

    /** Errores de la red del propio telefono (sin ruta, cambio de Wi-Fi/datos): no son sobrecarga del servidor. */
    private static boolean isLocalNetError(Throwable t) {
        int depth = 0;
        for (Throwable c = t; c != null && depth < 6; c = c.getCause(), depth++) {
            String m = String.valueOf(c.getMessage());
            if (m.contains("ENETUNREACH") || m.contains("Network is unreachable") || m.contains("ENETDOWN")
                    || m.contains("ECONNABORTED") || m.contains("Software caused connection abort")) return true;
        }
        return false;
    }

    public int start() throws Exception {
        if (!this.running.compareAndSet(false, true)) {
            throw new IllegalStateException("BHTTP bridge already started");
        }
        try {
            log("BHTTP SID " + hex(this.sid, 0, 4));
            if (this.tlsSni == null && REUSE_PLAIN) log("Reutilización de conexiones sin TLS activada");
            probe(MODE_PROBE, 0);
            probe(MODE_UPLOAD, 10);
            this.downloadChunkSize = calibrateChunkSize();
            if (this.chunkCap > 0 && this.downloadChunkSize > this.chunkCap) {
                this.downloadChunkSize = this.chunkCap;
                log("Tamaño de registro limitado manualmente a " + this.chunkCap + " bytes");
            }
            this.uploadChunkSize = calibrateUploadChunkSize();
            probe(MODE_BATCH, 8);
            probe(MODE_ACK, 1);
            log("Probe BHP1: todos los modos aceptados");
            log("Perfil funcional 1.0.11 invertido: downloadConns=" + this.downloadConnections
                    + ", uploadConns=" + this.uploadConnections
                    + ", batch=" + this.batchCount + ", download=" + this.downloadChunkSize
                    + ", upload=" + this.uploadChunkSize
                    + " fijos, stride=" + this.windowStride);
            registerSession();
            log("Registro BHTTP seq=0 aceptado");

            this.localListener = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"));
            startThread(new Thread(this::acceptLocalSsh, "BHTTP-local-accept"));
            return this.localListener.getLocalPort();
        } catch (Throwable th) {
            this.running.set(false);
            closeQuietly();
            if (th instanceof Exception) {
                throw (Exception) th;
            }
            throw new IOException(th);
        }
    }

    private void acceptLocalSsh() {
        try {
            this.localSocket = this.localListener.accept();
            this.localSocket.setTcpNoDelay(true);
            log("SSH conectado al bridge local");

            startThread(new Thread(this::statsLoop, "BHTTP-stats"));
            startThread(new Thread(this::uploadReadLoop, "BHTTP-upload-reader"));
            for (int i = 0; i < this.uploadConnections; i++) {
                final int upIndex = i;
                startThread(new Thread(() -> uploadWorkerLoop(upIndex), "BHTTP-upload-" + i));
            }
            for (int i = 0; i < this.downloadConnections; i++) {
                final int loopIndex = i;
                startThread(new Thread(() -> downloadLoop(loopIndex), "BHTTP-download-" + i));
            }
        } catch (Throwable th) {
            fail(th);
        }
    }

    private void statsLoop() {
        long lastDown = this.downloadedBytes, lastUp = this.statUpBytes.get();
        long lastConns = 0, lastNanos = 0, lastReused = 0;
        this.liveLastFails = this.statFails.get();
        this.liveLastResets = this.statResets.get();
        this.liveLastDeep = this.statDeepRetries.get();
        this.liveLastDrops = this.statNetDrops.get();
        while (this.running.get()) {
            sleep(10000);
            if (!this.running.get()) return;
            long down = this.downloadedBytes, up = this.statUpBytes.get();
            long conns = this.statConns.get(), nanos = this.statConnNanos.get(), reused = this.statReused.get();
            long dc = conns - lastConns;
            long avgMs = dc > 0 ? (nanos - lastNanos) / dc / 1_000_000L : 0;
            log("Velocidad 10s: bajada " + ((down - lastDown) / 10240) + " KB/s, subida " + ((up - lastUp) / 10240)
                    + " KB/s | conexiones nuevas " + dc + " (media " + avgMs + " ms"
                    + (this.tlsSni != null ? " con TLS" : "") + "), reutilizadas con éxito " + (reused - lastReused)
                    + ", fallos de conexión acum. " + this.statFails.get()
                    + ", reintentos rápidos acum. " + this.statQuickRetries.get()
                    + ", resets acum. " + this.statResets.get()
                    + (this.liveTune ? ", Auto+ " + this.liveUp + "/" + this.liveDown : "")
                    );
            if (this.liveTune) liveAdjust(this.statFails.get(), this.statResets.get(), this.statDeepRetries.get(), this.statNetDrops.get(), down - lastDown, up - lastUp);
            lastDown = down; lastUp = up; lastConns = conns; lastNanos = nanos; lastReused = reused;
        }
    }

    private void probe(int mode, int param) throws Exception {
        probe(mode, param, 15000);
    }

    private void probe(int mode, int param, int timeoutMs) throws Exception {
        byte[] payload = crypt(makeProbePayload(mode, param), MODE_PROBE, 0L, false);
        Socket socket = openRequestSocket(timeoutMs);
        try {
            sendRequest(socket, MODE_PROBE, 0L, payload);
            Response resp = readResponse(socket);
            if (resp.status != STATUS_OK) {
                throw new IOException("BHP1 mode " + mode + " status " + resp.status);
            }
            validateProbeResponse(crypt(resp.body, MODE_PROBE, 0L, true), mode, param);
        } finally {
            closeRequestSocket(socket);
        }
    }

    private static byte[] makeProbePayload(int mode, int param) {
        int length = mode == MODE_UPLOAD ? Math.max(MIN_PROBE_CHUNK_SIZE, param) : MIN_PROBE_CHUNK_SIZE;
        byte[] buf = new byte[length];
        buf[0] = 66; // 'B'
        buf[1] = 72; // 'H'
        buf[2] = 80; // 'P'
        buf[3] = 49; // '1'
        buf[4] = 1;  // Version
        buf[5] = (byte) mode;
        putInt(buf, 6, param);
        for (int i = 10; i < length; i++) {
            buf[i] = (byte) ((i * 31) & 0xFF);
        }
        return buf;
    }

    private static void validateProbeResponse(byte[] buf, int mode, int param) throws IOException {
        int expectedLen = mode == MODE_DOWNLOAD ? Math.max(MIN_PROBE_CHUNK_SIZE, param) : MIN_PROBE_CHUNK_SIZE;
        if (buf.length != expectedLen || buf[0] != 66 || buf[1] != 72 || buf[2] != 80 || buf[3] != 49 || buf[4] != 1 ||
                (buf[5] & 0xFF) != mode || getInt(buf, 6) != param) {
            throw new IOException("Respuesta BHP1 inválida en modo " + mode + ": tamaño=" + buf.length + ", esperado=" + expectedLen);
        }
        for (int i = 10; i < buf.length; i++) {
            if (buf[i] != (byte) ((i * 31) & 0xFF)) {
                throw new IOException("Respuesta BHP1 corrupta en el byte " + i);
            }
        }
    }

    /**
     * Solo en Manual con un registro mayor a 1399: se le pregunta al servidor cuál es el mayor tamaño que acepta
     * (primero el valor pedido y, si no, se acota por mitades). Si no acepta nada mayor, se queda en 1399.
     */
    private int calibrateLargerChunkSize() throws Exception {
        int low = REFERENCE_DOWNLOAD_CHUNK_SIZE;
        int high = this.chunkCap;
        log("Calibrando registro mayor a 1399 (hasta " + high + " bytes)...");
        if (acceptsChunkSize(high)) {
            log("Calibración BHTTP: el servidor acepta registros de " + high + " bytes");
            return high;
        }
        high--;
        while (high - low > 256) {
            int mid = low + (((high - low) + 1) >>> 1);
            if (acceptsChunkSize(mid)) {
                low = mid;
            } else {
                high = mid - 1;
            }
        }
        if (low == REFERENCE_DOWNLOAD_CHUNK_SIZE) {
            log("Calibración BHTTP: el servidor no acepta registros mayores a 1399; se queda en 1399 bytes");
        } else {
            log("Calibración BHTTP: el servidor acepta registros de hasta " + low + " bytes");
        }
        return low;
    }

    // ---- Caché de la calibración de bajada ----
    // Buscar el tamaño máximo que acepta el servidor cuesta varios timeouts de 3 s (cada tamaño rechazado = 2 timeouts).
    // Ese límite es del servidor y no cambia entre conexiones, así que se guarda y en las siguientes conexiones
    // (reconexión por cambio de red, por lentitud, o al abrir la app) solo se confirma con un sondeo rápido.
    private static final int MAX_PENDING_CHUNKS = 4096;
    private static final long CHUNK_CACHE_LOW_TTL_MS = 20L * 60 * 1000;   // valores bajos: se recalibra pronto
    private static final long CHUNK_CACHE_TTL_MS = 12L * 60 * 60 * 1000;   // 12 h; después se vuelve a calibrar completo
    private static volatile android.content.SharedPreferences chunkPrefs;

    /** Llamar una vez antes de crear el puente (usa el contexto de la aplicación). */
    public static void initCache(android.content.Context ctx) {
        try { chunkPrefs = ctx.getApplicationContext().getSharedPreferences("bhttp_cache", android.content.Context.MODE_PRIVATE); }
        catch (Throwable ignored) { chunkPrefs = null; }
    }

    private String chunkCacheKey() {
        return "chunk:" + this.host + ":" + this.port + ":" + this.batchCount + ":" + this.chunkCap;
    }

    private int cachedChunk() {
        try {
            android.content.SharedPreferences sp = chunkPrefs;
            if (sp == null) return -1;
            String v = sp.getString(chunkCacheKey(), null);
            if (v == null) return -1;
            String[] parts = v.split("\\|");
            int size = Integer.parseInt(parts[0]);
            long at = Long.parseLong(parts[1]);
            // Si el valor guardado es menor al maximo posible, probablemente lo calibro un mal momento de red:
            // vence rapido (20 min) para volver a buscar uno mayor, en vez de quedarse 12 h con registros chicos.
            int best = this.chunkCap > 0 ? this.chunkCap : REFERENCE_DOWNLOAD_CHUNK_SIZE;
            long ttl = size >= best ? CHUNK_CACHE_TTL_MS : CHUNK_CACHE_LOW_TTL_MS;
            if (size < MIN_PROBE_CHUNK_SIZE || System.currentTimeMillis() - at > ttl) return -1;
            return size;
        } catch (Throwable t) { return -1; }
    }

    private void saveChunk(int size) {
        try {
            android.content.SharedPreferences sp = chunkPrefs;
            if (sp != null) sp.edit().putString(chunkCacheKey(), size + "|" + System.currentTimeMillis()).apply();
        } catch (Throwable ignored) { }
    }

    private void clearCachedChunk() {
        try {
            android.content.SharedPreferences sp = chunkPrefs;
            if (sp != null) sp.edit().remove(chunkCacheKey()).apply();
        } catch (Throwable ignored) { }
    }

    private int calibrateChunkSize() throws Exception {
        int cached = cachedChunk();
        if (cached > 0) {
            log("Calibración: confirmando el tamaño guardado de " + cached + " bytes...");
            if (acceptsChunkSize(cached)) {
                log("Calibración BHTTP: tamaño guardado confirmado (" + cached + " bytes)");
                return cached;
            }
            log("El tamaño guardado ya no sirve; se calibra de nuevo");
            clearCachedChunk();
        }
        int v = calibrateChunkSizeFull();
        saveChunk(v);
        return v;
    }

    private int calibrateChunkSizeFull() throws Exception {
        log("Calibrando envelope batch=" + this.batchCount + " del perfil 1.0.5 (chunk máximo 1399)...");
        int upper = REFERENCE_DOWNLOAD_CHUNK_SIZE;
        if (acceptsChunkSize(REFERENCE_DOWNLOAD_CHUNK_SIZE)) {
            if (this.chunkCap > REFERENCE_DOWNLOAD_CHUNK_SIZE) {
                return calibrateLargerChunkSize();
            }
            log("Calibración BHTTP: envelope completo aceptado; chunk fijado en 1399 bytes");
            return REFERENCE_DOWNLOAD_CHUNK_SIZE;
        }

        int found = -1;
        for (int step : CHUNK_FALLBACK_STEPS) {
            if (acceptsChunkSize(step)) {
                found = step;
                break;
            }
            upper = step;
        }
        if (found < 0) {
            throw new IOException("Calibración BHTTP falló hasta 10 bytes");
        }

        int low = found;
        int high = upper - 1;
        while (low < high) {
            int mid = low + (((high - low) + 1) >>> 1);
            if (acceptsChunkSize(mid)) {
                low = mid;
            } else {
                high = mid - 1;
            }
        }
        log("Calibración BHTTP: envelope limitado; chunk fijado en " + low
                + " bytes en esta sesión (máximo 1.0.5=1399)");
        return low;
    }

    // --- cache de la calibracion de subida (evita repetir los "Connection reset" en cada conexion) ---
    private String uploadCacheKey() {
        return "upchunk:" + this.host + ":" + this.port + ":" + (this.liveTune ? "live" : String.valueOf(this.uploadConnections));
    }

    private int cachedUploadChunk() {
        try {
            android.content.SharedPreferences sp = chunkPrefs;
            if (sp == null) return -1;
            String v = sp.getString(uploadCacheKey(), null);
            if (v == null) return -1;
            String[] parts = v.split("\\|");
            int size = Integer.parseInt(parts[0]);
            long at = Long.parseLong(parts[1]);
            long ttl = size >= REFERENCE_UPLOAD_CHUNK_SIZE ? CHUNK_CACHE_TTL_MS : CHUNK_CACHE_LOW_TTL_MS;
            if (size < MIN_PROBE_CHUNK_SIZE || System.currentTimeMillis() - at > ttl) return -1;
            return size;
        } catch (Throwable t) { return -1; }
    }

    private void saveUploadChunk(int size) {
        try {
            android.content.SharedPreferences sp = chunkPrefs;
            if (sp != null) sp.edit().putString(uploadCacheKey(), size + "|" + System.currentTimeMillis()).apply();
        } catch (Throwable ignored) { }
    }

    private void clearCachedUploadChunk() {
        try {
            android.content.SharedPreferences sp = chunkPrefs;
            if (sp != null) sp.edit().remove(uploadCacheKey()).apply();
        } catch (Throwable ignored) { }
    }

    private int calibrateUploadChunkSize() throws Exception {
        int cached = cachedUploadChunk();
        if (cached > 0) {
            log("Calibración upload: confirmando el tamaño guardado de " + cached + " bytes...");
            if (acceptsUploadChunkSize(cached)) {
                log("Calibración upload: tamaño guardado confirmado (" + cached + " bytes)");
                return cached;
            }
            log("El tamaño de subida guardado ya no sirve; se calibra de nuevo");
            clearCachedUploadChunk();
        }
        int v = calibrateUploadChunkSizeFull();
        saveUploadChunk(v);
        return v;
    }

    private int calibrateUploadChunkSizeFull() throws Exception {
        log("Calibrando upload BHTTP con " + calibUploadConns() + " conexiones concurrentes...");
        int lastAccepted = -1;
        for (int step : UPLOAD_CALIBRATION_STEPS) {
            if (!acceptsUploadChunkSize(step)) {
                if (lastAccepted < 0) {
                    lastAccepted = findLowUploadFallback();
                }
                sleep(UPLOAD_CALIBRATION_COOLDOWN_MS);
                log("Calibración upload: rango " + step + " inestable; margen operacional fijado en "
                        + lastAccepted + " bytes con " + this.uploadConnections + " conexiones");
                return lastAccepted;
            }
            lastAccepted = step;
        }
        log("Calibración upload: perfil máximo " + REFERENCE_UPLOAD_CHUNK_SIZE + " bytes aceptado con "
                + this.uploadConnections + " conexiones");
        return REFERENCE_UPLOAD_CHUNK_SIZE;
    }

    private int findLowUploadFallback() throws Exception {
        for (int step : UPLOAD_LOW_FALLBACK_STEPS) {
            if (acceptsUploadChunkSize(step)) {
                return step;
            }
        }
        throw new IOException("Calibración de upload falló hasta 10 bytes");
    }

    private boolean acceptsChunkSize(int size) throws Exception {
        return acceptsStableProbe(MODE_DOWNLOAD, batchEnvelopeProbeParameter(size), "download", size);
    }

    private boolean acceptsUploadChunkSize(int size) throws Exception {
        IOException lastError = null;
        for (int round = 1; round <= 2; round++) {
            try {
                runConcurrentUploadProbeRound(size);
                if (round == 2) {
                    log("Calibración upload=" + size + " recuperada en la segunda ronda concurrente");
                }
                return true;
            } catch (IOException e) {
                lastError = e;
                if (round == 1) {
                    sleep(100L);
                }
            }
        }
        log("Calibración upload=" + size + " rechazada en 2 rondas: " + concise(lastError));
        return false;
    }

    private void runConcurrentUploadProbeRound(int size) throws IOException {
        final int calConns = calibUploadConns();
        CountDownLatch startSignal = new CountDownLatch(calConns);
        CountDownLatch runSignal = new CountDownLatch(1);
        CountDownLatch doneSignal = new CountDownLatch(calConns);
        AtomicReference<Throwable> errorRef = new AtomicReference<>();

        for (int i = 0; i < calConns; i++) {
            Thread thread = new Thread(() -> {
                startSignal.countDown();
                try {
                    runSignal.await();
                    probe(MODE_UPLOAD, size, CALIBRATION_TIMEOUT_MS);
                } catch (Throwable th) {
                    errorRef.compareAndSet(null, th);
                } finally {
                    doneSignal.countDown();
                }
            }, "BHTTP-upload-calibration-" + i);
            thread.setDaemon(true);
            thread.start();
        }

        try {
            if (!startSignal.await(5L, TimeUnit.SECONDS)) {
                throw new IOException("los hilos de calibración no iniciaron");
            }
            runSignal.countDown();
            if (!doneSignal.await(12L, TimeUnit.SECONDS)) {
                throw new IOException("tiempo de espera agotado en la ronda concurrente de upload");
            }
            Throwable err = errorRef.get();
            if (err != null) {
                if (err instanceof IOException) {
                    throw (IOException) err;
                }
                throw new IOException(err);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("calibración de upload interrumpida", e);
        }
    }

    private boolean acceptsStableProbe(int mode, int param, String label, int value) throws Exception {
        IOException lastError = null;
        int successCount = 0;
        int failureCount = 0;
        for (int attempt = 1; attempt <= 3; attempt++) {
            try {
                probe(mode, param, CALIBRATION_TIMEOUT_MS);
                successCount++;
                if (successCount == 2) {
                    if (attempt > 2) {
                        log("Calibración " + label + "=" + value
                                + " recuperada y confirmada después de falla transitoria");
                    }
                    return true;
                }
            } catch (IOException e) {
                lastError = e;
                failureCount++;
                if (failureCount == 2) {
                    log("Calibración " + label + "=" + value + " rechazada 2x: " + concise(lastError));
                    return false;
                }
            }
            sleep(100L);
        }
        log("Calibración " + label + "=" + value + " inestable: " + concise(lastError));
        return false;
    }

    private int batchEnvelopeProbeParameter(int chunkSize) {
        return (int) Math.max(10L, ((long) (chunkSize + 9) * this.batchCount) - UPLOAD_COALESCE_MS);
    }

    private void registerSession() throws Exception {
        exchange(socket -> {
            sendRequest(socket, MODE_UPLOAD, 0L, new byte[0]);
            Response resp = readResponse(socket);
            if (resp.status != STATUS_OK) {
                throw new IOException("Registro BHTTP rechazado: " + resp.status);
            }
            return null;
        });
    }

    private void uploadReadLoop() {
        int maxChunk = this.uploadChunkSize;
        byte[] buffer = new byte[maxChunk];
        try {
            BufferedInputStream in = new BufferedInputStream(this.localSocket.getInputStream());
            long sequence = 0;
            int read;
            while (this.running.get() && (read = in.read(buffer)) >= 0) {
                if (read > 0) {
                    // Antes se dormia 5 ms en CADA lectura (techo ~200 KB/s con trozos de 1024 B).
                    // Ahora solo se espera si lo leido es poco y no hay mas datos listos (trafico interactivo);
                    // en subidas grandes el buffer siempre trae datos y no se duerme nunca.
                    if (read < maxChunk && in.available() == 0) {
                        sleep(UPLOAD_COALESCE_MS);
                    }
                    while (read < maxChunk && in.available() > 0) {
                        int extra = in.read(buffer, read, maxChunk - read);
                        if (extra <= 0) break;
                        read += extra;
                    }
                    byte[] rawData = new byte[read];
                    System.arraycopy(buffer, 0, rawData, 0, read);
                    byte[] encrypted = crypt(rawData, MODE_UPLOAD, sequence, false);
                    this.uploadQueue.put(new UploadFrame(sequence, read, encrypted));
                    sequence++;
                }
            }
        } catch (Throwable th) {
            fail(th);
        }
    }

    private void uploadWorkerLoop(int workerIndex) {
        while (this.running.get()) {
            try {
                if (this.liveTune && workerIndex >= this.liveUp) {   // Auto+: este hilo descansa
                    sleep(300);
                    continue;
                }
                UploadFrame frame = this.liveTune
                        ? this.uploadQueue.poll(500, java.util.concurrent.TimeUnit.MILLISECONDS)
                        : this.uploadQueue.take();
                if (frame == null) continue;
                int retries = 0;
                while (this.running.get()) {
                    try {
                        uploadFrame(frame.sequence, frame.encrypted);
                        break;
                    } catch (IOException e) {
                        if (!this.running.get()) return;
                        retries++;
                        if (isLocalNetError(e)) {
                            this.statNetDrops.incrementAndGet();
                        } else {
                            this.statResets.incrementAndGet();
                            if (retries >= 3) this.statDeepRetries.incrementAndGet();
                        }
                        if (retries > 10) throw e;
                        log("Retry upload seq=" + frame.sequence + " bytes=" + frame.clearLength + " intento=" + retries + " error=" + concise(e));
                        sleep((long) retries * 250L);
                    }
                }
                this.uploadedBytes.addAndGet(frame.clearLength);
                this.lastUploadNanos = System.nanoTime();
                synchronized (this.downloadWakeup) {
                    this.downloadWakeup.notifyAll();
                }
            } catch (InterruptedException unused) {
                Thread.currentThread().interrupt();
                return;
            } catch (Throwable th) {
                fail(th);
                return;
            }
        }
    }

    private void uploadFrame(long sequence, byte[] data) throws Exception {
        this.statUpBytes.addAndGet(data.length);
        exchange(socket -> {
            sendRequest(socket, MODE_UPLOAD, sequence, data);
            Response resp = readResponse(socket);
            if (resp.status != STATUS_OK) {
                throw new IOException("Upload seq=" + sequence + " status=" + resp.status);
            }
            return null;
        });
    }

    /**
     * Cada conexión reclama la siguiente ventana libre cuando termina la anterior, en vez de tener
     * asignadas ventanas fijas. Si una conexión se atasca (por ejemplo, una conexión que tarda 8 s),
     * solo se retrasa esa ventana: las demás conexiones siguen con las ventanas posteriores en vez de
     * quedar esperando a que la atascada vuelva a su turno.
     */
    private void downloadLoop(int loopIndex) {
        int emptyCount = 0;
        int retries = 0;
        long sequence = -1;    // ventana en curso; si falla se reintenta la misma
        while (this.running.get()) {
            try {
                if (sequence < 0) {
                    if (this.liveTune && loopIndex >= this.liveDown) {   // Auto+: este hilo descansa (no reclama ventana)
                        sleep(300);
                        continue;
                    }
                    sequence = this.nextDownloadClaim.getAndAdd(this.batchCount);
                }
                boolean hasData = downloadBatch(sequence);
                sequence = -1;
                if (hasData) {
                    if (emptyCount > 0) {
                        // Se acabó la calma: despierta a los demás hilos de bajada para atender la ráfaga de datos.
                        synchronized (this.downloadWakeup) {
                            this.downloadWakeup.notifyAll();
                        }
                    }
                    emptyCount = 0;
                } else {
                    emptyCount++;
                    boolean recentUpload = (System.nanoTime() - this.lastUploadNanos) < 2_000_000_000L;
                    // Sin tráfico, solo el primer hilo sondea al ritmo normal (cada 750 ms); los demás esperan más
                    // (1,5 s y 4 s) para no abrir decenas de conexiones por segundo sin necesidad. Se despiertan
                    // al instante con cualquier subida o cuando llegan datos, así que con tráfico no cambia nada.
                    long idleCap = loopIndex == 0 ? EMPTY_BATCH_DELAY_MS : (loopIndex == 1 ? 1500L : 4000L);
                    long waitMs = Math.min(idleCap, 25L << Math.min(emptyCount, 8));
                    if (recentUpload) {
                        waitMs = Math.min(50L, waitMs);
                    }
                    waitForDownload(waitMs);
                }
                retries = 0;
            } catch (Throwable th) {
                if (!this.running.get()) {
                    return;
                }
                retries++;
                if (isLocalNetError(th)) {
                    this.statNetDrops.incrementAndGet();
                } else {
                    this.statResets.incrementAndGet();
                    if (retries >= 3) this.statDeepRetries.incrementAndGet();
                }
                log("Retry batch seq=" + sequence + " intento=" + retries + " error=" + concise(th));
                if (retries > 10) {
                    fail(th);
                    return;
                }
                sleep(Math.min(2000L, (long) retries * 200L));
            }
        }
    }

    private boolean downloadBatch(long sequence) throws Exception {
        final int count = this.batchCount;
        byte[] requestBody = new byte[6];
        putInt(requestBody, 0, this.downloadChunkSize);
        requestBody[4] = 0;
        requestBody[5] = (byte) count;

        byte[] encryptedRequest = crypt(requestBody, MODE_BATCH, sequence, false);
        byte[][] decryptedChunks = new byte[count][];
        boolean hasData = exchange(socket -> {
            sendRequest(socket, MODE_BATCH, sequence, encryptedRequest);
            DataInputStream in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            boolean got = false;
            for (int i = 0; i < count; i++) {
                Response resp = readResponse(in);
                if (resp.status != STATUS_DATA || resp.body.length < 4) {
                    throw new IOException("Batch seq=" + (sequence + i) + " status=" + resp.status);
                }
                int dataLen = getInt(resp.body, 0);
                if (dataLen < 0 || dataLen != resp.body.length - 4) {
                    throw new IOException("Longitud DATA inválida: " + dataLen);
                }
                if (dataLen == 0) {
                    decryptedChunks[i] = new byte[0];
                } else {
                    byte[] enc = new byte[dataLen];
                    System.arraycopy(resp.body, 4, enc, 0, dataLen);
                    decryptedChunks[i] = crypt(enc, MODE_BATCH, sequence + i, true);
                    got = true;
                }
            }
            return got;
        }, DOWNLOAD_READ_TIMEOUT_MS);

        List<Long> acksToSend = new ArrayList<>();
        synchronized (this.downstreamLock) {
            if (this.pending.size() > MAX_PENDING_CHUNKS && !this.pending.containsKey(this.nextRead)) {
                throw new IOException("Ventana de descarga atascada (" + this.pending.size() + " registros en espera)");
            }
            for (int i = 0; i < count; i++) {
                this.pending.put(sequence + i, decryptedChunks[i]);
            }
            OutputStream out = this.localSocket.getOutputStream();
            while (this.pending.containsKey(this.nextRead)) {
                byte[] chunk = this.pending.remove(this.nextRead);
                if (chunk != null && chunk.length > 0) {
                    out.write(chunk);
                    out.flush();
                    this.downloadedBytes += chunk.length;
                }
                this.nextRead++;
            }

            while ((this.nextRead - 1) >= this.nextAck) {
                acksToSend.add(this.nextAck);
                this.nextAck += 187L;
            }
        }

        for (Long ackSeq : acksToSend) {
            try {
                acknowledge(ackSeq);
            } catch (Exception e) {
                if (this.running.get()) {
                    log("ACK seq=" + ackSeq + " aplazado: " + concise(e));
                }
            }
        }
        return hasData;
    }

    private void acknowledge(long sequence) throws Exception {
        exchange(socket -> {
            sendRequest(socket, MODE_ACK, sequence, new byte[0]);
            Response resp = readResponse(socket);
            if (resp.status != STATUS_OK) {
                throw new IOException("ACK seq=" + sequence + " status=" + resp.status);
            }
            return null;
        });
    }

    private interface SocketOp<T> {
        T run(Socket socket) throws Exception;
    }

    /**
     * Ejecuta una petición completa (envío + lectura de la respuesta entera).
     * Con TLS reutiliza conexiones ya abiertas: el handshake TLS 1.2 (2 viajes de ida y vuelta
     * más cifrado asimétrico) se paga una sola vez, no en cada petición. Si la conexión
     * reutilizada resulta cerrada por el servidor, se reintenta una vez con una nueva.
     */
    private <T> T exchange(SocketOp<T> op) throws Exception {
        return exchange(op, 15000);
    }

    private <T> T exchange(SocketOp<T> op, int readTimeoutMs) throws Exception {
        // Solo con TLS: sin TLS abrir una conexión es barato y el servidor cierra al responder.
        boolean allowReuse = (this.tlsSni != null || REUSE_PLAIN) && this.staleFails.get() < 3;
        for (int attempt = 0; ; attempt++) {
            Object[] idle = (allowReuse && attempt == 0) ? takeIdle() : null;
            Socket socket = idle != null ? (Socket) idle[0] : null;
            boolean reused = socket != null;
            if (!reused) {
                socket = openRequestSocket(readTimeoutMs);
            } else {
                try { socket.setSoTimeout(readTimeoutMs); } catch (IOException ignored) { }
            }
            boolean ok = false;
            try {
                T result = op.run(socket);
                ok = true;
                if (reused) {
                    this.statReused.incrementAndGet();   // solo cuenta reutilizaciones que funcionaron
                    this.staleFails.set(0);
                }
                return result;
            } catch (IOException e) {
                if (!reused || !this.running.get()) throw e;
                this.staleFails.incrementAndGet();
                // El servidor (o la red) cerró esta conexión mientras estaba libre: se acorta el
                // tiempo de reutilización para no volver a toparse con lo mismo, y se reintenta.
                long age = (Long) idle[1];
                long limit = Math.max(1_000_000_000L, age / 2);
                if (limit < this.poolMaxIdleNanos) {
                    this.poolMaxIdleNanos = limit;
                    log("Conexión libre cerrada por el servidor tras " + (age / 1_000_000L)
                            + " ms; reutilización limitada a " + (limit / 1_000_000L) + " ms");
                }
            } finally {
                if (ok && allowReuse && this.running.get()) releaseIdle(socket);
                else closeRequestSocket(socket);
            }
        }
    }

    /** Devuelve {socket, milisegundos-en-nanos que estuvo libre} o null si no hay ninguna utilizable. */
    private Object[] takeIdle() {
        long now = System.nanoTime();
        Object[] e;
        while ((e = this.idlePool.pollFirst()) != null) {
            Socket s = (Socket) e[0];
            long age = now - (Long) e[1];
            if (age > this.poolMaxIdleNanos || s.isClosed()) {
                closeRequestSocket(s);
                continue;
            }
            return new Object[]{s, age};
        }
        return null;
    }

    private void releaseIdle(Socket socket) {
        if (this.idlePool.size() >= this.uploadConnections + this.downloadConnections + 2) {
            closeRequestSocket(socket);
            return;
        }
        this.idlePool.addFirst(new Object[]{socket, System.nanoTime()});
    }

    private Socket openRequestSocket() throws IOException {
        return openRequestSocket(15000);
    }

    private Socket openRequestSocket(int timeoutMs) throws IOException {
        try {
            this.connectGate.acquire();
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw new java.io.InterruptedIOException("interrumpido");
        }
        try {
            return connectNew(timeoutMs);
        } catch (IOException | RuntimeException e) {
            if (isLocalNetError(e)) this.statNetDrops.incrementAndGet(); else this.statFails.incrementAndGet();
            throw e;
        } finally {
            this.connectGate.release();
        }
    }

    /**
     * Tiempo de espera de cada intento de conexión TCP. Una conexión normal tarda ~70 ms; si un SYN se pierde,
     * antes se esperaba 8 s. Ahora se reintenta pronto con un puerto nuevo (1,2 s, 1,5 s y por último 4 s).
     */
    private static final int[] CONNECT_ATTEMPT_TIMEOUTS_MS = {1200, 1500, 4000};
    private final java.util.concurrent.atomic.AtomicLong statQuickRetries = new java.util.concurrent.atomic.AtomicLong();

    private Socket connectNew(int timeoutMs) throws IOException {
        final long t0 = System.nanoTime();
        Socket socket = null;
        try {
            for (int attempt = 0; ; attempt++) {
                socket = new Socket();
                try {
                    // Frontera crea el FD antes de protect(): bind(0) -> protect -> connect.
                    socket.bind(new InetSocketAddress(0));
                    if (this.protector != null) {
                        boolean protectedOk = this.protector.protect(socket);
                        if (!protectedOk && this.protectWarningLogged.compareAndSet(false, true)) {
                            log("Aviso: protect(socket) retornó false; continuando porque el paquete está excluido de la VPN");
                        }
                    }
                    socket.setTcpNoDelay(true);
                    socket.setKeepAlive(true);
                    socket.connect(new InetSocketAddress(this.host, this.port), CONNECT_ATTEMPT_TIMEOUTS_MS[attempt]);
                    break;
                } catch (java.net.SocketTimeoutException e) {
                    try {
                        socket.close();
                    } catch (IOException ignored) {
                    }
                    socket = null;
                    if (attempt + 1 >= CONNECT_ATTEMPT_TIMEOUTS_MS.length || !this.running.get()) throw e;
                    this.statQuickRetries.incrementAndGet();
                }
            }
            String sni = this.tlsSni;
            if (sni != null) {
                socket = TlsWrap.wrap(socket, sni, this.port, 8000);
            }
            socket.setSoTimeout(timeoutMs);
            this.requestSockets.add(socket);
            this.statConns.incrementAndGet();
            this.statConnNanos.addAndGet(System.nanoTime() - t0);
            return socket;
        } catch (IOException | RuntimeException e) {
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException ignored) {
                }
            }
            throw e;
        }
    }

    private void closeRequestSocket(Socket socket) {
        if (socket != null) {
            this.requestSockets.remove(socket);
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }
    }

    private void sendRequest(Socket socket, int mode, long sequence, byte[] data) throws IOException {
        sendRequest(new DataOutputStream(new BufferedOutputStream(socket.getOutputStream())), mode, sequence, data);
    }

    private void sendRequest(DataOutputStream out, int mode, long sequence, byte[] data) throws IOException {
        // Cabecera + datos en un solo write: con TLS son un único registro y un único paquete.
        java.nio.ByteBuffer buf = java.nio.ByteBuffer.allocate(1 + 16 + 8 + 4 + data.length);
        buf.put((byte) mode);
        buf.put(this.sid);
        buf.putLong(sequence);
        buf.putInt(data.length);
        buf.put(data);
        out.write(buf.array(), 0, buf.position());
        out.flush();
    }

    private Response readResponse(Socket socket) throws IOException {
        return readResponse(new DataInputStream(new BufferedInputStream(socket.getInputStream())));
    }

    private Response readResponse(DataInputStream in) throws IOException {
        try {
            int status = in.readUnsignedByte();
            int length = in.readInt();
            if (length < 0 || length > 2097152) { // 2MB max
                throw new IOException("Resposta BHTTP grande/inválida: " + length);
            }
            byte[] body = new byte[length];
            in.readFully(body);
            return new Response(status, body);
        } catch (EOFException e) {
            throw new IOException("Resposta BHTTP truncada", e);
        }
    }

    private byte[] crypt(byte[] input, int mode, long sequence, boolean isResponse) throws Exception {
        byte[] output = new byte[input.length];
        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");

        ByteBuffer state = ByteBuffer.allocate(30).order(ByteOrder.BIG_ENDIAN);
        state.put(this.sid);
        state.put((byte) mode);
        state.putLong(sequence);
        state.put((byte) (isResponse ? 1 : 0));

        int offset = 0;
        int blockIndex = 0;
        while (offset < input.length) {
            state.putInt(26, blockIndex);
            byte[] digest = sha256.digest(state.array());
            int blockSize = Math.min(32, input.length - offset);
            for (int i = 0; i < blockSize; i++) {
                output[offset + i] = (byte) (input[offset + i] ^ digest[i]);
            }
            offset += blockSize;
            blockIndex++;
        }
        return output;
    }

    private void startThread(Thread t) {
        t.setDaemon(true);
        this.threads.add(t);
        t.start();
    }

    private void fail(Throwable th) {
        if (this.running.get() && this.terminalError.compareAndSet(null, th)) {
            this.listener.fatal(th);
        }
    }

    public long getUploadedBytes() {
        return this.uploadedBytes.get();
    }

    public long getDownloadedBytes() {
        return this.downloadedBytes;
    }

    @Override
    public void close() {
        this.running.set(false);
        closeQuietly();
    }

    private void closeQuietly() {
        this.uploadQueue.clear();
        synchronized (this.downloadWakeup) {
            this.downloadWakeup.notifyAll();
        }
        if (this.localListener != null) {
            try {
                this.localListener.close();
            } catch (IOException ignored) {
            }
        }
        if (this.localSocket != null) {
            try {
                this.localSocket.close();
            } catch (IOException ignored) {
            }
        }
        synchronized (this.requestSockets) {
            for (Socket s : new ArrayList<>(this.requestSockets)) {
                try {
                    s.close();
                } catch (IOException ignored) {
                }
            }
            this.requestSockets.clear();
            this.idlePool.clear();
        }
        synchronized (this.threads) {
            for (Thread t : this.threads) {
                t.interrupt();
            }
        }
    }

    private void log(String msg) {
        this.listener.log(msg);
    }

    private void waitForDownload(long ms) {
        synchronized (this.downloadWakeup) {
            if (this.running.get()) {
                try {
                    this.downloadWakeup.wait(ms);
                } catch (InterruptedException unused) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
    }

    private static String concise(Throwable th) {
        String msg = th.getMessage();
        return msg == null ? th.getClass().getSimpleName() : msg;
    }

    private static int getInt(byte[] b, int off) {
        return ((b[off] & 0xFF) << 24) |
               ((b[off + 1] & 0xFF) << 16) |
               ((b[off + 2] & 0xFF) << 8) |
               (b[off + 3] & 0xFF);
    }

    private static void putInt(byte[] b, int off, int val) {
        b[off] = (byte) (val >>> 24);
        b[off + 1] = (byte) (val >>> 16);
        b[off + 2] = (byte) (val >>> 8);
        b[off + 3] = (byte) val;
    }

    private static int clamp(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }

    private static String hex(byte[] data, int off, int len) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) {
            sb.append(String.format("%02x", data[off + i] & 0xFF));
        }
        return sb.toString();
    }

    public static final class Response {
        public final int status;
        public final byte[] body;

        public Response(int status, byte[] body) {
            this.status = status;
            this.body = body;
        }
    }

    public static final class UploadFrame {
        public final long sequence;
        public final int clearLength;
        public final byte[] encrypted;

        public UploadFrame(long sequence, int clearLength, byte[] encrypted) {
            this.sequence = sequence;
            this.clearLength = clearLength;
            this.encrypted = encrypted;
        }
    }
}
