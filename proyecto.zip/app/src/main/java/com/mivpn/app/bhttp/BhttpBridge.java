package com.mivpn.app.bhttp;

import java.util.concurrent.ConcurrentLinkedDeque;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

public final class BhttpBridge implements AutoCloseable {
    private static final int BATCH_COUNT = 8;
    private static final int CALIBRATION_TIMEOUT_MS = 3000;
    private static final int DEFAULT_DOWNLOAD_SLOTS = 32;
    private static final int DEFAULT_UPLOAD_SLOTS = 16;
    private static final long EMPTY_BATCH_DELAY_MS = 750;
    private static final int MIN_PROBE_CHUNK_SIZE = 10;
    private static final int MODE_PROBE = 0;
    private static final int MODE_UPLOAD = 1;
    private static final int MODE_DOWNLOAD = 2;
    private static final int MODE_BATCH = 3;
    private static final int MODE_ACK = 4;
    private static final int REFERENCE_DOWNLOAD_CHUNK_SIZE = 1399;
    /** Tope del modo Manual: se intenta subir de 1399 hasta este valor, y el servidor decide cuánto acepta. */
    private static final int MAX_MANUAL_CHUNK_SIZE = 9000;
    private static final int REFERENCE_UPLOAD_CHUNK_SIZE = 32768;
    private static final int STATUS_OK = 0;
    private static final int STATUS_DATA = 2;
    private static final long UPLOAD_CALIBRATION_COOLDOWN_MS = 750;
    private static final long UPLOAD_COALESCE_MS = 5;

    private static final int[] CHUNK_FALLBACK_STEPS = {1024, 768, 512, 256, 128, 64, 32, 16, 10};
    private static final int[] UPLOAD_CALIBRATION_STEPS = {4096, 8192, 12288, 16384, 20480, 24576, 32768};
    private static final int[] UPLOAD_LOW_FALLBACK_STEPS = {2048, 1024, 512, 256, 128, 64, 32, 16, 10};

    private final String host;
    private final int port;
    private final Listener listener;
    private final SocketProtector protector;
    /** Si no es null, cada conexión al servidor se envuelve en TLS 1.2 con este SNI. */
    private volatile String tlsSni;
    /** Conexiones TLS ya establecidas y libres, para no repetir el handshake en cada petición. */
    /** Tiempo máximo que una conexión libre se reutiliza; se acorta solo si el servidor las cierra antes. */
    private volatile long poolMaxIdleNanos = 5_000_000_000L;
    private final ConcurrentLinkedDeque<Object[]> idlePool = new ConcurrentLinkedDeque<>();
    // Estadísticas para diagnosticar velocidad (se imprimen cada 10 s en el registro)
    private final java.util.concurrent.atomic.AtomicLong statConns = new java.util.concurrent.atomic.AtomicLong();
    private final java.util.concurrent.atomic.AtomicLong statConnNanos = new java.util.concurrent.atomic.AtomicLong();
    private final java.util.concurrent.atomic.AtomicLong statReused = new java.util.concurrent.atomic.AtomicLong();
    private final java.util.concurrent.atomic.AtomicLong statUpBytes = new java.util.concurrent.atomic.AtomicLong();
    /** Reutilizaciones fallidas seguidas: si el servidor cierra cada conexión al responder, se deja de reutilizar. */
    private final java.util.concurrent.atomic.AtomicInteger staleFails = new java.util.concurrent.atomic.AtomicInteger();
    /**
     * Máximo de conexiones nuevas en curso a la vez. Antes era fijo en 8, y eso anulaba las subidas y descargas
     * en paralelo: con 16 + 32 configuradas, solo 8 podían estar conectando al mismo tiempo (la versión 1.19 no
     * tenía ese tope). Ahora se ajusta a la cantidad de subidas + descargas elegidas.
     */
    private final java.util.concurrent.Semaphore connectGate;
    private final java.util.concurrent.atomic.AtomicLong statFails = new java.util.concurrent.atomic.AtomicLong();
    private final int uploadConnections;
    private final int downloadConnections;
    private long windowStride;
    /** Próxima secuencia de descarga sin pedir: cada conexión libre reclama la siguiente ventana disponible. */
    private final java.util.concurrent.atomic.AtomicLong nextDownloadClaim = new java.util.concurrent.atomic.AtomicLong();
    private final long[] windowBases;
    private final byte[] sid = new byte[16];

    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicBoolean protectWarningLogged = new AtomicBoolean(false);
    private final AtomicReference<Throwable> terminalError = new AtomicReference<>();
    private final List<Socket> requestSockets = Collections.synchronizedList(new ArrayList<>());
    private final List<Thread> threads = Collections.synchronizedList(new ArrayList<>());
    private final Object downstreamLock = new Object();
    private final Object downloadWakeup = new Object();
    private final Map<Long, byte[]> pending = new HashMap<>();
    private final BlockingQueue<UploadFrame> uploadQueue;
    private final AtomicLong uploadedBytes = new AtomicLong();

    private int downloadChunkSize = REFERENCE_DOWNLOAD_CHUNK_SIZE;
    /** Registros por pedido de descarga (8 por defecto; se puede cambiar en modo Manual). */
    private volatile int batchCount = BATCH_COUNT;
    /** Si es mayor que 0, tope manual del tamaño de registro (nunca supera lo que el servidor acepta). */
    private int chunkCap = 0;
    private int uploadChunkSize = REFERENCE_UPLOAD_CHUNK_SIZE;
    private volatile long downloadedBytes;
    private volatile long lastUploadNanos;
    private long nextRead;
    private long nextAck = 186L;

    private ServerSocket localListener;
    private Socket localSocket;

    public interface Listener {
        void fatal(Throwable th);
        void log(String str);
    }

    public interface SocketProtector {
        boolean protect(Socket socket);
    }

    public BhttpBridge(String host, int port, Listener listener, SocketProtector socketProtector) {
        this(host, port, listener, socketProtector, DEFAULT_UPLOAD_SLOTS, DEFAULT_DOWNLOAD_SLOTS);
    }

    public BhttpBridge(String host, int port, Listener listener, SocketProtector socketProtector, int uploadSlots, int downloadSlots) {
        this.host = host;
        this.port = port;
        this.listener = listener;
        this.protector = socketProtector;
        this.uploadConnections = clamp(uploadSlots, 1, 64);
        this.downloadConnections = clamp(downloadSlots, 1, 128);
        this.windowStride = (long) this.downloadConnections * BATCH_COUNT;
        this.windowBases = new long[this.downloadConnections];
        this.connectGate = new java.util.concurrent.Semaphore(Math.max(8, this.uploadConnections + this.downloadConnections));

        for (int i = 0; i < this.windowBases.length; i++) {
            this.windowBases[i] = (long) i * BATCH_COUNT;
        }
        this.uploadQueue = new ArrayBlockingQueue<>(this.uploadConnections * 2);
        new SecureRandom().nextBytes(this.sid);
    }

    /** Activa TLS 1.2 con SNI hacia el servidor. Llamar antes de start(). null o vacío = sin TLS. */
    public void setTlsSni(String sni) {
        this.tlsSni = (sni == null || sni.trim().isEmpty()) ? null : sni.trim();
    }

    /** Modo Manual: lote de descarga (1-32) y tope del tamaño de registro (64-9000, 0 = el calibrado). Llamar antes de start(). */
    public void setBatch(int batch, int chunkCap) {
        this.batchCount = clamp(batch, 1, 32);
        this.chunkCap = chunkCap <= 0 ? 0 : clamp(chunkCap, 64, MAX_MANUAL_CHUNK_SIZE);
        this.windowStride = (long) this.downloadConnections * this.batchCount;
        for (int i = 0; i < this.windowBases.length; i++) {
            this.windowBases[i] = (long) i * this.batchCount;
        }
    }

    public int start() throws Exception {
        if (!this.running.compareAndSet(false, true)) {
            throw new IllegalStateException("BHTTP bridge already started");
        }
        try {
            log("BHTTP SID " + hex(this.sid, 0, 4));
            probe(MODE_PROBE, 0);
            probe(MODE_UPLOAD, 10);
            this.downloadChunkSize = calibrateChunkSize();
            if (this.chunkCap > 0 && this.downloadChunkSize > this.chunkCap) {
                this.downloadChunkSize = this.chunkCap;
                log("Tamaño de registro limitado manualmente a " + this.chunkCap + " bytes");
            }
            this.uploadChunkSize = calibrateUploadChunkSize();
            probe(MODE_BATCH, 8);
            probe(MODE_ACK, 1);
            log("Probe BHP1: todos los modos aceptados");
            log("Perfil funcional 1.0.11 invertido: downloadConns=" + this.downloadConnections
                    + ", uploadConns=" + this.uploadConnections
                    + ", batch=" + this.batchCount + ", download=" + this.downloadChunkSize
                    + ", upload=" + this.uploadChunkSize
                    + " fijos, stride=" + this.windowStride);
            registerSession();
            log("Registro BHTTP seq=0 aceptado");

            this.localListener = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"));
            startThread(new Thread(this::acceptLocalSsh, "BHTTP-local-accept"));
            return this.localListener.getLocalPort();
        } catch (Throwable th) {
            this.running.set(false);
            closeQuietly();
            if (th instanceof Exception) {
                throw (Exception) th;
            }
            throw new IOException(th);
        }
    }

    private void acceptLocalSsh() {
        try {
            this.localSocket = this.localListener.accept();
            this.localSocket.setTcpNoDelay(true);
            log("SSH conectado al bridge local");

            startThread(new Thread(this::statsLoop, "BHTTP-stats"));
            startThread(new Thread(this::uploadReadLoop, "BHTTP-upload-reader"));
            for (int i = 0; i < this.uploadConnections; i++) {
                startThread(new Thread(this::uploadWorkerLoop, "BHTTP-upload-" + i));
            }
            for (int i = 0; i < this.downloadConnections; i++) {
                startThread(new Thread(this::downloadLoop, "BHTTP-download-" + i));
            }
        } catch (Throwable th) {
            fail(th);
        }
    }

    private void statsLoop() {
        long lastDown = this.downloadedBytes, lastUp = this.statUpBytes.get();
        long lastConns = 0, lastNanos = 0, lastReused = 0;
        while (this.running.get()) {
            sleep(10000);
            if (!this.running.get()) return;
            long down = this.downloadedBytes, up = this.statUpBytes.get();
            long conns = this.statConns.get(), nanos = this.statConnNanos.get(), reused = this.statReused.get();
            long dc = conns - lastConns;
            long avgMs = dc > 0 ? (nanos - lastNanos) / dc / 1_000_000L : 0;
            log("Velocidad 10s: bajada " + ((down - lastDown) / 10240) + " KB/s, subida " + ((up - lastUp) / 10240)
                    + " KB/s | conexiones nuevas " + dc + " (media " + avgMs + " ms"
                    + (this.tlsSni != null ? " con TLS" : "") + "), reutilizadas con éxito " + (reused - lastReused)
                    + ", fallos de conexión acum. " + this.statFails.get()
                    );
            lastDown = down; lastUp = up; lastConns = conns; lastNanos = nanos; lastReused = reused;
        }
    }

    private void probe(int mode, int param) throws Exception {
        probe(mode, param, 15000);
    }

    private void probe(int mode, int param, int timeoutMs) throws Exception {
        byte[] payload = crypt(makeProbePayload(mode, param), MODE_PROBE, 0L, false);
        Socket socket = openRequestSocket(timeoutMs);
        try {
            sendRequest(socket, MODE_PROBE, 0L, payload);
            Response resp = readResponse(socket);
            if (resp.status != STATUS_OK) {
                throw new IOException("BHP1 mode " + mode + " status " + resp.status);
            }
            validateProbeResponse(crypt(resp.body, MODE_PROBE, 0L, true), mode, param);
        } finally {
            closeRequestSocket(socket);
        }
    }

    private static byte[] makeProbePayload(int mode, int param) {
        int length = mode == MODE_UPLOAD ? Math.max(MIN_PROBE_CHUNK_SIZE, param) : MIN_PROBE_CHUNK_SIZE;
        byte[] buf = new byte[length];
        buf[0] = 66; // 'B'
        buf[1] = 72; // 'H'
        buf[2] = 80; // 'P'
        buf[3] = 49; // '1'
        buf[4] = 1;  // Version
        buf[5] = (byte) mode;
        putInt(buf, 6, param);
        for (int i = 10; i < length; i++) {
            buf[i] = (byte) ((i * 31) & 0xFF);
        }
        return buf;
    }

    private static void validateProbeResponse(byte[] buf, int mode, int param) throws IOException {
        int expectedLen = mode == MODE_DOWNLOAD ? Math.max(MIN_PROBE_CHUNK_SIZE, param) : MIN_PROBE_CHUNK_SIZE;
        if (buf.length != expectedLen || buf[0] != 66 || buf[1] != 72 || buf[2] != 80 || buf[3] != 49 || buf[4] != 1 ||
                (buf[5] & 0xFF) != mode || getInt(buf, 6) != param) {
            throw new IOException("Respuesta BHP1 inválida en modo " + mode + ": tamaño=" + buf.length + ", esperado=" + expectedLen);
        }
        for (int i = 10; i < buf.length; i++) {
            if (buf[i] != (byte) ((i * 31) & 0xFF)) {
                throw new IOException("Respuesta BHP1 corrupta en el byte " + i);
            }
        }
    }

    /**
     * Solo en Manual con un registro mayor a 1399: se le pregunta al servidor cuál es el mayor tamaño que acepta
     * (primero el valor pedido y, si no, se acota por mitades). Si no acepta nada mayor, se queda en 1399.
     */
    private int calibrateLargerChunkSize() throws Exception {
        int low = REFERENCE_DOWNLOAD_CHUNK_SIZE;
        int high = this.chunkCap;
        log("Calibrando registro mayor a 1399 (hasta " + high + " bytes)...");
        if (acceptsChunkSize(high)) {
            log("Calibración BHTTP: el servidor acepta registros de " + high + " bytes");
            return high;
        }
        high--;
        while (high - low > 256) {
            int mid = low + (((high - low) + 1) >>> 1);
            if (acceptsChunkSize(mid)) {
                low = mid;
            } else {
                high = mid - 1;
            }
        }
        if (low == REFERENCE_DOWNLOAD_CHUNK_SIZE) {
            log("Calibración BHTTP: el servidor no acepta registros mayores a 1399; se queda en 1399 bytes");
        } else {
            log("Calibración BHTTP: el servidor acepta registros de hasta " + low + " bytes");
        }
        return low;
    }

    private int calibrateChunkSize() throws Exception {
        log("Calibrando envelope batch=" + this.batchCount + " del perfil 1.0.5 (chunk máximo 1399)...");
        int upper = REFERENCE_DOWNLOAD_CHUNK_SIZE;
        if (acceptsChunkSize(REFERENCE_DOWNLOAD_CHUNK_SIZE)) {
            if (this.chunkCap > REFERENCE_DOWNLOAD_CHUNK_SIZE) {
                return calibrateLargerChunkSize();
            }
            log("Calibración BHTTP: envelope completo aceptado; chunk fijado en 1399 bytes");
            return REFERENCE_DOWNLOAD_CHUNK_SIZE;
        }

        int found = -1;
        for (int step : CHUNK_FALLBACK_STEPS) {
            if (acceptsChunkSize(step)) {
                found = step;
                break;
            }
            upper = step;
        }
        if (found < 0) {
            throw new IOException("Calibración BHTTP falló hasta 10 bytes");
        }

        int low = found;
        int high = upper - 1;
        while (low < high) {
            int mid = low + (((high - low) + 1) >>> 1);
            if (acceptsChunkSize(mid)) {
                low = mid;
            } else {
                high = mid - 1;
            }
        }
        log("Calibración BHTTP: envelope limitado; chunk fijado en " + low
                + " bytes en esta sesión (máximo 1.0.5=1399)");
        return low;
    }

    private int calibrateUploadChunkSize() throws Exception {
        log("Calibrando upload BHTTP con " + this.uploadConnections + " conexiones concurrentes...");
        int lastAccepted = -1;
        for (int step : UPLOAD_CALIBRATION_STEPS) {
            if (!acceptsUploadChunkSize(step)) {
                if (lastAccepted < 0) {
                    lastAccepted = findLowUploadFallback();
                }
                sleep(UPLOAD_CALIBRATION_COOLDOWN_MS);
                log("Calibración upload: rango " + step + " inestable; margen operacional fijado en "
                        + lastAccepted + " bytes con " + this.uploadConnections + " conexiones");
                return lastAccepted;
            }
            lastAccepted = step;
        }
        log("Calibración upload: perfil máximo 32768 bytes aceptado con "
                + this.uploadConnections + " conexiones");
        return REFERENCE_UPLOAD_CHUNK_SIZE;
    }

    private int findLowUploadFallback() throws Exception {
        for (int step : UPLOAD_LOW_FALLBACK_STEPS) {
            if (acceptsUploadChunkSize(step)) {
                return step;
            }
        }
        throw new IOException("Calibración de upload falló hasta 10 bytes");
    }

    private boolean acceptsChunkSize(int size) throws Exception {
        return acceptsStableProbe(MODE_DOWNLOAD, batchEnvelopeProbeParameter(size), "download", size);
    }

    private boolean acceptsUploadChunkSize(int size) throws Exception {
        IOException lastError = null;
        for (int round = 1; round <= 2; round++) {
            try {
                runConcurrentUploadProbeRound(size);
                if (round == 2) {
                    log("Calibración upload=" + size + " recuperada en la segunda ronda concurrente");
                }
                return true;
            } catch (IOException e) {
                lastError = e;
                if (round == 1) {
                    sleep(100L);
                }
            }
        }
        log("Calibración upload=" + size + " rechazada en 2 rondas: " + concise(lastError));
        return false;
    }

    private void runConcurrentUploadProbeRound(int size) throws IOException {
        CountDownLatch startSignal = new CountDownLatch(this.uploadConnections);
        CountDownLatch runSignal = new CountDownLatch(1);
        CountDownLatch doneSignal = new CountDownLatch(this.uploadConnections);
        AtomicReference<Throwable> errorRef = new AtomicReference<>();

        for (int i = 0; i < this.uploadConnections; i++) {
            Thread thread = new Thread(() -> {
                startSignal.countDown();
                try {
                    runSignal.await();
                    probe(MODE_UPLOAD, size, CALIBRATION_TIMEOUT_MS);
                } catch (Throwable th) {
                    errorRef.compareAndSet(null, th);
                } finally {
                    doneSignal.countDown();
                }
            }, "BHTTP-upload-calibration-" + i);
            thread.setDaemon(true);
            thread.start();
        }

        try {
            if (!startSignal.await(5L, TimeUnit.SECONDS)) {
                throw new IOException("los hilos de calibración no iniciaron");
            }
            runSignal.countDown();
            if (!doneSignal.await(12L, TimeUnit.SECONDS)) {
                throw new IOException("tiempo de espera agotado en la ronda concurrente de upload");
            }
            Throwable err = errorRef.get();
            if (err != null) {
                if (err instanceof IOException) {
                    throw (IOException) err;
                }
                throw new IOException(err);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("calibración de upload interrumpida", e);
        }
    }

    private boolean acceptsStableProbe(int mode, int param, String label, int value) throws Exception {
        IOException lastError = null;
        int successCount = 0;
        int failureCount = 0;
        for (int attempt = 1; attempt <= 3; attempt++) {
            try {
                probe(mode, param, CALIBRATION_TIMEOUT_MS);
                successCount++;
                if (successCount == 2) {
                    if (attempt > 2) {
                        log("Calibración " + label + "=" + value
                                + " recuperada y confirmada después de falla transitoria");
                    }
                    return true;
                }
            } catch (IOException e) {
                lastError = e;
                failureCount++;
                if (failureCount == 2) {
                    log("Calibración " + label + "=" + value + " rechazada 2x: " + concise(lastError));
                    return false;
                }
            }
            sleep(100L);
        }
        log("Calibración " + label + "=" + value + " inestable: " + concise(lastError));
        return false;
    }

    private int batchEnvelopeProbeParameter(int chunkSize) {
        return (int) Math.max(10L, ((long) (chunkSize + 9) * this.batchCount) - UPLOAD_COALESCE_MS);
    }

    private void registerSession() throws Exception {
        exchange(socket -> {
            sendRequest(socket, MODE_UPLOAD, 0L, new byte[0]);
            Response resp = readResponse(socket);
            if (resp.status != STATUS_OK) {
                throw new IOException("Registro BHTTP rechazado: " + resp.status);
            }
            return null;
        });
    }

    private void uploadReadLoop() {
        int maxChunk = this.uploadChunkSize;
        byte[] buffer = new byte[maxChunk];
        try {
            BufferedInputStream in = new BufferedInputStream(this.localSocket.getInputStream());
            long sequence = 0;
            int read;
            while (this.running.get() && (read = in.read(buffer)) >= 0) {
                if (read > 0) {
                    sleep(UPLOAD_COALESCE_MS);
                    while (read < maxChunk && in.available() > 0) {
                        int extra = in.read(buffer, read, maxChunk - read);
                        if (extra <= 0) break;
                        read += extra;
                    }
                    byte[] rawData = new byte[read];
                    System.arraycopy(buffer, 0, rawData, 0, read);
                    byte[] encrypted = crypt(rawData, MODE_UPLOAD, sequence, false);
                    this.uploadQueue.put(new UploadFrame(sequence, read, encrypted));
                    sequence++;
                }
            }
        } catch (Throwable th) {
            fail(th);
        }
    }

    private void uploadWorkerLoop() {
        while (this.running.get()) {
            try {
                UploadFrame frame = this.uploadQueue.take();
                int retries = 0;
                while (this.running.get()) {
                    try {
                        uploadFrame(frame.sequence, frame.encrypted);
                        break;
                    } catch (IOException e) {
                        if (!this.running.get()) return;
                        retries++;
                        if (retries > 10) throw e;
                        log("Retry upload seq=" + frame.sequence + " bytes=" + frame.clearLength + " intento=" + retries + " error=" + concise(e));
                        sleep((long) retries * 250L);
                    }
                }
                this.uploadedBytes.addAndGet(frame.clearLength);
                this.lastUploadNanos = System.nanoTime();
                synchronized (this.downloadWakeup) {
                    this.downloadWakeup.notifyAll();
                }
            } catch (InterruptedException unused) {
                Thread.currentThread().interrupt();
                return;
            } catch (Throwable th) {
                fail(th);
                return;
            }
        }
    }

    private void uploadFrame(long sequence, byte[] data) throws Exception {
        this.statUpBytes.addAndGet(data.length);
        exchange(socket -> {
            sendRequest(socket, MODE_UPLOAD, sequence, data);
            Response resp = readResponse(socket);
            if (resp.status != STATUS_OK) {
                throw new IOException("Upload seq=" + sequence + " status=" + resp.status);
            }
            return null;
        });
    }

    /**
     * Cada conexión reclama la siguiente ventana libre cuando termina la anterior, en vez de tener
     * asignadas ventanas fijas. Si una conexión se atasca (por ejemplo, una conexión que tarda 8 s),
     * solo se retrasa esa ventana: las demás conexiones siguen con las ventanas posteriores en vez de
     * quedar esperando a que la atascada vuelva a su turno.
     */
    private void downloadLoop() {
        int emptyCount = 0;
        int retries = 0;
        long sequence = -1;    // ventana en curso; si falla se reintenta la misma
        while (this.running.get()) {
            try {
                if (sequence < 0) {
                    sequence = this.nextDownloadClaim.getAndAdd(this.batchCount);
                }
                boolean hasData = downloadBatch(sequence);
                sequence = -1;
                if (hasData) {
                    emptyCount = 0;
                } else {
                    emptyCount++;
                    boolean recentUpload = (System.nanoTime() - this.lastUploadNanos) < 2_000_000_000L;
                    long waitMs = Math.min(EMPTY_BATCH_DELAY_MS, 25L << Math.min(emptyCount, 5));
                    if (recentUpload) {
                        waitMs = Math.min(50L, waitMs);
                    }
                    waitForDownload(waitMs);
                }
                retries = 0;
            } catch (Throwable th) {
                if (!this.running.get()) {
                    return;
                }
                retries++;
                log("Retry batch seq=" + sequence + " intento=" + retries + " error=" + concise(th));
                if (retries > 10) {
                    fail(th);
                    return;
                }
                sleep(Math.min(2000L, (long) retries * 200L));
            }
        }
    }

    private boolean downloadBatch(long sequence) throws Exception {
        final int count = this.batchCount;
        byte[] requestBody = new byte[6];
        putInt(requestBody, 0, this.downloadChunkSize);
        requestBody[4] = 0;
        requestBody[5] = (byte) count;

        byte[] encryptedRequest = crypt(requestBody, MODE_BATCH, sequence, false);
        byte[][] decryptedChunks = new byte[count][];
        boolean hasData = exchange(socket -> {
            sendRequest(socket, MODE_BATCH, sequence, encryptedRequest);
            DataInputStream in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            boolean got = false;
            for (int i = 0; i < count; i++) {
                Response resp = readResponse(in);
                if (resp.status != STATUS_DATA || resp.body.length < 4) {
                    throw new IOException("Batch seq=" + (sequence + i) + " status=" + resp.status);
                }
                int dataLen = getInt(resp.body, 0);
                if (dataLen < 0 || dataLen != resp.body.length - 4) {
                    throw new IOException("Longitud DATA inválida: " + dataLen);
                }
                if (dataLen == 0) {
                    decryptedChunks[i] = new byte[0];
                } else {
                    byte[] enc = new byte[dataLen];
                    System.arraycopy(resp.body, 4, enc, 0, dataLen);
                    decryptedChunks[i] = crypt(enc, MODE_BATCH, sequence + i, true);
                    got = true;
                }
            }
            return got;
        });

        List<Long> acksToSend = new ArrayList<>();
        synchronized (this.downstreamLock) {
            for (int i = 0; i < count; i++) {
                this.pending.put(sequence + i, decryptedChunks[i]);
            }
            OutputStream out = this.localSocket.getOutputStream();
            while (this.pending.containsKey(this.nextRead)) {
                byte[] chunk = this.pending.remove(this.nextRead);
                if (chunk != null && chunk.length > 0) {
                    out.write(chunk);
                    out.flush();
                    this.downloadedBytes += chunk.length;
                }
                this.nextRead++;
            }

            while ((this.nextRead - 1) >= this.nextAck) {
                acksToSend.add(this.nextAck);
                this.nextAck += 187L;
            }
        }

        for (Long ackSeq : acksToSend) {
            try {
                acknowledge(ackSeq);
            } catch (Exception e) {
                if (this.running.get()) {
                    log("ACK seq=" + ackSeq + " aplazado: " + concise(e));
                }
            }
        }
        return hasData;
    }

    private void acknowledge(long sequence) throws Exception {
        exchange(socket -> {
            sendRequest(socket, MODE_ACK, sequence, new byte[0]);
            Response resp = readResponse(socket);
            if (resp.status != STATUS_OK) {
                throw new IOException("ACK seq=" + sequence + " status=" + resp.status);
            }
            return null;
        });
    }

    private interface SocketOp<T> {
        T run(Socket socket) throws Exception;
    }

    /**
     * Ejecuta una petición completa (envío + lectura de la respuesta entera).
     * Con TLS reutiliza conexiones ya abiertas: el handshake TLS 1.2 (2 viajes de ida y vuelta
     * más cifrado asimétrico) se paga una sola vez, no en cada petición. Si la conexión
     * reutilizada resulta cerrada por el servidor, se reintenta una vez con una nueva.
     */
    private <T> T exchange(SocketOp<T> op) throws Exception {
        // Solo con TLS: sin TLS abrir una conexión es barato y el servidor cierra al responder.
        boolean allowReuse = this.tlsSni != null && this.staleFails.get() < 3;
        for (int attempt = 0; ; attempt++) {
            Object[] idle = (allowReuse && attempt == 0) ? takeIdle() : null;
            Socket socket = idle != null ? (Socket) idle[0] : null;
            boolean reused = socket != null;
            if (!reused) socket = openRequestSocket();
            boolean ok = false;
            try {
                T result = op.run(socket);
                ok = true;
                if (reused) {
                    this.statReused.incrementAndGet();   // solo cuenta reutilizaciones que funcionaron
                    this.staleFails.set(0);
                }
                return result;
            } catch (IOException e) {
                if (!reused || !this.running.get()) throw e;
                this.staleFails.incrementAndGet();
                // El servidor (o la red) cerró esta conexión mientras estaba libre: se acorta el
                // tiempo de reutilización para no volver a toparse con lo mismo, y se reintenta.
                long age = (Long) idle[1];
                long limit = Math.max(1_000_000_000L, age / 2);
                if (limit < this.poolMaxIdleNanos) {
                    this.poolMaxIdleNanos = limit;
                    log("Conexión libre cerrada por el servidor tras " + (age / 1_000_000L)
                            + " ms; reutilización limitada a " + (limit / 1_000_000L) + " ms");
                }
            } finally {
                if (ok && allowReuse && this.running.get()) releaseIdle(socket);
                else closeRequestSocket(socket);
            }
        }
    }

    /** Devuelve {socket, milisegundos-en-nanos que estuvo libre} o null si no hay ninguna utilizable. */
    private Object[] takeIdle() {
        long now = System.nanoTime();
        Object[] e;
        while ((e = this.idlePool.pollFirst()) != null) {
            Socket s = (Socket) e[0];
            long age = now - (Long) e[1];
            if (age > this.poolMaxIdleNanos || s.isClosed()) {
                closeRequestSocket(s);
                continue;
            }
            return new Object[]{s, age};
        }
        return null;
    }

    private void releaseIdle(Socket socket) {
        if (this.idlePool.size() >= this.uploadConnections + this.downloadConnections + 2) {
            closeRequestSocket(socket);
            return;
        }
        this.idlePool.addFirst(new Object[]{socket, System.nanoTime()});
    }

    private Socket openRequestSocket() throws IOException {
        return openRequestSocket(15000);
    }

    private Socket openRequestSocket(int timeoutMs) throws IOException {
        try {
            this.connectGate.acquire();
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            throw new java.io.InterruptedIOException("interrumpido");
        }
        try {
            return connectNew(timeoutMs);
        } catch (IOException | RuntimeException e) {
            this.statFails.incrementAndGet();
            throw e;
        } finally {
            this.connectGate.release();
        }
    }

    private Socket connectNew(int timeoutMs) throws IOException {
        final long t0 = System.nanoTime();
        Socket socket = new Socket();
        try {
            // Frontera crea el FD antes de protect(): bind(0) -> protect -> connect.
            socket.bind(new InetSocketAddress(0));
            if (this.protector != null) {
                boolean protectedOk = this.protector.protect(socket);
                if (!protectedOk && this.protectWarningLogged.compareAndSet(false, true)) {
                    log("Aviso: protect(socket) retornó false; continuando porque el paquete está excluido de la VPN");
                }
            }
            socket.setTcpNoDelay(true);
            socket.setKeepAlive(true);
            socket.connect(new InetSocketAddress(this.host, this.port), 8000);
            String sni = this.tlsSni;
            if (sni != null) {
                socket = TlsWrap.wrap(socket, sni, this.port, 8000);
            }
            socket.setSoTimeout(timeoutMs);
            this.requestSockets.add(socket);
            this.statConns.incrementAndGet();
            this.statConnNanos.addAndGet(System.nanoTime() - t0);
            return socket;
        } catch (IOException | RuntimeException e) {
            try {
                socket.close();
            } catch (IOException ignored) {
            }
            throw e;
        }
    }

    private void closeRequestSocket(Socket socket) {
        if (socket != null) {
            this.requestSockets.remove(socket);
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }
    }

    private void sendRequest(Socket socket, int mode, long sequence, byte[] data) throws IOException {
        sendRequest(new DataOutputStream(new BufferedOutputStream(socket.getOutputStream())), mode, sequence, data);
    }

    private void sendRequest(DataOutputStream out, int mode, long sequence, byte[] data) throws IOException {
        // Cabecera + datos en un solo write: con TLS son un único registro y un único paquete.
        java.nio.ByteBuffer buf = java.nio.ByteBuffer.allocate(1 + 16 + 8 + 4 + data.length);
        buf.put((byte) mode);
        buf.put(this.sid);
        buf.putLong(sequence);
        buf.putInt(data.length);
        buf.put(data);
        out.write(buf.array(), 0, buf.position());
        out.flush();
    }

    private Response readResponse(Socket socket) throws IOException {
        return readResponse(new DataInputStream(new BufferedInputStream(socket.getInputStream())));
    }

    private Response readResponse(DataInputStream in) throws IOException {
        try {
            int status = in.readUnsignedByte();
            int length = in.readInt();
            if (length < 0 || length > 2097152) { // 2MB max
                throw new IOException("Resposta BHTTP grande/inválida: " + length);
            }
            byte[] body = new byte[length];
            in.readFully(body);
            return new Response(status, body);
        } catch (EOFException e) {
            throw new IOException("Resposta BHTTP truncada", e);
        }
    }

    private byte[] crypt(byte[] input, int mode, long sequence, boolean isResponse) throws Exception {
        byte[] output = new byte[input.length];
        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");

        ByteBuffer state = ByteBuffer.allocate(30).order(ByteOrder.BIG_ENDIAN);
        state.put(this.sid);
        state.put((byte) mode);
        state.putLong(sequence);
        state.put((byte) (isResponse ? 1 : 0));

        int offset = 0;
        int blockIndex = 0;
        while (offset < input.length) {
            state.putInt(26, blockIndex);
            byte[] digest = sha256.digest(state.array());
            int blockSize = Math.min(32, input.length - offset);
            for (int i = 0; i < blockSize; i++) {
                output[offset + i] = (byte) (input[offset + i] ^ digest[i]);
            }
            offset += blockSize;
            blockIndex++;
        }
        return output;
    }

    private void startThread(Thread t) {
        t.setDaemon(true);
        this.threads.add(t);
        t.start();
    }

    private void fail(Throwable th) {
        if (this.running.get() && this.terminalError.compareAndSet(null, th)) {
            this.listener.fatal(th);
        }
    }

    public long getUploadedBytes() {
        return this.uploadedBytes.get();
    }

    public long getDownloadedBytes() {
        return this.downloadedBytes;
    }

    @Override
    public void close() {
        this.running.set(false);
        closeQuietly();
    }

    private void closeQuietly() {
        this.uploadQueue.clear();
        synchronized (this.downloadWakeup) {
            this.downloadWakeup.notifyAll();
        }
        if (this.localListener != null) {
            try {
                this.localListener.close();
            } catch (IOException ignored) {
            }
        }
        if (this.localSocket != null) {
            try {
                this.localSocket.close();
            } catch (IOException ignored) {
            }
        }
        synchronized (this.requestSockets) {
            for (Socket s : new ArrayList<>(this.requestSockets)) {
                try {
                    s.close();
                } catch (IOException ignored) {
                }
            }
            this.requestSockets.clear();
            this.idlePool.clear();
        }
        synchronized (this.threads) {
            for (Thread t : this.threads) {
                t.interrupt();
            }
        }
    }

    private void log(String msg) {
        this.listener.log(msg);
    }

    private void waitForDownload(long ms) {
        synchronized (this.downloadWakeup) {
            if (this.running.get()) {
                try {
                    this.downloadWakeup.wait(ms);
                } catch (InterruptedException unused) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
    }

    private static String concise(Throwable th) {
        String msg = th.getMessage();
        return msg == null ? th.getClass().getSimpleName() : msg;
    }

    private static int getInt(byte[] b, int off) {
        return ((b[off] & 0xFF) << 24) |
               ((b[off + 1] & 0xFF) << 16) |
               ((b[off + 2] & 0xFF) << 8) |
               (b[off + 3] & 0xFF);
    }

    private static void putInt(byte[] b, int off, int val) {
        b[off] = (byte) (val >>> 24);
        b[off + 1] = (byte) (val >>> 16);
        b[off + 2] = (byte) (val >>> 8);
        b[off + 3] = (byte) val;
    }

    private static int clamp(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }

    private static String hex(byte[] data, int off, int len) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) {
            sb.append(String.format("%02x", data[off + i] & 0xFF));
        }
        return sb.toString();
    }

    public static final class Response {
        public final int status;
        public final byte[] body;

        public Response(int status, byte[] body) {
            this.status = status;
            this.body = body;
        }
    }

    public static final class UploadFrame {
        public final long sequence;
        public final int clearLength;
        public final byte[] encrypted;

        public UploadFrame(long sequence, int clearLength, byte[] encrypted) {
            this.sequence = sequence;
            this.clearLength = clearLength;
            this.encrypted = encrypted;
        }
    }
}
