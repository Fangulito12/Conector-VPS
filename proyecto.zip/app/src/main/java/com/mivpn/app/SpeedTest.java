package com.mivpn.app;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;

/**
 * Mide la velocidad real bajando datos de relleno desde speedtest_server.py en el VPS, pasando
 * por el mismo SOCKS que usa el túnel (no por la conexión directa del teléfono). Por eso solo
 * tiene sentido mientras la VPN está conectada: así se mide lo mismo que experimentan las demás
 * apps del teléfono, no la velocidad de internet "a secas".
 */
public final class SpeedTest {

    public interface Listener {
        /** Se llama varias veces por segundo mientras baja, con la velocidad hasta el momento. */
        void onProgress(double mbps);
        /** Terminó de bajar todo el archivo de prueba. */
        void onDone(double mbps);
        void onError(String message);
        /** Se detuvo porque se pidió cancelar (no es un error). */
        void onCancelled();
    }

    /** La prueba mide durante este tiempo y termina sola, sin importar cuánto alcance a bajar. */
    /** Duración de la medición: 10 segundos. */
    private static volatile long durationNs = 10_000_000_000L;
    public static void setDurationSeconds(int seconds) { durationNs = Math.max(3, seconds) * 1_000_000_000L; }

    private static volatile Thread running;

    private SpeedTest() { }

    public static boolean isRunning() { return running != null; }

    public static void stop() {
        Thread t = running;
        if (t != null) t.interrupt();
    }

    public static void start(final android.app.Activity ui, final String host, final int socksPort,
                              final int speedtestPort, final int mb, final Listener l) {
        if (running != null) return;
        Thread t = new Thread(() -> {
            try {
                run(ui, host, socksPort, speedtestPort, mb, l);
            } finally {
                running = null;
            }
        }, "speedtest");
        running = t;
        t.start();
    }

    private static void run(android.app.Activity ui, String host, int socksPort, int speedtestPort,
                             int mb, Listener l) {
        HttpURLConnection c = null;
        // Vigía aparte: solo vigila la conexión inicial (hasta recibir la respuesta). Si por el
        // SOCKS (vía SSH) algo se cuelga sin respetar los tiempos de espera normales, esto fuerza
        // el corte igual, para que el botón no quede pegado. Una vez que empieza a bajar, el
        // tiempo lo controla durationNs, así una conexión lenta ya no se corta antes de medir.
        final java.util.Timer watchdog = new java.util.Timer(true);
        try {
            URL url = new URL("https://speed.cloudflare.com/__down?bytes=" + ((long) mb * 1024 * 1024));
            Proxy proxy = new Proxy(Proxy.Type.SOCKS, new InetSocketAddress("127.0.0.1", socksPort));
            c = (HttpURLConnection) url.openConnection(proxy);
            c.setConnectTimeout(8_000);
            c.setReadTimeout(15_000);
            // Cada prueba puede apuntar a un destino distinto dentro del mismo túnel SOCKS; sin
            // esto, Java puede reutilizar una conexión ya "amarrada" a un destino anterior y
            // quedarse esperando datos que nunca van a llegar.
            c.setRequestProperty("Connection", "close");

            final HttpURLConnection cc = c;
            watchdog.schedule(new java.util.TimerTask() {
                @Override public void run() { cc.disconnect(); }
            }, 20_000);

            int code = c.getResponseCode();
            watchdog.cancel();
            if (code != 200) {
                final String msg = "El servidor de prueba respondió " + code;
                ui.runOnUiThread(() -> l.onError(msg));
                return;
            }

            InputStream in = c.getInputStream();
            byte[] buf = new byte[64 * 1024];
            long total = 0;
            long start = System.nanoTime();
            long lastReport = start;
            int n;
            while ((n = in.read(buf)) >= 0) {
                if (Thread.currentThread().isInterrupted()) {
                    ui.runOnUiThread(l::onCancelled);
                    return;
                }
                total += n;
                long now = System.nanoTime();
                if (now - lastReport > 200_000_000L) {   // cada ~200 ms
                    lastReport = now;
                    double mbps = mbps(total, now - start);
                    ui.runOnUiThread(() -> l.onProgress(mbps));
                }
                if (now - start >= durationNs) break;   // ya midió lo suficiente
            }
            double finalMbps = mbps(total, System.nanoTime() - start);
            ui.runOnUiThread(() -> l.onDone(finalMbps));
        } catch (final java.io.InterruptedIOException e) {
            ui.runOnUiThread(l::onCancelled);
        } catch (final Exception e) {
            final String msg = friendly(e);
            ui.runOnUiThread(() -> l.onError(msg));
        } finally {
            watchdog.cancel();
            if (c != null) c.disconnect();
        }
    }

    private static double mbps(long bytes, long nanos) {
        if (nanos <= 0) return 0;
        double seconds = nanos / 1_000_000_000.0;
        double bitsPerSecond = (bytes * 8.0) / seconds;
        return bitsPerSecond / 1_000_000.0;
    }

    private static String friendly(Exception e) {
        if (e instanceof java.net.SocketTimeoutException) return "El servidor de prueba no respondió a tiempo.";
        String m = e.getMessage();
        String low = m != null ? m.toLowerCase(java.util.Locale.ROOT) : "";
        boolean refused = e instanceof java.net.ConnectException || low.contains("refused");
        if (refused) return "No se pudo llegar al servidor de prueba (¿está encendido?).";
        if (low.contains("closed") || low.contains("reset")) return "La prueba tardó demasiado y se cortó sola.";
        return "No se pudo completar la prueba de velocidad" + (m != null && !m.isEmpty() ? ": " + m : ".");
    }
}
