package com.mivpn.app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Oculta IP, puerto, usuario e ID (HWID) en cualquier texto que vaya al registro. */
public final class LogMask {
    public static final String MASK = "\u25CF\u25CF\u25CF\u25CF";

    private static final Pattern IPV4 = Pattern.compile("\\b\\d{1,3}(?:\\.\\d{1,3}){3}(?::\\d{1,5})?\\b");
    private static final Pattern HWID = Pattern.compile("\\bhw[0-9a-fA-F]{8,}\\b");
    private static final Pattern HWID_KEY = Pattern.compile("\\b[0-9A-F]{4}(?:-[0-9A-F]{4}){3}\\b");
    private static volatile List<Pattern> secrets = new ArrayList<>();

    private LogMask() {}

    /** Valores concretos a ocultar (servidor, usuario, HWID...). Los de menos de 3 caracteres se ignoran. */
    public static void setSecrets(String... values) {
        List<String> list = new ArrayList<>();
        for (String v : values) {
            if (v == null) continue;
            v = v.trim();
            if (v.length() >= 3 && !list.contains(v)) list.add(v);
        }
        Collections_sortByLengthDesc(list);
        List<Pattern> ps = new ArrayList<>();
        for (String v : list) {
            ps.add(Pattern.compile(Pattern.quote(v) + "(?::\\d{1,5})?", Pattern.CASE_INSENSITIVE));
        }
        secrets = ps;
    }

    public static String mask(String s) {
        if (s == null || s.isEmpty()) return s;
        for (Pattern p : secrets) s = p.matcher(s).replaceAll(Matcher.quoteReplacement(MASK));
        s = IPV4.matcher(s).replaceAll(Matcher.quoteReplacement(MASK));
        s = HWID.matcher(s).replaceAll(Matcher.quoteReplacement(MASK));
        s = HWID_KEY.matcher(s).replaceAll(Matcher.quoteReplacement(MASK));
        return s;
    }

    private static void Collections_sortByLengthDesc(List<String> l) {
        String[] a = l.toArray(new String[0]);
        Arrays.sort(a, new Comparator<String>() {
            @Override public int compare(String x, String y) { return y.length() - x.length(); }
        });
        l.clear();
        l.addAll(Arrays.asList(a));
    }
}
