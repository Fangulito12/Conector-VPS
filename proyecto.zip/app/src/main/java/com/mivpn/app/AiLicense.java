package com.mivpn.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Licencia de IA por dispositivo. Es un archivo que contiene la llave de Gemini cifrada con el
 * HWID del teléfono (PBKDF2-HMAC-SHA256 + AES-256-GCM), generado con tools/generar_licencia_ia.py.
 * Solo se abre en el dispositivo cuyo HWID se usó al generarlo. Así ningún APK lleva la llave.
 *
 * Formato: "CONECTAIA1:" + Base64( sal[16] + iv[12] + cifrado+etiqueta ).
 * El contenido descifrado es JSON: {"key": "...", "exp": segundos_epoch o 0, "max": consultas o 0, "id": "..."}.
 */
public final class AiLicense {
    public static final String PREFIX = "CONECTAIA1:";
    private static final int ITER = 150_000;
    private static final byte[] AAD = "CONECTAIA1".getBytes(StandardCharsets.US_ASCII);
    private static final String PREFS = "ai_license";

    private AiLicense() { }

    public static boolean looks(String text) {
        return text != null && text.trim().startsWith(PREFIX);
    }

    /** Descifra con el HWID de este dispositivo y guarda la licencia. Lanza excepción si no corresponde. */
    public static void activate(Context ctx, String text, String hwid) throws Exception {
        JSONObject o = new JSONObject(decrypt(text, hwid));
        String key = o.optString("key", "").trim();
        if (!key.matches("[A-Za-z0-9_\\-]{20,100}")) throw new GeneralSecurityException("Licencia inv\u00e1lida");
        String id = o.optString("id", "");
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        // Si se vuelve a cargar la misma licencia, el contador de consultas no se reinicia.
        boolean same = !id.isEmpty() && id.equals(sp.getString("id", ""));
        sp.edit()
                .putString("key", key)
                .putLong("exp", o.optLong("exp", 0))
                .putInt("max", o.optInt("max", 0))
                .putString("id", id)
                .putInt("used", same ? sp.getInt("used", 0) : 0)
                .apply();
    }

    /** Llave de la licencia vigente, o "" si no hay o ya venció. */
    public static String key(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (expired(sp)) return "";
        return sp.getString("key", "");
    }

    /** Cuenta una consulta. Devuelve un mensaje si ya no se puede consultar, o null si todo bien. */
    public static String consume(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (sp.getString("key", "").isEmpty()) return null;   // sin licencia: no hay l\u00edmite que contar
        if (expired(sp)) return "Tu licencia de IA venci\u00f3.";
        int max = sp.getInt("max", 0);
        int used = sp.getInt("used", 0);
        if (max > 0 && used >= max) return "Llegaste al l\u00edmite de " + max + " consultas de tu licencia.";
        sp.edit().putInt("used", used + 1).apply();
        return null;
    }

    private static boolean expired(SharedPreferences sp) {
        long exp = sp.getLong("exp", 0);
        return exp > 0 && System.currentTimeMillis() / 1000L > exp;
    }

    private static String decrypt(String text, String hwid) throws GeneralSecurityException {
        byte[] all;
        try {
            all = Base64.getDecoder().decode(text.trim().substring(PREFIX.length()));
        } catch (IllegalArgumentException e) {
            throw new GeneralSecurityException("Archivo da\u00f1ado");
        }
        if (all.length < 16 + 12 + 16) throw new GeneralSecurityException("Archivo da\u00f1ado");
        byte[] salt = new byte[16];
        byte[] iv = new byte[12];
        System.arraycopy(all, 0, salt, 0, 16);
        System.arraycopy(all, 16, iv, 0, 12);
        PBEKeySpec spec = new PBEKeySpec(hwid.trim().toLowerCase(java.util.Locale.ROOT).toCharArray(), salt, ITER, 256);
        try {
            byte[] k = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(k, "AES"), new GCMParameterSpec(128, iv));
            c.updateAAD(AAD);
            return new String(c.doFinal(all, 28, all.length - 28), StandardCharsets.UTF_8);
        } finally {
            spec.clearPassword();
        }
    }
}
