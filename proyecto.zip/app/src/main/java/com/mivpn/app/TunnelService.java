package com.mivpn.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.TrafficStats;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.util.Base64;

import com.mivpn.app.bhttp.BhttpBridge;
import com.trilead.ssh2.Connection;
import com.trilead.ssh2.ConnectionMonitor;
import com.trilead.ssh2.DynamicPortForwarder;
import com.trilead.ssh2.ServerHostKeyVerifier;

import hev.htproxy.TProxyService;

import java.io.File;
import java.io.FileOutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.concurrent.CountDownLatch;

/**
 * Cadena completa:  BHTTP -> SSH (autenticado con la llave del dispositivo = HWID)
 *                   -> SOCKS5 local -> hev-socks5-tunnel -> interfaz VPN de Android.
 * El DNS lo resuelve el servidor (mapdns de hev), no hace falta ningún proxy DNS aparte.
 */
public final class TunnelService extends VpnService {
    public static final String ACTION_START = "com.mivpn.app.START";
    public static final String ACTION_STOP = "com.mivpn.app.STOP";
    public static final String EXTRA_HOST = "host";
    public static final String EXTRA_PORT = "port";
    public static final String EXTRA_USER = "user";
    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_SPEED = "speed";          // normal | rapido | maximo
    public static final String EXTRA_AUTO = "auto";            // reconexión automática
    public static final String EXTRA_UDP = "udp";              // BadVPN activado
    public static final String EXTRA_UDPGW_PORT = "udpgwPort"; // puerto de badvpn-udpgw en el VPS
    public static final String MODE_RUFU = "rufu";   // usuario = contraseña = HWID
    public static final String MODE_KEY = "key";     // llave de dispositivo (más seguro)

    public static final int ST_IDLE = 0, ST_CONNECTING = 1, ST_CONNECTED = 2;

    public interface Listener {
        void onState(int state, String text);
        void onLog(String line);
    }

    public static volatile Listener listener;
    public static volatile long baseRx = -1, baseTx = -1;   // contadores al iniciar la sesión
    public static volatile int activeSocksPort = -1;        // puerto SOCKS del túnel activo, o -1 si no hay
    public static volatile int state = ST_IDLE;
    public static volatile String stateText = "Desconectado";
    private static final ArrayDeque<String> LOGS = new ArrayDeque<>();
    private static final String CREDIT = "by: el_tioNel";

    public static void appendLog(String line) { log(line); }

    public static String logsSnapshot() {
        synchronized (LOGS) {
            StringBuilder sb = new StringBuilder(CREDIT).append('\n');
            for (String l : LOGS) sb.append(l).append('\n');
            return sb.toString();
        }
    }

    private static final String CHANNEL = "conecta_vpn";
    private static final int NOTIF_ID = 1;

    private volatile boolean desired;
    private volatile Thread supervisor;
    private volatile CountDownLatch failureSignal = new CountDownLatch(1);
    private volatile String failReason;
    private volatile int gen;                 // número de intento: ignora avisos de intentos viejos
    private volatile boolean noRetry;         // caída que no se arregla reintentando
    private volatile boolean hostKeyRejected;
    private boolean autoReconnect = true;
    private static final int MAX_ATTEMPTS = 40;

    /** Error que no se arregla reintentando (HWID no autorizado, etc.). */
    private static final class FatalException extends Exception {
        FatalException(String m) { super(m); }
    }

    private String host, user, mode;
    private int upSlots = 16, downSlots = 32, mtu = 8500, udpgwPort = 7300;
    private boolean useUdp;
    private SocksFront front;
    private int port;

    private BhttpBridge bridge;
    private Connection ssh;
    private DynamicPortForwarder socks;
    private ParcelFileDescriptor tun;
    private boolean tproxyStarted;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            return handleStart(intent);
        } catch (Throwable t) {
            log("No se pudo iniciar el servicio: " + concise(t));
            desired = false;
            setState(ST_IDLE, "Error al iniciar");
            try { stopForegroundCompat(); } catch (Throwable ignored) { }
            stopSelf();
            return START_NOT_STICKY;
        }
    }

    private int handleStart(Intent intent) {
        if (intent == null) return START_NOT_STICKY;

        if (ACTION_STOP.equals(intent.getAction())) {
            desired = false;
            failureSignal.countDown();
            Thread sv = supervisor;
            if (sv != null) sv.interrupt();
            teardown();
            setState(ST_IDLE, "Desconectado");
            stopForegroundCompat();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(intent.getAction())) return START_NOT_STICKY;

        startForegroundCompat();
        if (supervisor != null && supervisor.isAlive()) return START_NOT_STICKY;

        host = intent.getStringExtra(EXTRA_HOST);
        port = intent.getIntExtra(EXTRA_PORT, 22);
        user = intent.getStringExtra(EXTRA_USER);
        mode = intent.getStringExtra(EXTRA_MODE);
        String speed = intent.getStringExtra(EXTRA_SPEED);
        if ("normal".equals(speed)) { upSlots = 1; downSlots = 16; mtu = 1500; }
        else if ("rapido".equals(speed)) { upSlots = 4; downSlots = 24; mtu = 1500; }
        else { upSlots = 16; downSlots = 32; mtu = 8500; }
        if (!"normal".equals(speed) && !"rapido".equals(speed) && lowRam()) {
            // Celulares con poca RAM: el modo Máximo usa muchos buffers y el sistema termina
            // cerrando la app cuando se abre otra pesada (Facebook, etc.). Se baja a Rápido.
            upSlots = 4; downSlots = 24; mtu = 1500;
            log("Poca memoria RAM: se usa el modo R\u00e1pido en lugar de M\u00e1ximo");
        }
        autoReconnect = intent.getBooleanExtra(EXTRA_AUTO, true);
        useUdp = intent.getBooleanExtra(EXTRA_UDP, false);
        udpgwPort = intent.getIntExtra(EXTRA_UDPGW_PORT, 7300);
        if (udpgwPort < 1 || udpgwPort > 65535) udpgwPort = 7300;
        LogMask.setSecrets(host, user, DeviceIdentity.rufuHwid(this));

        desired = true;
        noRetry = false;
        hostKeyRejected = false;
        failReason = null;
        failureSignal = new CountDownLatch(1);
        supervisor = new Thread(this::supervise, "conecta-supervisor");
        supervisor.start();
        return START_NOT_STICKY;
    }

    /** True si el celular tiene 4 GB de RAM o menos (o Android lo marca como de poca memoria). */
    private boolean lowRam() {
        try {
            android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (am == null) return false;
            if (am.isLowRamDevice()) return true;
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return mi.totalMem > 0 && mi.totalMem < 4L * 1024 * 1024 * 1024;
        } catch (Throwable t) {
            return false;
        }
    }

    @Override
    public void onRevoke() {
        // El usuario quitó la VPN desde los ajustes de Android.
        noRetry = true;
        fail("VPN revocada desde Android");
    }

    @Override
    public void onDestroy() {
        desired = false;
        failureSignal.countDown();
        teardown();
        if (state != ST_IDLE) setState(ST_IDLE, "Desconectado");
        super.onDestroy();
    }

    // ------------------------------------------------------------------ flujo principal

    private void supervise() {
        String endText = "Desconectado";
        String pendingEnd = "Desconectado";   // se usa solo si termina por fallo, no por cancelar
        int attempt = 0;                 // fallos seguidos
        boolean everConnected = false;
        try {
            while (desired) {
                failReason = null;
                failureSignal = new CountDownLatch(1);
                try {
                    setState(ST_CONNECTING, attempt == 0 ? "Conectando\u2026" : "Reconectando\u2026 (intento " + attempt + ")");
                    establish();
                    setState(ST_CONNECTED, "Conectado");
                    log(everConnected ? "VPN restablecida" : "VPN activa");
                    everConnected = true;
                    attempt = 0;
                    failureSignal.await();
                    if (!desired) break;
                    pendingEnd = "Conexi\u00f3n perdida";
                    log("Conexi\u00f3n perdida: " + failReason);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (FatalException e) {
                    if (desired) { endText = "Error al conectar"; log("Error: " + concise(e)); }
                    break;
                } catch (Throwable e) {
                    if (!desired) break;
                    if (hostKeyRejected) {
                        endText = "Error al conectar";
                        log("Error: la huella del servidor cambi\u00f3. No se reintenta por seguridad.");
                        break;
                    }
                    pendingEnd = "Error al conectar";
                    log("Error: " + concise(e));
                }

                // Llegamos aqu\u00ed por una ca\u00edda o un fallo recuperable.
                teardown();
                if (!desired || noRetry || !autoReconnect) {
                    if (desired) endText = pendingEnd;
                    break;
                }
                if (!everConnected) {                       // primera conexi\u00f3n fallida: mostrar el error, sin reintentar
                    endText = pendingEnd;
                    break;
                }
                attempt++;
                if (attempt > MAX_ATTEMPTS) {
                    endText = "Reconexi\u00f3n fallida";
                    log("No se pudo reconectar tras varios intentos.");
                    break;
                }
                int wait = attempt == 1 ? 2 : attempt == 2 ? 3 : attempt == 3 ? 5 : attempt == 4 ? 8 : attempt == 5 ? 12 : 15;
                setState(ST_CONNECTING, "Reconectando en " + wait + " s\u2026 (intento " + attempt + ")");
                if (!sleepWhileDesired(wait * 1000)) break;
                waitForNetwork(60);
            }
        } finally {
            boolean wasDesired = desired;
            desired = false;
            teardown();
            setState(ST_IDLE, endText);
            supervisor = null;
            if (wasDesired) {
                stopForegroundCompat();
                stopSelf();
            }
        }
    }

    /** Espera ms milisegundos; devuelve false si el usuario cancel\u00f3 mientras tanto. */
    private boolean sleepWhileDesired(int ms) {
        try {
            for (int t = 0; t < ms && desired; t += 250) Thread.sleep(250);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
        return desired;
    }

    /** Espera (hasta maxSec) a que el tel\u00e9fono tenga alguna red con internet. */
    private void waitForNetwork(int maxSec) {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        boolean logged = false;
        for (int i = 0; i < maxSec * 4 && desired; i++) {
            if (hasInternet(cm)) return;
            if (!logged) { logged = true; log("Sin red. Esperando conexi\u00f3n\u2026"); }
            try { Thread.sleep(250); } catch (InterruptedException e) { Thread.currentThread().interrupt(); return; }
        }
    }

    private static boolean hasInternet(ConnectivityManager cm) {
        try {
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                if (nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        && !nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return true;
            }
            return false;
        } catch (Throwable ignored) {
            return true;   // si no se puede consultar, se intenta igual
        }
    }

    private void establish() throws Exception {
        final int myGen = ++gen;
        hostKeyRejected = false;
        log("Iniciando BHTTP");
        String resolved = InetAddress.getByName(host).getHostAddress();

        bridge = new BhttpBridge(resolved, port, new BhttpBridge.Listener() {
            @Override public void log(String str) { /* detalle interno del bridge: se omite */ }
            @Override public void fatal(Throwable th) { fail(myGen, concise(th)); }
        }, new BhttpBridge.SocketProtector() {
            @Override public boolean protect(Socket socket) { return TunnelService.this.protect(socket); }
        }, upSlots, downSlots);
        log("Velocidad: subida " + upSlots + " / bajada " + downSlots);

        int bridgePort = bridge.start();
        log("Sesión BHTTP lista");

        ssh = new Connection("127.0.0.1", bridgePort);
        ssh.addConnectionMonitor(new ConnectionMonitor() {
            @Override public void connectionLost(Throwable reason) { fail(myGen, concise(reason)); }
        });

        log("Conectando SSH");
        ssh.connect(new ServerHostKeyVerifier() {
            @Override
            public boolean verifyServerHostKey(String hostname, int p, String algo, byte[] key) throws Exception {
                return checkHostKey(algo, key);
            }
        }, 10_000, 20_000);

        if (MODE_RUFU.equals(mode)) {
            String hw = DeviceIdentity.rufuHwid(this);
            if (hw == null) throw new FatalException("Android no entreg\u00f3 el ID del dispositivo");
            log("Autenticando con HWID (usuario y contraseña)");
            boolean ok = ssh.authenticateWithPassword(hw, hw);
            if (!ok) throw new FatalException("HWID no registrado en el VPS. Crea el usuario con el comando de la app.");
        } else {
            log("Autenticando con la llave de este dispositivo");
            boolean ok = ssh.authenticateWithPublicKey(user, DeviceIdentity.keyPair(this));
            if (!ok) throw new FatalException("Dispositivo no autorizado. Registra tu HWID en el VPS.");
        }
        log("Dispositivo autorizado");

        int socksPort = freePort();
        socks = ssh.createDynamicPortForwarder(
                new InetSocketAddress(InetAddress.getByName("127.0.0.1"), socksPort));
        activeSocksPort = socksPort;   // así la prueba de velocidad puede usar el mismo túnel

        int hevPort = socksPort;
        if (useUdp) {
            front = new SocksFront(socksPort, udpgwPort, new SocksFront.Logger() {
                @Override public void log(String line) { TunnelService.log(line); }
            });
            hevPort = front.start();
            log("Modo juegos: UDP por BadVPN");
        }

        startTun(hevPort, useUdp);
    }

    /** Crea la interfaz VPN y arranca hev-socks5-tunnel apuntando al SOCKS5 local. */
    private void startTun(int hevPort, boolean udp) throws Exception {
        VpnService.Builder b = new VpnService.Builder();
        b.setSession("Conecta HWID");
        b.setMtu(mtu);
        b.addAddress("198.18.0.1", 32);
        b.addRoute("0.0.0.0", 0);
        b.addDnsServer(udp ? "8.8.8.8" : "198.18.0.2");
        try { b.addDisallowedApplication(getPackageName()); } catch (Throwable ignored) { }
        try { b.addRoute("::", 0); } catch (Throwable ignored) { /* evita fugas por IPv6 */ }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) b.setMetered(false);
        tun = b.establish();
        if (tun == null) throw new Exception("No se pudo crear la VPN (permiso denegado)");

        File cfg = new File(getCacheDir(), "hev.yml");
        String yml = "tunnel:\n"
                + "  mtu: " + mtu + "\n"
                + "  ipv4: 198.18.0.1\n"
                + "socks5:\n"
                + "  port: " + hevPort + "\n"
                + "  address: 127.0.0.1\n"
                + (udp ? "  udp: 'udp'\n" : "")
                + (udp ? "" : "mapdns:\n"
                + "  address: 198.18.0.2\n"
                + "  port: 53\n"
                + "  network: 100.64.0.0\n"
                + "  netmask: 240.0.0.0\n"
                + "  cache-size: 10000\n")
                + "misc:\n"
                + "  log-level: warn\n";
        try (FileOutputStream fo = new FileOutputStream(cfg)) {
            fo.write(yml.getBytes(StandardCharsets.UTF_8));
        }
        log("Iniciando túnel");
        boolean started = TProxyService.TProxyStartService(cfg.getAbsolutePath(), tun.getFd());
        if (!started) throw new Exception("El túnel nativo no arrancó");
        tproxyStarted = true;
    }

    /** Primera vez guarda la huella del servidor; si luego cambia, rechaza (protege contra MITM). */
    private boolean checkHostKey(String algo, byte[] key) throws Exception {
        byte[] h = MessageDigest.getInstance("SHA-256").digest(key);
        String fp = algo + ":" + Base64.encodeToString(h, Base64.NO_WRAP);
        SharedPreferences sp = getSharedPreferences("hostkeys", MODE_PRIVATE);
        String id = host + ":" + port;
        String saved = sp.getString(id, null);
        if (saved == null) {
            sp.edit().putString(id, fp).apply();
            log("Huella del servidor guardada (primera conexión)");
            return true;
        }
        if (saved.equals(fp)) return true;
        hostKeyRejected = true;
        log("\u00a1La huella del servidor cambi\u00f3! Conexi\u00f3n rechazada.");
        return false;
    }

    private synchronized void teardown() {
        activeSocksPort = -1;
        if (tproxyStarted) {
            tproxyStarted = false;
            try { TProxyService.TProxyStopService(); } catch (Throwable ignored) { }
        }
        ParcelFileDescriptor t = tun; tun = null;
        if (t != null) try { t.close(); } catch (Exception ignored) { }
        SocksFront fr = front; front = null;
        if (fr != null) try { fr.close(); } catch (Throwable ignored) { }
        DynamicPortForwarder d = socks; socks = null;
        if (d != null) try { d.close(); } catch (Exception ignored) { }
        Connection c = ssh; ssh = null;
        if (c != null) try { c.close(); } catch (Exception ignored) { }
        BhttpBridge br = bridge; bridge = null;
        if (br != null) try { br.close(); } catch (Exception ignored) { }
    }

    private void fail(String reason) { fail(gen, reason); }

    private void fail(int g, String reason) {
        if (g != gen || !desired || failReason != null) return;
        failReason = reason == null ? "desconocido" : reason;
        failureSignal.countDown();
    }

    // ------------------------------------------------------------------ utilidades

    private static void setState(int s, String text) {
        if (s == ST_CONNECTING && state == ST_IDLE) {
            baseRx = TrafficStats.getUidRxBytes(Process.myUid());
            baseTx = TrafficStats.getUidTxBytes(Process.myUid());
        }
        state = s;
        stateText = text;
        Listener l = listener;
        if (l != null) l.onState(s, text);
    }

    public static void clearLogs() {
        synchronized (LOGS) { LOGS.clear(); }
    }

    private static void log(String raw) {
        String line = LogMask.mask(raw);   // IP, puerto, usuario e ID nunca llegan al registro
        synchronized (LOGS) {
            LOGS.addLast(line);
            while (LOGS.size() > 200) LOGS.removeFirst();
        }
        Listener l = listener;
        if (l != null) l.onLog(line);
    }

    private static int freePort() throws Exception {
        try (ServerSocket s = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))) {
            return s.getLocalPort();
        }
    }

    private static String concise(Throwable t) {
        if (t == null) return "error";
        return t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
    }

    private void startForegroundCompat() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Conexión VPN", NotificationManager.IMPORTANCE_LOW));
        }
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder nb = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Notification n = nb.setContentTitle("Conecta HWID")
                .setContentText("VPN en uso")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(open)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED);
            } catch (Throwable first) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            }
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void stopForegroundCompat() {
        stopForeground(true);
    }
}
