package com.mivpn.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.os.PowerManager;
import android.net.TrafficStats;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.util.Base64;

import com.mivpn.app.bhttp.BhttpBridge;
import com.trilead.ssh2.Connection;
import com.trilead.ssh2.ConnectionMonitor;
import com.trilead.ssh2.DynamicPortForwarder;
import com.trilead.ssh2.ServerHostKeyVerifier;

import hev.htproxy.TProxyService;

import java.io.File;
import java.io.FileOutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.concurrent.CountDownLatch;

/**
 * Cadena completa:  BHTTP -> SSH (autenticado con la llave del dispositivo = HWID)
 *                   -> SOCKS5 local -> hev-socks5-tunnel -> interfaz VPN de Android.
 * El DNS lo resuelve el servidor (mapdns de hev), no hace falta ningún proxy DNS aparte.
 */
public final class TunnelService extends VpnService {
    public static final String ACTION_START = "com.mivpn.app.START";
    public static final String ACTION_STOP = "com.mivpn.app.STOP";
    public static final String EXTRA_HOST = "host";
    public static final String EXTRA_PORT = "port";
    public static final String EXTRA_USER = "user";
    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_SPEED = "speed";          // normal | rapido | maximo | manual
    public static final String EXTRA_UP = "manUp";            // solo en modo manual: subidas en paralelo
    public static final String EXTRA_DOWN = "manDown";        // solo en modo manual: descargas en paralelo
    public static final String EXTRA_BATCH = "manBatch";      // solo en modo manual: lote de descarga
    public static final String EXTRA_CHUNK = "manChunk";      // solo en modo manual: tamaño de registro
    public static final String EXTRA_MTU = "manMtu";          // solo en modo manual: MTU de la interfaz VPN (el Máximo de la 1.19 usaba 8500)
    public static final String EXTRA_LIVE = "manLive";        // Auto+: las conexiones pasan a ser el maximo y se ajustan en vivo
    public static final String EXTRA_AUTO = "auto";            // reconexión automática
    public static final String EXTRA_UDP = "udp";              // BadVPN activado
    public static final String EXTRA_UDPGW_PORT = "udpgwPort"; // puerto de badvpn-udpgw en el VPS
    public static final String EXTRA_DNS = "dns"; // DNS manual (hasta 2 IPv4 separadas por coma); solo se usa con BadVPN
    public static final String EXTRA_SHARE_PORT = "sharePort"; // puerto del proxy para compartir la conexión (0 = apagado)
    public static final String MODE_RUFU = "rufu";   // usuario = contraseña = HWID
    public static final String MODE_KEY = "key";     // llave de dispositivo (más seguro)

    public static final int ST_IDLE = 0, ST_CONNECTING = 1, ST_CONNECTED = 2;

    public interface Listener {
        void onState(int state, String text);
        void onLog(String line);
    }

    public static volatile Listener listener;
    public static volatile long baseRx = -1, baseTx = -1;   // contadores al iniciar la sesión
    public static volatile int activeSocksPort = -1;        // puerto SOCKS del túnel activo, o -1 si no hay
    public static volatile int state = ST_IDLE;
    public static volatile String stateText = "Desconectado";
    private static final ArrayDeque<String> LOGS = new ArrayDeque<>();
    private static final String CREDIT = "by: el_tioNel | v" + BuildConfig.VERSION_NAME;

    public static void appendLog(String line) { log(line); }

    public static String logsSnapshot() {
        synchronized (LOGS) {
            StringBuilder sb = new StringBuilder(CREDIT).append('\n');
            for (String l : LOGS) sb.append(l).append('\n');
            return sb.toString();
        }
    }

    private static final String CHANNEL = "conecta_vpn";
    private static final int NOTIF_ID = 1;

    private volatile boolean desired;
    private volatile Thread supervisor;
    private volatile CountDownLatch failureSignal = new CountDownLatch(1);
    private volatile String failReason;
    private volatile int gen;                 // número de intento: ignora avisos de intentos viejos
    private volatile boolean noRetry;         // caída que no se arregla reintentando
    private volatile boolean hostKeyRejected;
    private boolean autoReconnect = true;
    private static final int MAX_ATTEMPTS = 40;

    /** Error que no se arregla reintentando (HWID no autorizado, etc.). */
    private static final class FatalException extends Exception {
        FatalException(String m) { super(m); }
    }

    private String host, user, mode;
    private int upSlots = 16, downSlots = 32, mtu = 8500, udpgwPort = 7300;
    private boolean useUdp;
    private SocksFront front;
    private SharedProxy sharedProxy;
    private int sharePort;
    private String dnsServers = "8.8.8.8";
    private int port;

    private BhttpBridge bridge;
    private Connection ssh;
    private DynamicPortForwarder socks;
    private ParcelFileDescriptor tun;
    private volatile boolean tproxyStarted;

    // Estabilidad: la CPU y el wifi no se duermen mientras la VPN está activa, y un cambio de red
    // (wifi <-> datos) reconecta de inmediato en vez de esperar a que el socket falle por timeout.
    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;
    private ConnectivityManager.NetworkCallback netCallback;
    private volatile Network lastNet;
    private volatile boolean netLost;
    private static volatile long lastSlowReconnect = -1_000_000L;   // última reconexión por lentitud (elapsedRealtime)
    private volatile long connectedSince = Long.MAX_VALUE / 2;   // instante (elapsedRealtime) en que quedó conectada
    private int batchOpt = 8;     // lote de descarga (8 salvo en modo Manual)
    private boolean liveOpt;   // Auto+
    private int chunkOpt = 0;     // tope del tamaño de registro (0 = el que calibra el puente)

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            return handleStart(intent);
        } catch (Throwable t) {
            log("No se pudo iniciar el servicio: " + concise(t));
            desired = false;
            setState(ST_IDLE, "Error al iniciar");
            try { stopForegroundCompat(); } catch (Throwable ignored) { }
            stopSelf();
            return START_NOT_STICKY;
        }
    }

    private int handleStart(Intent intent) {
        if (intent == null) return START_NOT_STICKY;

        if (ACTION_STOP.equals(intent.getAction())) {
            desired = false;
            failureSignal.countDown();
            Thread sv = supervisor;
            if (sv != null) sv.interrupt();
            teardown();
            releaseKeepAlive();
            setState(ST_IDLE, "Desconectado");
            stopForegroundCompat();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(intent.getAction())) return START_NOT_STICKY;

        startForegroundCompat();
        if (supervisor != null && supervisor.isAlive()) return START_NOT_STICKY;

        host = intent.getStringExtra(EXTRA_HOST);
        port = intent.getIntExtra(EXTRA_PORT, 22);
        user = intent.getStringExtra(EXTRA_USER);
        mode = intent.getStringExtra(EXTRA_MODE);
        String speed = intent.getStringExtra(EXTRA_SPEED);
        batchOpt = 8;
        chunkOpt = 0;
        liveOpt = false;
        if ("normal".equals(speed)) { upSlots = 1; downSlots = 16; mtu = 1500; }
        else if ("rapido".equals(speed)) { upSlots = 4; downSlots = 24; mtu = 1500; }
        else if ("manual".equals(speed)) {
            upSlots = Math.max(1, Math.min(64, intent.getIntExtra(EXTRA_UP, 4)));
            downSlots = Math.max(1, Math.min(128, intent.getIntExtra(EXTRA_DOWN, 8)));
            batchOpt = Math.max(1, Math.min(32, intent.getIntExtra(EXTRA_BATCH, 8)));
            chunkOpt = Math.max(64, Math.min(9000, intent.getIntExtra(EXTRA_CHUNK, 1399)));
            liveOpt = intent.getBooleanExtra(EXTRA_LIVE, false);
            mtu = Math.max(576, Math.min(9000, intent.getIntExtra(EXTRA_MTU, 1500)));
        }
        else { upSlots = 16; downSlots = 32; mtu = 8500; }
        if (!"normal".equals(speed) && !"rapido".equals(speed) && !"manual".equals(speed) && lowRam()) {
            // Celulares con poca RAM: el modo Máximo usa muchos buffers y el sistema termina
            // cerrando la app cuando se abre otra pesada (Facebook, etc.). Se baja a Rápido.
            upSlots = 4; downSlots = 24; mtu = 1500;
            log("Poca memoria RAM: se usa el modo R\u00e1pido en lugar de M\u00e1ximo");
        }
        // Tope de conexiones paralelas. Con 32/16 el servidor/la red dejaba de responder a las conexiones
        // nuevas (timeouts de 8 s). Otra app con el mismo servidor trabaja con 8 de bajada y 4 de subida.
        if (!"manual".equals(speed)) {   // en Manual manda lo que el usuario puso
            upSlots = Math.min(upSlots, 4);
            downSlots = Math.min(downSlots, 8);
        }
        autoReconnect = intent.getBooleanExtra(EXTRA_AUTO, true);
        useUdp = intent.getBooleanExtra(EXTRA_UDP, false);
        udpgwPort = intent.getIntExtra(EXTRA_UDPGW_PORT, 7300);
        if (udpgwPort < 1 || udpgwPort > 65535) udpgwPort = 7300;
        String dnsExtra = intent.getStringExtra(EXTRA_DNS);
        if (dnsExtra != null && !dnsExtra.trim().isEmpty()) dnsServers = dnsExtra.trim();
        sharePort = intent.getIntExtra(EXTRA_SHARE_PORT, 0);
        if (sharePort < 1024 || sharePort > 65535) sharePort = 0;
        LogMask.setSecrets(host, user, DeviceIdentity.rufuHwid(this));

        desired = true;
        acquireKeepAlive();
        noRetry = false;
        hostKeyRejected = false;
        failReason = null;
        failureSignal = new CountDownLatch(1);
        supervisor = new Thread(this::supervise, "conecta-supervisor");
        supervisor.start();
        return START_NOT_STICKY;
    }

    /** True si el celular tiene 4 GB de RAM o menos (o Android lo marca como de poca memoria). */
    private boolean lowRam() {
        try {
            android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (am == null) return false;
            if (am.isLowRamDevice()) return true;
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return mi.totalMem > 0 && mi.totalMem < 4L * 1024 * 1024 * 1024;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Mantiene despierta la CPU/wifi y vigila los cambios de red mientras la VPN está activa. */
    private synchronized void acquireKeepAlive() {
        try {
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null) {
                    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "conecta:vpn");
                    wakeLock.setReferenceCounted(false);
                }
            }
            if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire();
        } catch (Throwable t) { log("WakeLock no disponible: " + concise(t)); }
        try {
            if (wifiLock == null) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                if (wm != null) {
                    int mode = Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                                                            : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
                    wifiLock = wm.createWifiLock(mode, "conecta:vpn");
                    wifiLock.setReferenceCounted(false);
                }
            }
            if (wifiLock != null && !wifiLock.isHeld()) wifiLock.acquire();
        } catch (Throwable t) { log("WifiLock no disponible: " + concise(t)); }
        try {
            if (netCallback == null) {
                final ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
                lastNet = null;
                netLost = false;
                netCallback = new ConnectivityManager.NetworkCallback() {
                    // Se decide en onCapabilitiesChanged porque ahí ya se sabe si la red es una VPN.
                    // Las redes VPN (la nuestra incluida) se ignoran: solo cuentan wifi/datos reales.
                    @Override public void onCapabilitiesChanged(Network n, NetworkCapabilities nc) {
                        if (nc == null || nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
                                || !nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return;
                        Network prev = lastNet;
                        if (n.equals(prev)) return;
                        boolean changed = prev != null || netLost;
                        lastNet = n;
                        netLost = false;
                        try { setUnderlyingNetworks(new Network[]{n}); } catch (Throwable ignored) { }
                        // Los primeros segundos tras conectar se ignoran: Android reordena redes al levantar la VPN.
                        boolean grace = android.os.SystemClock.elapsedRealtime() - connectedSince < 10_000;
                        if (changed && !grace && desired && state == ST_CONNECTED) {
                            log("Cambió la red: reconectando");
                            fail("Cambio de red");
                        }
                    }
                    @Override public void onLost(Network n) {
                        if (n.equals(lastNet)) { lastNet = null; netLost = true; }
                    }
                };
                // Esta app está excluida de la VPN (addDisallowedApplication), así que ve la red física real.
                if (cm != null && Build.VERSION.SDK_INT >= 24) cm.registerDefaultNetworkCallback(netCallback);
                else netCallback = null;
            }
        } catch (Throwable t) { netCallback = null; log("Vigilancia de red no disponible: " + concise(t)); }
    }

    private synchronized void releaseKeepAlive() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Throwable ignored) { }
        try { if (wifiLock != null && wifiLock.isHeld()) wifiLock.release(); } catch (Throwable ignored) { }
        try {
            if (netCallback != null) {
                ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
                if (cm != null) cm.unregisterNetworkCallback(netCallback);
            }
        } catch (Throwable ignored) { }
        netCallback = null;
        lastNet = null;
    }

    // ------------------------------------------------------------------ vigilante de lentitud

    // Ajustes del vigilante: los dos primeros se cambian con variables de GitHub (Settings > Secrets and variables > Actions > Variables).
    private static final int  SLOW_INTERVAL_S   = BuildConfig.SLOW_INTERVAL_S;   // cada cuántos segundos revisa (variable de GitHub SLOW_INTERVAL_S, por defecto 300 = 5 min)
    private static final int  SLOW_PROBES       = 2;         // pedidos cortos por revisión; reconecta si TODOS salen lentos
    private static final long SLOW_PROBE_GAP_MS = 4000;      // pausa entre esos pedidos
    private static final long SLOW_MIN_MS       = 3000;      // por debajo de esto nunca se considera lento
    private static final int  SLOW_FACTOR       = 4;         // lento = más de 4 veces la latencia normal
    private static final long SLOW_COOLDOWN_MS  = 120_000;   // mínimo entre dos reconexiones por lentitud
    private static final long SLOW_OK_KBPS     = BuildConfig.SLOW_OK_KBPS;     // variable de GitHub SLOW_OK_KBPS (por defecto 500): si durante la revisión el túnel bajaba a esa velocidad o más, anda bien y no reconecta

    /** Cada pocos minutos mide la latencia del túnel con 2 pedidos minúsculos; si los dos salen muy lentos, reconecta. */
    private void startSlowWatch(final int g) {
        Thread t = new Thread(() -> {
            long baseline = -1;
            try { Thread.sleep(30_000); } catch (InterruptedException e) { return; }   // deja estabilizar; esta primera revisión fija lo "normal"
            while (desired && g == gen && state == ST_CONNECTED) {
                try {
                    PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                    boolean screenOn = pm == null || pm.isInteractive();
                    int port = activeSocksPort;
                    if (screenOn && port > 0) {            // con la pantalla apagada no se mide (ahorra datos y batería)
                        long rx0 = tunnelRx();
                        long tStart = android.os.SystemClock.elapsedRealtime();
                        long[] ms = new long[SLOW_PROBES];
                        for (int k = 0; k < SLOW_PROBES; k++) {
                            if (k > 0) Thread.sleep(SLOW_PROBE_GAP_MS);
                            ms[k] = probeLatency(port);     // -1 = falló / timeout
                            if (ms[k] >= 0 && (baseline < 0 || ms[k] < baseline)) baseline = ms[k];
                        }
                        long rx1 = tunnelRx();
                        long limit = Math.max(SLOW_MIN_MS, baseline < 0 ? 0 : baseline * SLOW_FACTOR);
                        boolean allSlow = true;
                        StringBuilder sb = new StringBuilder();
                        for (long m : ms) {
                            long eff = m < 0 ? 10_000 : m;
                            if (eff <= limit) allSlow = false;
                            sb.append(sb.length() == 0 ? "" : ", ").append(m < 0 ? "sin respuesta" : m + " ms");
                        }
                        long elapsed = Math.max(1, android.os.SystemClock.elapsedRealtime() - tStart);
                        long kbps = rx0 >= 0 && rx1 >= rx0 ? (rx1 - rx0) * 8 / elapsed : 0;   // bytes*8/ms = kbps
                        boolean busyOk = kbps >= SLOW_OK_KBPS;   // está bajando bien: no es lentitud
                        if (allSlow && !busyOk) {
                            log("Túnel lento: " + sb + " (normal ~" + (baseline < 0 ? "?" : baseline + " ms") + "), bajada " + kbps + " kbps");
                            long now = android.os.SystemClock.elapsedRealtime();
                            if (now - lastSlowReconnect >= SLOW_COOLDOWN_MS) {
                                lastSlowReconnect = now;
                                log("Velocidad baja: reconectando para recuperarla");
                                fail(g, "Velocidad baja");
                                return;
                            }
                        }
                    }
                    for (int t2 = 0; t2 < SLOW_INTERVAL_S && desired && g == gen; t2++) Thread.sleep(1000);
                } catch (InterruptedException e) {
                    return;
                } catch (Throwable ignored) {
                    try { Thread.sleep(30_000); } catch (InterruptedException e) { return; }
                }
            }
        }, "VPN-slowwatch");
        t.setDaemon(true);
        t.start();
    }

    /** Bytes recibidos por el túnel (apps del teléfono) hasta ahora; -1 si no se puede leer. */
    private static long tunnelRx() {
        try {
            long[] st = TProxyService.TProxyGetStats();
            if (st != null && st.length >= 4) return st[3];
        } catch (Throwable ignored) { }
        return -1;
    }

    /** Tiempo (ms) de un pedido mínimo (204, sin cuerpo) a través del SOCKS del túnel; -1 si falla. */
    private static long probeLatency(int socksPort) {
        java.net.HttpURLConnection c = null;
        long t0 = android.os.SystemClock.elapsedRealtime();
        try {
            java.net.Proxy proxy = new java.net.Proxy(java.net.Proxy.Type.SOCKS,
                    new InetSocketAddress("127.0.0.1", socksPort));
            c = (java.net.HttpURLConnection) new java.net.URL("http://connectivitycheck.gstatic.com/generate_204").openConnection(proxy);
            c.setConnectTimeout(8_000);
            c.setReadTimeout(8_000);
            c.setUseCaches(false);
            c.setRequestProperty("Connection", "close");
            int code = c.getResponseCode();
            if (code < 200 || code >= 400) return -1;
            return android.os.SystemClock.elapsedRealtime() - t0;
        } catch (Throwable e) {
            return -1;
        } finally {
            if (c != null) { try { c.disconnect(); } catch (Throwable ignored) { } }
        }
    }

    @Override
    public void onRevoke() {
        // El usuario quitó la VPN desde los ajustes de Android.
        noRetry = true;
        fail("VPN revocada desde Android");
    }

    @Override
    public void onDestroy() {
        desired = false;
        failureSignal.countDown();
        teardown();
        releaseKeepAlive();
        if (state != ST_IDLE) setState(ST_IDLE, "Desconectado");
        super.onDestroy();
    }

    // ------------------------------------------------------------------ flujo principal

    private void supervise() {
        String endText = "Desconectado";
        String pendingEnd = "Desconectado";   // se usa solo si termina por fallo, no por cancelar
        int attempt = 0;                 // fallos seguidos
        boolean everConnected = false;
        try {
            while (desired) {
                failReason = null;
                connectedSince = Long.MAX_VALUE / 2;
                failureSignal = new CountDownLatch(1);
                try {
                    setState(ST_CONNECTING, attempt == 0 ? "Conectando\u2026" : "Reconectando\u2026 (intento " + attempt + ")");
                    establish();
                    setState(ST_CONNECTED, "Conectado");
                    connectedSince = android.os.SystemClock.elapsedRealtime();
                    log(everConnected ? "VPN restablecida" : "VPN activa");
                    showConnectedNotification();
                    everConnected = true;
                    attempt = 0;
                    startSlowWatch(gen);
                    failureSignal.await();
                    if (!desired) break;
                    pendingEnd = "Conexi\u00f3n perdida";
                    log("Conexi\u00f3n perdida: " + failReason);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (FatalException e) {
                    if (desired) { endText = "Error al conectar"; log("Error: " + concise(e)); }
                    break;
                } catch (Throwable e) {
                    if (!desired) break;
                    if (hostKeyRejected) {
                        endText = "Error al conectar";
                        log("Error: la huella del servidor cambi\u00f3. No se reintenta por seguridad.");
                        break;
                    }
                    pendingEnd = "Error al conectar";
                    log("Error: " + concise(e));
                }

                // Llegamos aqu\u00ed por una ca\u00edda o un fallo recuperable.
                teardown();
                if (!desired || noRetry || !autoReconnect) {
                    if (desired) endText = pendingEnd;
                    break;
                }
                if (!everConnected) {                       // primera conexi\u00f3n fallida: mostrar el error, sin reintentar
                    endText = pendingEnd;
                    break;
                }
                attempt++;
                if (attempt > MAX_ATTEMPTS) {
                    endText = "Reconexi\u00f3n fallida";
                    log("No se pudo reconectar tras varios intentos.");
                    break;
                }
                int wait = attempt == 1 ? 2 : attempt == 2 ? 3 : attempt == 3 ? 5 : attempt == 4 ? 8 : attempt == 5 ? 12 : 15;
                setState(ST_CONNECTING, "Reconectando en " + wait + " s\u2026 (intento " + attempt + ")");
                if (!sleepWhileDesired(wait * 1000)) break;
                waitForNetwork(60);
            }
        } finally {
            boolean wasDesired = desired;
            desired = false;
            teardown();
            releaseKeepAlive();
            setState(ST_IDLE, endText);
            supervisor = null;
            if (wasDesired) {
                stopForegroundCompat();
                stopSelf();
            }
        }
    }

    /** Espera ms milisegundos; devuelve false si el usuario cancel\u00f3 mientras tanto. */
    private boolean sleepWhileDesired(int ms) {
        try {
            for (int t = 0; t < ms && desired; t += 250) Thread.sleep(250);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
        return desired;
    }

    /** Espera (hasta maxSec) a que el tel\u00e9fono tenga alguna red con internet. */
    private void waitForNetwork(int maxSec) {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        boolean logged = false;
        for (int i = 0; i < maxSec * 4 && desired; i++) {
            if (hasInternet(cm)) return;
            if (!logged) { logged = true; log("Sin red. Esperando conexi\u00f3n\u2026"); }
            try { Thread.sleep(250); } catch (InterruptedException e) { Thread.currentThread().interrupt(); return; }
        }
    }

    private static boolean hasInternet(ConnectivityManager cm) {
        try {
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                if (nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        && !nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return true;
            }
            return false;
        } catch (Throwable ignored) {
            return true;   // si no se puede consultar, se intenta igual
        }
    }

    private void establish() throws Exception {
        final int myGen = ++gen;
        hostKeyRejected = false;
        log("Iniciando BHTTP");
        String resolved = InetAddress.getByName(host).getHostAddress();

        BhttpBridge.initCache(getApplicationContext());
        bridge = new BhttpBridge(resolved, port, new BhttpBridge.Listener() {
            @Override public void log(String str) { TunnelService.log(str); }
            @Override public void fatal(Throwable th) { fail(myGen, concise(th)); }
        }, new BhttpBridge.SocketProtector() {
            @Override public boolean protect(Socket socket) { return TunnelService.this.protect(socket); }
        }, upSlots, downSlots);
        log("Velocidad: subida " + upSlots + " / bajada " + downSlots + (liveOpt ? " (máximos; Auto+ ajusta en vivo)" : ""));

        if (BuildConfig.TLS_ENABLED) {
            // SNI automático: el nombre del servidor al que se conecta (o TLS_SNI si se definió uno).
            String sni = BuildConfig.TLS_SNI.isEmpty() ? host : BuildConfig.TLS_SNI;
            bridge.setTlsSni(sni);
            log("TLS 1.2 activado");
        }

        bridge.setBatch(batchOpt, chunkOpt);
        if (liveOpt) bridge.setLiveTune();
        int bridgePort = bridge.start();
        log("Sesión BHTTP lista");

        ssh = new Connection("127.0.0.1", bridgePort);
        ssh.addConnectionMonitor(new ConnectionMonitor() {
            @Override public void connectionLost(Throwable reason) { fail(myGen, concise(reason)); }
        });

        log("Conectando SSH");
        ssh.connect(new ServerHostKeyVerifier() {
            @Override
            public boolean verifyServerHostKey(String hostname, int p, String algo, byte[] key) throws Exception {
                return checkHostKey(algo, key);
            }
        }, 10_000, 20_000);

        if (MODE_RUFU.equals(mode)) {
            String hw = DeviceIdentity.rufuHwid(this);
            if (hw == null) throw new FatalException("Android no entreg\u00f3 el ID del dispositivo");
            log("Autenticando con HWID (usuario y contraseña)");
            boolean ok = ssh.authenticateWithPassword(hw, hw);
            if (!ok) throw new FatalException("HWID no registrado en el VPS. Crea el usuario con el comando de la app.");
        } else {
            log("Autenticando con la llave de este dispositivo");
            boolean ok = ssh.authenticateWithPublicKey(user, DeviceIdentity.keyPair(this));
            if (!ok) throw new FatalException("Dispositivo no autorizado. Registra tu HWID en el VPS.");
        }
        log("Dispositivo autorizado");

        int socksPort = freePort();
        socks = ssh.createDynamicPortForwarder(
                new InetSocketAddress(InetAddress.getByName("127.0.0.1"), socksPort));
        activeSocksPort = socksPort;   // así la prueba de velocidad puede usar el mismo túnel
        log("SOCKS5 escuchando en 127.0.0.1:" + socksPort);

        // Compartir la conexión (hotspot / Wi-Fi): proxy HTTP + SOCKS5 que sale por este mismo túnel.
        if (sharePort > 0) {
            try {
                SharedProxy sp = new SharedProxy(sharePort, socksPort, new SharedProxy.Logger() {
                    @Override public void log(String line) { TunnelService.log(line); }
                });
                sp.start();
                sharedProxy = sp;
                log("Compartir conexión activo: configura en el otro dispositivo el proxy " + SharedProxy.addresses(sharePort));
            } catch (Exception e) {
                log("No se pudo compartir la conexión (puerto " + sharePort + "): " + e.getMessage());
            }
        }

        int hevPort = socksPort;
        if (useUdp) {
            SocksFront.setDropQuic(BuildConfig.DROP_QUIC);
            front = new SocksFront(socksPort, udpgwPort, new SocksFront.Logger() {
                @Override public void log(String line) { TunnelService.log(line); }
            });
            hevPort = front.start();
            log("Modo juegos: UDP por BadVPN" + (BuildConfig.DROP_QUIC ? " (QUIC bloqueado, usa TCP)" : " (QUIC permitido)"));
        }

        startTun(hevPort, useUdp);
    }

    /** Crea la interfaz VPN y arranca hev-socks5-tunnel apuntando al SOCKS5 local. */
    private void startTun(int hevPort, boolean udp) throws Exception {
        VpnService.Builder b = new VpnService.Builder();
        b.setSession("Conecta HWID");
        final String v6m = BuildConfig.IPV6_MODE;
        if (("tunnel".equals(v6m) || "block".equals(v6m)) && mtu < 1280) {
            mtu = 1280;   // con IPv6 en la interfaz Android exige al menos 1280
            log("MTU subido a 1280: IPv6 activo lo requiere");
        }
        b.setMtu(mtu);
        b.addAddress("198.18.0.1", 32);
        // IPv6 (BuildConfig.IPV6_MODE):
        //  - "ignore" (por defecto): no se manda IPv6 al túnel. Es lo que hace la app que sí funciona con TikTok,
        //    Facebook y YouTube: el IPv6 no se captura, así que no hay nada que se pierda en silencio.
        //  - "tunnel": el túnel recibe una dirección IPv6 y el tráfico IPv6 sale por SSH al VPS.
        //  - "block": se manda todo el IPv6 al túnel sin atenderlo (se descarta; era el comportamiento antiguo).
        final String v6 = BuildConfig.IPV6_MODE;
        if ("tunnel".equals(v6)) {
            try { b.addAddress("fd00:198:18::1", 128); } catch (Throwable e) { log("IPv6 del túnel no disponible: " + e.getMessage()); }
        }
        b.addRoute("0.0.0.0", 0);
        if (udp) {
            // DNS manual: las apps preguntan a estas direcciones y la consulta sale por el túnel (por TCP).
            int added = 0;
            for (String ds : dnsServers.split(",")) {
                try { b.addDnsServer(ds.trim()); added++; } catch (Throwable ignored) { }
            }
            if (added == 0) b.addDnsServer("8.8.8.8");
            log("DNS: " + dnsServers);
        } else {
            b.addDnsServer("198.18.0.2");   // DNS interno (mapdns): el servidor resuelve los nombres
        }
        try { b.addDisallowedApplication(getPackageName()); } catch (Throwable ignored) { }
        if ("tunnel".equals(v6) || "block".equals(v6)) {
            try { b.addRoute("::", 0); } catch (Throwable ignored) { }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) b.setMetered(false);
        tun = b.establish();
        if (tun == null) throw new Exception("No se pudo crear la VPN (permiso denegado)");

        File cfg = new File(getCacheDir(), "hev.yml");
        String yml = "tunnel:\n"
                + "  mtu: " + mtu + "\n"
                + "  ipv4: 198.18.0.1\n"
                + ("tunnel".equals(v6) ? "  ipv6: 'fd00:198:18::1'\n" : "")
                + "socks5:\n"
                + "  port: " + hevPort + "\n"
                + "  address: 127.0.0.1\n"
                + (udp ? "  udp: 'udp'\n" : "")
                + (udp ? "" : "mapdns:\n"
                + "  address: 198.18.0.2\n"
                + "  port: 53\n"
                + "  network: 100.64.0.0\n"
                + "  netmask: 255.192.0.0\n"   // 100.64.0.0/10 (antes 240.0.0.0 = 96.0.0.0/4, que pisaba IPs públicas reales)
                + "  cache-size: 10000\n")
                + "misc:\n"
                + "  log-level: warn\n";
        try (FileOutputStream fo = new FileOutputStream(cfg)) {
            fo.write(yml.getBytes(StandardCharsets.UTF_8));
        }
        log("Iniciando túnel (IPv6: " + BuildConfig.IPV6_MODE + ")");
        boolean started = TProxyService.TProxyStartService(cfg.getAbsolutePath(), tun.getFd());
        if (!started) throw new Exception("El túnel nativo no arrancó");
        tproxyStarted = true;

        // Estadística de la interfaz VPN: tráfico real de las apps del teléfono que entra al túnel.
        final int statGen = gen;
        Thread statThread = new Thread(() -> {
            long[] last = null;
            while (desired && statGen == gen && tproxyStarted) {
                try { Thread.sleep(10000); } catch (InterruptedException e) { return; }
                if (!(desired && statGen == gen && tproxyStarted)) return;
                try {
                    long[] st = TProxyService.TProxyGetStats();
                    if (st != null && st.length >= 4) {
                        if (last != null) {
                            log("VPN (apps del teléfono) en 10s: tx " + (st[0] - last[0]) + " paq / " + (st[1] - last[1])
                                    + " B, rx " + (st[2] - last[2]) + " paq / " + (st[3] - last[3]) + " B");
                        }
                        last = st;
                    }
                } catch (Throwable ignored) { }
            }
        }, "VPN-stats");
        statThread.setDaemon(true);
        statThread.start();
    }

    /** Primera vez guarda la huella del servidor; si luego cambia, rechaza (protege contra MITM). */
    private boolean checkHostKey(String algo, byte[] key) throws Exception {
        byte[] h = MessageDigest.getInstance("SHA-256").digest(key);
        String fp = algo + ":" + Base64.encodeToString(h, Base64.NO_WRAP);
        SharedPreferences sp = getSharedPreferences("hostkeys", MODE_PRIVATE);
        String id = host + ":" + port;
        String saved = sp.getString(id, null);
        if (saved == null) {
            sp.edit().putString(id, fp).apply();
            log("Huella del servidor guardada (primera conexión)");
            return true;
        }
        if (saved.equals(fp)) return true;
        hostKeyRejected = true;
        log("\u00a1La huella del servidor cambi\u00f3! Conexi\u00f3n rechazada.");
        return false;
    }

    private synchronized void teardown() {
        activeSocksPort = -1;
        if (tproxyStarted) {
            tproxyStarted = false;
            try { TProxyService.TProxyStopService(); } catch (Throwable ignored) { }
        }
        ParcelFileDescriptor t = tun; tun = null;
        if (t != null) try { t.close(); } catch (Exception ignored) { }
        SharedProxy shp = sharedProxy; sharedProxy = null;
        if (shp != null) try { shp.close(); } catch (Throwable ignored) { }
        SocksFront fr = front; front = null;
        if (fr != null) try { fr.close(); } catch (Throwable ignored) { }
        DynamicPortForwarder d = socks; socks = null;
        if (d != null) try { d.close(); } catch (Exception ignored) { }
        Connection c = ssh; ssh = null;
        if (c != null) try { c.close(); } catch (Exception ignored) { }
        BhttpBridge br = bridge; bridge = null;
        if (br != null) try { br.close(); } catch (Exception ignored) { }
    }

    private void fail(String reason) { fail(gen, reason); }

    private void fail(int g, String reason) {
        if (g != gen || !desired || failReason != null) return;
        failReason = reason == null ? "desconocido" : reason;
        failureSignal.countDown();
    }

    // ------------------------------------------------------------------ utilidades

    private static void setState(int s, String text) {
        if (s == ST_CONNECTING && state == ST_IDLE) {
            baseRx = TrafficStats.getUidRxBytes(Process.myUid());
            baseTx = TrafficStats.getUidTxBytes(Process.myUid());
        }
        state = s;
        stateText = text;
        Listener l = listener;
        if (l != null) l.onState(s, text);
    }

    public static void clearLogs() {
        synchronized (LOGS) { LOGS.clear(); }
    }

    private static void log(String raw) {
        String line = LogMask.mask(raw);   // IP, puerto, usuario e ID nunca llegan al registro
        synchronized (LOGS) {
            LOGS.addLast(line);
            while (LOGS.size() > 200) LOGS.removeFirst();
        }
        Listener l = listener;
        if (l != null) l.onLog(line);
    }

    private static int freePort() throws Exception {
        try (ServerSocket s = new ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))) {
            return s.getLocalPort();
        }
    }

    private static String concise(Throwable t) {
        if (t == null) return "error";
        return t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
    }

    private Notification buildNotification(long connectedAtMs) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Conexión VPN", NotificationManager.IMPORTANCE_LOW));
        }
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder nb = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        nb.setContentTitle("Conecta HWID")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(open)
                .setOnlyAlertOnce(true)
                .setOngoing(true);
        if (connectedAtMs > 0) {
            // El cronómetro del sistema cuenta solo desde que la VPN quedó activa, sin reenviar la notificación.
            nb.setContentText("VPN en uso")
                    .setShowWhen(true)
                    .setWhen(connectedAtMs)
                    .setUsesChronometer(true);
        } else {
            nb.setContentText("Conectando\u2026");
        }
        return nb.build();
    }

    /** Se llama cuando la VPN queda activa: reinicia el cronómetro de la notificación. */
    private void showConnectedNotification() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIF_ID, buildNotification(System.currentTimeMillis()));
        } catch (Throwable ignored) { }
    }

    private void startForegroundCompat() {
        Notification n = buildNotification(0);
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED);
            } catch (Throwable first) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            }
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void stopForegroundCompat() {
        stopForeground(true);
    }
}
