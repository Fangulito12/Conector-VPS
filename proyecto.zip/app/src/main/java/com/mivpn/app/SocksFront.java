package com.mivpn.app;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Servidor SOCKS5 local que le entrega tráfico a hev-socks5-tunnel.
 *
 *  - TCP (CONNECT): lo reenvía al SOCKS del reenviador SSH (upstream).
 *  - UDP (ASSOCIATE):
 *      * puerto 53 (DNS): se resuelve por TCP a través del túnel, con caché.
 *      * resto (juegos, voz, QUIC): se envía a badvpn-udpgw en el VPS (si está disponible).
 *
 * Solo usa java.net, así que se puede probar fuera de Android.
 */
public final class SocksFront {

    public interface Logger { void log(String s); }

    private static final int DNS_CACHE_MAX = 512;
    private static final long DNS_CACHE_TTL_MS = 60_000;
    private static final int MAX_UDPGW_FLOWS = 1000;
    /** QUIC (UDP 443): se descarta para que TikTok, Facebook, YouTube, etc. usen TCP de inmediato en vez de depender de BadVPN. */
    private static final boolean DROP_QUIC = true;

    private final int upstreamPort;
    private final int udpgwPort;          // 0 = BadVPN desactivado
    private final Logger logger;

    private volatile boolean closed;
    private ServerSocket server;
    private ExecutorService pool;
    private UdpGw gw;
    private final Set<Assoc> assocs = ConcurrentHashMap.newKeySet();
    private final AtomicInteger assocIds = new AtomicInteger();

    private final Map<String, CachedDns> dnsCache = new LinkedHashMap<String, CachedDns>(64, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, CachedDns> e) { return size() > DNS_CACHE_MAX; }
    };

    private static final class CachedDns {
        final byte[] response; final long at;
        CachedDns(byte[] r, long at) { this.response = r; this.at = at; }
    }

    public SocksFront(int upstreamPort, int udpgwPort, Logger logger) {
        this.upstreamPort = upstreamPort;
        this.udpgwPort = udpgwPort;
        this.logger = logger != null ? logger : new Logger() { @Override public void log(String s) { } };
    }

    /** Arranca y devuelve el puerto local donde escucha. */
    public int start() throws IOException {
        server = new ServerSocket(0, 256, InetAddress.getByName("127.0.0.1"));
        pool = Executors.newCachedThreadPool(new ThreadFactory() {
            @Override public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "socksfront");
                t.setDaemon(true);
                return t;
            }
        });
        if (udpgwPort > 0) gw = new UdpGw();
        pool.execute(new Runnable() { @Override public void run() { acceptLoop(); } });
        return server.getLocalPort();
    }

    public void close() {
        closed = true;
        quiet(server);
        if (gw != null) gw.down();
        for (Assoc a : assocs) a.close();
        if (pool != null) pool.shutdownNow();
    }

    // ------------------------------------------------------------------ aceptar y negociar SOCKS5

    private void acceptLoop() {
        while (!closed) {
            try {
                final Socket c = server.accept();
                pool.execute(new Runnable() { @Override public void run() { handle(c); } });
            } catch (IOException e) {
                if (closed) return;
            } catch (RuntimeException e) {
                return;
            }
        }
    }

    private void handle(Socket c) {
        try {
            c.setTcpNoDelay(true);
            c.setSoTimeout(15_000);
            InputStream in = c.getInputStream();
            OutputStream out = c.getOutputStream();

            if (in.read() != 5) return;
            int n = in.read();
            if (n < 0) return;
            readFully(in, new byte[n], n);
            out.write(new byte[]{5, 0});
            out.flush();

            int ver = in.read();
            int cmd = in.read();
            in.read();
            int atyp = in.read();
            if (ver != 5 || atyp < 0) return;
            Addr a = readAddr(in, atyp);
            c.setSoTimeout(0);

            if (cmd == 1) doConnect(c, out, a);
            else if (cmd == 3) doUdp(in, out);
            else reply(out, 7);
        } catch (Throwable ignored) {
            // conexión cerrada o mal formada
        } finally {
            quiet(c);
        }
    }

    private static final class Addr {
        int atyp;          // 1 = IPv4, 3 = dominio, 4 = IPv6
        byte[] ip;         // IPv4/IPv6
        String domain;     // dominio
        int port;

        static Addr ip(byte[] ip, int port) {
            Addr a = new Addr();
            a.atyp = ip.length == 16 ? 4 : 1;
            a.ip = ip;
            a.port = port;
            return a;
        }
    }

    private static Addr readAddr(InputStream in, int atyp) throws IOException {
        Addr a = new Addr();
        a.atyp = atyp;
        if (atyp == 1) {
            a.ip = new byte[4];
            readFully(in, a.ip, 4);
        } else if (atyp == 4) {
            a.ip = new byte[16];
            readFully(in, a.ip, 16);
        } else if (atyp == 3) {
            int l = in.read();
            if (l <= 0) throw new IOException("dominio vacío");
            byte[] d = new byte[l];
            readFully(in, d, l);
            a.domain = new String(d, StandardCharsets.ISO_8859_1);
        } else {
            throw new IOException("ATYP no soportado");
        }
        byte[] p = new byte[2];
        readFully(in, p, 2);
        a.port = ((p[0] & 0xff) << 8) | (p[1] & 0xff);
        return a;
    }

    private static void reply(OutputStream out, int rep) throws IOException {
        out.write(new byte[]{5, (byte) rep, 0, 1, 0, 0, 0, 0, 0, 0});
        out.flush();
    }

    // ------------------------------------------------------------------ TCP

    /** Abre una conexión TCP al destino usando el SOCKS del reenviador SSH. */
    private Socket connectUpstream(Addr a) throws IOException {
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), upstreamPort), 5_000);
            s.setTcpNoDelay(true);
            s.setSoTimeout(30_000);
            InputStream in = s.getInputStream();
            OutputStream out = s.getOutputStream();

            out.write(new byte[]{5, 1, 0});
            out.flush();
            byte[] r = new byte[2];
            readFully(in, r, 2);
            if (r[0] != 5 || r[1] != 0) throw new IOException("SOCKS upstream rechazó el método");

            byte[] req;
            if (a.atyp == 3) {
                byte[] d = a.domain.getBytes(StandardCharsets.ISO_8859_1);
                req = new byte[7 + d.length];
                req[3] = 3;
                req[4] = (byte) d.length;
                System.arraycopy(d, 0, req, 5, d.length);
            } else {
                req = new byte[6 + a.ip.length];
                req[3] = (byte) (a.ip.length == 16 ? 4 : 1);
                System.arraycopy(a.ip, 0, req, 4, a.ip.length);
            }
            req[0] = 5;
            req[1] = 1;
            req[2] = 0;
            req[req.length - 2] = (byte) (a.port >> 8);
            req[req.length - 1] = (byte) a.port;
            out.write(req);
            out.flush();

            byte[] h = new byte[4];
            readFully(in, h, 4);
            if (h[0] != 5) throw new IOException("respuesta SOCKS inválida");
            int skip = h[3] == 1 ? 4 : h[3] == 4 ? 16 : h[3] == 3 ? (in.read() & 0xff) : 0;
            readFully(in, new byte[skip + 2], skip + 2);
            if (h[1] != 0) throw new IOException("destino inaccesible (código " + (h[1] & 0xff) + ")");
            s.setSoTimeout(0);
            return s;
        } catch (IOException e) {
            quiet(s);
            throw e;
        }
    }

    private void doConnect(final Socket c, final OutputStream out, Addr a) throws IOException {
        final Socket up;
        try {
            up = connectUpstream(a);
        } catch (IOException e) {
            reply(out, 5);
            return;
        }
        reply(out, 0);

        final InputStream cin = c.getInputStream();
        final InputStream uin = up.getInputStream();
        final OutputStream uout = up.getOutputStream();
        final java.util.concurrent.CountDownLatch done = new java.util.concurrent.CountDownLatch(1);
        pool.execute(new Runnable() {
            @Override public void run() {
                try { pump(uin, out, up, c); } finally { done.countDown(); }
            }
        });
        try {
            pump(cin, uout, c, up);
            done.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            quiet(up);
        }
    }

    /** Copia src -> dst. En EOF limpio cierra solo la escritura de dst (half-close); en error cierra ambos. */
    private static void pump(InputStream in, OutputStream out, Socket from, Socket to) {
        byte[] buf = new byte[32 * 1024];
        try {
            int n;
            while ((n = in.read(buf)) >= 0) {
                out.write(buf, 0, n);
                out.flush();
            }
            try { to.shutdownOutput(); } catch (Exception ignored) { }
        } catch (IOException e) {
            quiet(from);
            quiet(to);
        }
    }

    // ------------------------------------------------------------------ UDP

    private final class Assoc {
        final int id = assocIds.incrementAndGet();
        final DatagramSocket ds;
        volatile SocketAddress client;
        volatile boolean closed;

        Assoc(DatagramSocket ds) { this.ds = ds; }

        /** Envía a hev un datagrama SOCKS5 con origen (ip, port). */
        void deliver(byte[] ip, int port, byte[] data, int off, int len) {
            SocketAddress to = client;
            if (to == null || closed) return;
            try {
                byte[] pkt = new byte[4 + ip.length + 2 + len];
                pkt[3] = (byte) (ip.length == 16 ? 4 : 1);
                System.arraycopy(ip, 0, pkt, 4, ip.length);
                pkt[4 + ip.length] = (byte) (port >> 8);
                pkt[5 + ip.length] = (byte) port;
                System.arraycopy(data, off, pkt, 6 + ip.length, len);
                ds.send(new DatagramPacket(pkt, pkt.length, to));
            } catch (IOException ignored) { }
        }

        void close() {
            closed = true;
            ds.close();
            assocs.remove(this);
            if (gw != null) gw.forget(this);
        }
    }

    private void doUdp(InputStream in, OutputStream out) throws IOException {
        DatagramSocket ds = new DatagramSocket(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0));
        final Assoc as = new Assoc(ds);
        assocs.add(as);
        int p = ds.getLocalPort();
        out.write(new byte[]{5, 0, 0, 1, 127, 0, 0, 1, (byte) (p >> 8), (byte) p});
        out.flush();

        pool.execute(new Runnable() { @Override public void run() { relay(as); } });
        try {
            while (in.read() >= 0) { /* la conexión de control vive mientras dure la asociación */ }
        } catch (IOException ignored) { }
        as.close();
    }

    private void relay(Assoc as) {
        byte[] buf = new byte[65535];
        DatagramPacket p = new DatagramPacket(buf, buf.length);
        while (!as.closed && !closed) {
            try {
                p.setLength(buf.length);
                as.ds.receive(p);
            } catch (IOException e) {
                return;
            }
            as.client = p.getSocketAddress();
            try {
                parseDatagram(as, buf, p.getLength());
            } catch (RuntimeException ignored) { }
        }
    }

    private void parseDatagram(final Assoc as, byte[] b, int len) {
        if (len < 10 || b[2] != 0) return;                      // sin fragmentos
        int atyp = b[3] & 0xff;
        int off = 4;
        byte[] ip = null;
        String domain = null;
        if (atyp == 1) { ip = Arrays.copyOfRange(b, off, off + 4); off += 4; }
        else if (atyp == 4) { if (len < off + 18) return; ip = Arrays.copyOfRange(b, off, off + 16); off += 16; }
        else if (atyp == 3) {
            int dl = b[off] & 0xff;
            if (len < off + 1 + dl + 2) return;
            domain = new String(b, off + 1, dl, StandardCharsets.ISO_8859_1);
            off += 1 + dl;
        } else return;
        if (len < off + 2) return;
        final int port = ((b[off] & 0xff) << 8) | (b[off + 1] & 0xff);
        off += 2;
        final byte[] data = Arrays.copyOfRange(b, off, len);

        if (ip != null) {
            dispatchUdp(as, ip, port, data);
        } else {
            final String d = domain;
            pool.execute(new Runnable() {
                @Override public void run() {
                    try {
                        InetAddress[] all = InetAddress.getAllByName(d);
                        for (InetAddress x : all) {
                            if (x.getAddress().length == 4) { dispatchUdp(as, x.getAddress(), port, data); return; }
                        }
                    } catch (IOException ignored) { }
                }
            });
        }
    }

    private void dispatchUdp(final Assoc as, final byte[] ip, final int port, final byte[] data) {
        if (port == 53) {
            pool.execute(new Runnable() { @Override public void run() { dns(as, ip, port, data); } });
        } else if (DROP_QUIC && port == 443) {
            // sin respuesta: la app da por fallido QUIC y sigue por TCP
        } else if (gw != null) {
            gw.send(as, ip, port, data);
        }
    }

    // ------------------------------------------------------------------ DNS (TCP + caché)

    private void dns(Assoc as, byte[] ip, int port, byte[] query) {
        if (query.length < 12) return;
        String key = hex(ip) + "|" + questionKey(query);
        long now = System.currentTimeMillis();
        CachedDns hit;
        synchronized (dnsCache) { hit = dnsCache.get(key); }
        if (hit != null && now - hit.at < DNS_CACHE_TTL_MS) {
            byte[] r = hit.response.clone();
            r[0] = query[0];
            r[1] = query[1];
            as.deliver(ip, port, r, 0, r.length);
            return;
        }
        Socket s = null;
        try {
            s = connectUpstream(Addr.ip(ip, 53));
            s.setSoTimeout(6_000);
            OutputStream o = s.getOutputStream();
            byte[] framed = new byte[2 + query.length];
            framed[0] = (byte) (query.length >> 8);
            framed[1] = (byte) query.length;
            System.arraycopy(query, 0, framed, 2, query.length);
            o.write(framed);
            o.flush();
            InputStream i = s.getInputStream();
            byte[] lh = new byte[2];
            readFully(i, lh, 2);
            int rl = ((lh[0] & 0xff) << 8) | (lh[1] & 0xff);
            if (rl < 12) return;
            byte[] resp = new byte[rl];
            readFully(i, resp, rl);
            boolean ok = (resp[3] & 0x0f) == 0 && (((resp[6] & 0xff) << 8) | (resp[7] & 0xff)) > 0;
            if (ok) synchronized (dnsCache) { dnsCache.put(key, new CachedDns(resp, System.currentTimeMillis())); }
            as.deliver(ip, port, resp, 0, resp.length);
        } catch (IOException ignored) {
        } finally {
            quiet(s);
        }
    }

    /** Parte "pregunta" de un mensaje DNS (nombre + tipo + clase), igual en consulta y respuesta. */
    private static String questionKey(byte[] m) {
        int p = 12;
        while (p < m.length && m[p] != 0) p += (m[p] & 0xff) + 1;
        int end = Math.min(m.length, p + 5);
        return new String(m, 12, Math.max(0, end - 12), StandardCharsets.ISO_8859_1);
    }

    // ------------------------------------------------------------------ BadVPN (udpgw)

    private static final class Flow {
        final int con; final Assoc assoc; final byte[] ip; final int port; volatile long last;
        Flow(int con, Assoc a, byte[] ip, int port) { this.con = con; this.assoc = a; this.ip = ip; this.port = port; }
    }

    /**
     * Cliente del protocolo de badvpn-udpgw. Una sola conexión TCP (a través del túnel SSH) lleva
     * todos los flujos UDP. Cada paquete: [largo LE16][flags][conid LE16][IP][puerto BE16][datos].
     */
    private final class UdpGw {
        private final Map<Integer, Flow> byCon = new ConcurrentHashMap<>();
        private final Map<String, Flow> byKey = new ConcurrentHashMap<>();
        private final Object writeLock = new Object();
        private Socket sock;
        private OutputStream out;
        private volatile boolean up;
        private long lastFail;
        private boolean failLogged;
        private int nextCon = 1;
        private volatile boolean gotReply;
        private boolean warnScheduled;

        synchronized boolean ensure() {
            if (up) return true;
            long now = System.currentTimeMillis();
            if (now - lastFail < 10_000) return false;
            try {
                Socket s = connectUpstream(Addr.ip(new byte[]{127, 0, 0, 1}, udpgwPort));
                byCon.clear();
                byKey.clear();
                sock = s;
                out = s.getOutputStream();
                up = true;
                failLogged = false;
                final Socket fs = s;
                pool.execute(new Runnable() { @Override public void run() { readLoop(fs); } });
                logger.log("BadVPN conectado");
                return true;
            } catch (IOException e) {
                lastFail = now;
                if (!failLogged) {
                    failLogged = true;
                    logger.log("BadVPN no disponible en el servidor. UDP de juegos desactivado.");
                }
                return false;
            }
        }

        void send(Assoc as, byte[] ip, int port, byte[] data) {
            if (!ensure()) return;
            String key = as.id + "|" + hex(ip) + ":" + port;
            Flow f = byKey.get(key);
            if (f == null) {
                if (byCon.size() >= MAX_UDPGW_FLOWS) evict();
                synchronized (this) {
                    int con;
                    do { con = nextCon++; if (nextCon > 65535) nextCon = 1; } while (byCon.containsKey(con));
                    f = new Flow(con, as, ip, port);
                    byKey.put(key, f);
                    byCon.put(con, f);
                }
            }
            f.last = System.currentTimeMillis();

            int plen = 3 + ip.length + 2 + data.length;
            if (plen > 65535) return;
            byte[] fr = new byte[2 + plen];
            fr[0] = (byte) plen;
            fr[1] = (byte) (plen >> 8);
            fr[2] = (byte) (ip.length == 16 ? 0x08 : 0x00);
            fr[3] = (byte) f.con;
            fr[4] = (byte) (f.con >> 8);
            System.arraycopy(ip, 0, fr, 5, ip.length);
            fr[5 + ip.length] = (byte) (port >> 8);
            fr[6 + ip.length] = (byte) port;
            System.arraycopy(data, 0, fr, 7 + ip.length, data.length);
            try {
                synchronized (writeLock) { out.write(fr); out.flush(); }
            } catch (IOException e) {
                logger.log("BadVPN: error al enviar (" + e + ")");
                down();
                return;
            }
            scheduleWarning();
        }

        private synchronized void scheduleWarning() {
            if (warnScheduled) return;
            warnScheduled = true;
            pool.execute(new Runnable() {
                @Override public void run() {
                    try { Thread.sleep(8_000); } catch (InterruptedException e) { return; }
                    if (!gotReply && up) {
                        logger.log("BadVPN no responde. Verifica que badvpn-udpgw esté activo en el VPS y que el puerto BadVPN sea el correcto.");
                    }
                }
            });
        }

        private void readLoop(Socket s) {
            try {
                InputStream in = s.getInputStream();
                byte[] hdr = new byte[2];
                while (true) {
                    readFully(in, hdr, 2);
                    int len = (hdr[0] & 0xff) | ((hdr[1] & 0xff) << 8);
                    byte[] b = new byte[len];
                    readFully(in, b, len);
                    if (len < 3) continue;
                    int flags = b[0] & 0xff;
                    if ((flags & 0x01) != 0) continue;                       // keepalive
                    int con = (b[1] & 0xff) | ((b[2] & 0xff) << 8);
                    int off = 3;
                    int al = (flags & 0x08) != 0 ? 16 : 4;
                    if (len < off + al + 2) continue;
                    byte[] ip = Arrays.copyOfRange(b, off, off + al);
                    off += al;
                    int port = ((b[off] & 0xff) << 8) | (b[off + 1] & 0xff);
                    off += 2;
                    Flow f = byCon.get(con);
                    if (f == null) continue;
                    f.last = System.currentTimeMillis();
                    if (!gotReply) {
                        gotReply = true;
                        logger.log("BadVPN responde correctamente");
                    }
                    f.assoc.deliver(ip, port, b, off, len - off);
                }
            } catch (IOException e) {
                if (s == sock) logger.log("BadVPN desconectado: " + e);
            } finally {
                if (s == sock) down();
            }
        }

        synchronized void down() {
            up = false;
            quiet(sock);
            byCon.clear();
            byKey.clear();
        }

        void forget(Assoc as) {
            for (Iterator<Map.Entry<String, Flow>> it = byKey.entrySet().iterator(); it.hasNext(); ) {
                Flow f = it.next().getValue();
                if (f.assoc == as) { it.remove(); byCon.remove(f.con); }
            }
        }

        private void evict() {
            long limit = System.currentTimeMillis() - 30_000;
            for (Iterator<Map.Entry<String, Flow>> it = byKey.entrySet().iterator(); it.hasNext(); ) {
                Flow f = it.next().getValue();
                if (f.last < limit) { it.remove(); byCon.remove(f.con); }
            }
            if (byCon.size() >= MAX_UDPGW_FLOWS) { byKey.clear(); byCon.clear(); }
        }
    }

    // ------------------------------------------------------------------ utilidades

    private static void readFully(InputStream in, byte[] b, int n) throws IOException {
        int off = 0;
        while (off < n) {
            int r = in.read(b, off, n - off);
            if (r < 0) throw new IOException("fin de flujo");
            off += r;
        }
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x & 0xff));
        return sb.toString();
    }

    private static void quiet(Closeable c) {
        if (c != null) try { c.close(); } catch (Exception ignored) { }
    }

    private static void quiet(Socket s) {
        if (s != null) try { s.close(); } catch (Exception ignored) { }
    }
}
