APP_OPTIM := release
APP_PLATFORM := android-24
APP_ABI := arm64-v8a armeabi-v7a
APP_CFLAGS := -O3 -DPKGNAME=hev/htproxy -DCLSNAME=TProxyService
APP_STL := none
APP_LDFLAGS += -Wl,-z,max-page-size=16384
